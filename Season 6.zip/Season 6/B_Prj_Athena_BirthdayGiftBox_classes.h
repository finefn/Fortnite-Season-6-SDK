// BlueprintGeneratedClass B_Prj_Athena_BirthdayGiftBox.B_Prj_Athena_BirthdayGiftBox_C
// Size: 0xbf0 (Inherited: 0xbdc)
struct AB_Prj_Athena_BirthdayGiftBox_C : AB_Prj_Athena_GiftBox_C {
	char UnknownData_BDC[0x4]; // 0xbdc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbe0(0x08)
	struct UAudioComponent* InAirAudio; // 0xbe8(0x08)

	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Athena_BirthdayGiftBox.B_Prj_Athena_BirthdayGiftBox_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_BirthdayGiftBox(int32_t EntryPoint); // Function B_Prj_Athena_BirthdayGiftBox.B_Prj_Athena_BirthdayGiftBox_C.ExecuteUbergraph_B_Prj_Athena_BirthdayGiftBox // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

