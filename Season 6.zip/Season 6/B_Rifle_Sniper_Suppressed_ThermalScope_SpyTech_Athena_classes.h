// BlueprintGeneratedClass B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena.B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C
// Size: 0x12fc (Inherited: 0x12dc)
struct AB_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C : AB_Rifle_Generic_C {
	char UnknownData_12DC[0x4]; // 0x12dc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x12e0(0x08)
	float ScalePlayerThermal_NewTrack_0_253E51B74F624080BF58BDA99C8B5B64; // 0x12e8(0x04)
	enum class ETimelineDirection ScalePlayerThermal__Direction_253E51B74F624080BF58BDA99C8B5B64; // 0x12ec(0x01)
	char UnknownData_12ED[0x3]; // 0x12ed(0x03)
	struct UTimelineComponent* ScalePlayerThermal; // 0x12f0(0x08)
	float BlendInTime; // 0x12f8(0x04)

	void ScalePlayerThermal__FinishedFunc(); // Function B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena.B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C.ScalePlayerThermal__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void ScalePlayerThermal__UpdateFunc(); // Function B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena.B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C.ScalePlayerThermal__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnSetTargeting(bool bNewIsTargeting); // Function B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena.B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C.OnSetTargeting // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void PlayScopePP(); // Function B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena.B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C.PlayScopePP // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReverseScopePP(); // Function B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena.B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C.ReverseScopePP // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ForceScopeBackImmediatly(); // Function B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena.B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C.ForceScopeBackImmediatly // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena(int32_t EntryPoint); // Function B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena.B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena_C.ExecuteUbergraph_B_Rifle_Sniper_Suppressed_ThermalScope_SpyTech_Athena // (Final|UbergraphFunction) // @ game+0xbd830c
};

