// BlueprintGeneratedClass B_HeldObject_Generic_Component.B_HeldObject_Generic_Component_C
// Size: 0xd4c (Inherited: 0xd40)
struct AB_HeldObject_Generic_Component_C : AFortWeapon {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd40(0x08)
	int32_t BattleLabHudKeyDataIndex; // 0xd48(0x04)

	void K2_OnUnEquip(); // Function B_HeldObject_Generic_Component.B_HeldObject_Generic_Component_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_HeldObject_Generic_Component.B_HeldObject_Generic_Component_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_HeldObject_Generic_Component(int32_t EntryPoint); // Function B_HeldObject_Generic_Component.B_HeldObject_Generic_Component_C.ExecuteUbergraph_B_HeldObject_Generic_Component // (Final|UbergraphFunction) // @ game+0xbd830c
};

