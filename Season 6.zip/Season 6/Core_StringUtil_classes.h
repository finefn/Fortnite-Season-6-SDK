// SolarisGeneratedClass Core_StringUtil.StringUtil
// Size: 0x28 (Inherited: 0x28)
struct UStringUtil : UObject {

	struct FString Join(struct FString __verse_0x7B90A06E_separator, struct TArray<struct FString> __verse_0x7817A78F_strings); // Function Core_StringUtil.StringUtil.Join // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6fac
	struct FString fromInt(int32_t __verse_0xE50A13DD_val); // Function Core_StringUtil.StringUtil.fromInt // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed688c
	struct FString fromFloat(float __verse_0xE50A13DD_val); // Function Core_StringUtil.StringUtil.fromFloat // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6884
	struct FString fromBool(char __verse_0xE50A13DD_val); // Function Core_StringUtil.StringUtil.fromBool // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed687c
	struct FString concatArray(struct TArray<struct FString> __verse_0x7817A78F_strings); // Function Core_StringUtil.StringUtil.concatArray // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed64d0
	struct FString concat4(struct FString __verse_0xAE808AE8_one, struct FString __verse_0x38034999_two, struct FString __verse_0xA18F2A98_three, struct FString __verse_0xACAB2BF9_four); // Function Core_StringUtil.StringUtil.concat4 // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed64c8
	struct FString concat3(struct FString __verse_0xAE808AE8_one, struct FString __verse_0x38034999_two, struct FString __verse_0xA18F2A98_three); // Function Core_StringUtil.StringUtil.concat3 // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed64c0
	struct FString Concat(struct FString __verse_0x9A53092C_lhs, struct FString __verse_0x786D20C9_rhs); // Function Core_StringUtil.StringUtil.Concat // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed64d8
	void $InitInstance(); // Function Core_StringUtil.StringUtil.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Core_StringUtil.StringUtil.$InitCDO // () // @ game+0xbd830c
};

