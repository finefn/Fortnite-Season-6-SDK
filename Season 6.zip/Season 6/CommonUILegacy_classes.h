// Class CommonUILegacy.CommonActivatablePanel
// Size: 0x458 (Inherited: 0x320)
struct UCommonActivatablePanel : UCommonActivatableWidget {
	char UnknownData_320[0x8]; // 0x320(0x08)
	struct FMulticastInlineDelegate OnWidgetActivated; // 0x328(0x10)
	struct FMulticastInlineDelegate OnWidgetDeactivated; // 0x338(0x10)
	bool bConsumeAllActions; // 0x348(0x01)
	bool bExposeActionsExternally; // 0x349(0x01)
	bool bShouldBypassStack; // 0x34a(0x01)
	char UnknownData_34B[0x10d]; // 0x34b(0x10d)

	void SetInputActionHandlerWithProgressPopupMenu(struct FDataTableRowHandle InputActionRow, struct FDelegate CommitedEvent, struct FDelegate ProgressEvent, struct UCommonPopupMenu* PopupMenu); // Function CommonUILegacy.CommonActivatablePanel.SetInputActionHandlerWithProgressPopupMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x34b9764
	void SetInputActionHandlerWithProgress(struct FDataTableRowHandle InputActionRow, struct FDelegate CommitedEvent, struct FDelegate ProgressEvent); // Function CommonUILegacy.CommonActivatablePanel.SetInputActionHandlerWithProgress // (Final|Native|Public|BlueprintCallable) // @ game+0x34b95e4
	void SetInputActionHandlerWithPopupMenu(struct FDataTableRowHandle InputActionRow, struct FDelegate CommitedEvent, struct UCommonPopupMenu* PopupMenu); // Function CommonUILegacy.CommonActivatablePanel.SetInputActionHandlerWithPopupMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x34b9450
	void SetInputActionHandler(struct FDataTableRowHandle InputActionRow, struct FDelegate CommitedEvent); // Function CommonUILegacy.CommonActivatablePanel.SetInputActionHandler // (Final|Native|Public|BlueprintCallable) // @ game+0x1322d00
	void SetActionHandlerStateWithDisabledCommitEvent(struct UDataTable* DataTable, struct FName RowName, enum class EInputActionState State, struct FDelegate DisabledCommitEvent); // Function CommonUILegacy.CommonActivatablePanel.SetActionHandlerStateWithDisabledCommitEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8f84
	void SetActionHandlerStateFromHandleWithDisabledCommitEvent(struct FDataTableRowHandle InputActionRow, enum class EInputActionState State, struct FDelegate DisabledCommitEvent); // Function CommonUILegacy.CommonActivatablePanel.SetActionHandlerStateFromHandleWithDisabledCommitEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8e24
	void SetActionHandlerStateFromHandle(struct FDataTableRowHandle InputActionRow, enum class EInputActionState State); // Function CommonUILegacy.CommonActivatablePanel.SetActionHandlerStateFromHandle // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8d28
	void SetActionHandlerState(struct UDataTable* DataTable, struct FName RowName, enum class EInputActionState State); // Function CommonUILegacy.CommonActivatablePanel.SetActionHandlerState // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8bd4
	void RemoveInputActionHandler(struct FDataTableRowHandle InputActionRow); // Function CommonUILegacy.CommonActivatablePanel.RemoveInputActionHandler // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8afc
	void RemoveAllInputActionHandlers(); // Function CommonUILegacy.CommonActivatablePanel.RemoveAllInputActionHandlers // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8ae8
	void PopPanel(); // Function CommonUILegacy.CommonActivatablePanel.PopPanel // (Native|Public|BlueprintCallable) // @ game+0x34b88cc
	void OnTransitionedBySwitcher(); // Function CommonUILegacy.CommonActivatablePanel.OnTransitionedBySwitcher // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnRemovedFromActivationStack(); // Function CommonUILegacy.CommonActivatablePanel.OnRemovedFromActivationStack // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnInputModeChanged(bool bUsingGamepad); // Function CommonUILegacy.CommonActivatablePanel.OnInputModeChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnBeginOutro(); // Function CommonUILegacy.CommonActivatablePanel.OnBeginOutro // (Native|Event|Protected|BlueprintEvent) // @ game+0x15d3b0c
	void OnBeginIntro(); // Function CommonUILegacy.CommonActivatablePanel.OnBeginIntro // (Native|Event|Protected|BlueprintEvent) // @ game+0x1486388
	void OnAddedToActivationStack(); // Function CommonUILegacy.CommonActivatablePanel.OnAddedToActivationStack // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	bool IsIntroed(); // Function CommonUILegacy.CommonActivatablePanel.IsIntroed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b86ac
	bool IsInActivationStack(); // Function CommonUILegacy.CommonActivatablePanel.IsInActivationStack // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b8668
	bool HasInputActionHandler(struct FDataTableRowHandle InputActionRow); // Function CommonUILegacy.CommonActivatablePanel.HasInputActionHandler // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2214d94
	bool GetInputActions(struct TArray<struct FCommonInputActionHandlerData> InputActionDataRows); // Function CommonUILegacy.CommonActivatablePanel.GetInputActions // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b7e0c
	void EndOutro(); // Function CommonUILegacy.CommonActivatablePanel.EndOutro // (Final|Native|Protected|BlueprintCallable) // @ game+0x24018ac
	void EndIntro(); // Function CommonUILegacy.CommonActivatablePanel.EndIntro // (Final|Native|Protected|BlueprintCallable) // @ game+0x34b7c6c
	void BeginOutro(); // Function CommonUILegacy.CommonActivatablePanel.BeginOutro // (Final|Native|Public|BlueprintCallable) // @ game+0x34b7b34
	void BeginIntro(); // Function CommonUILegacy.CommonActivatablePanel.BeginIntro // (Final|Native|Public|BlueprintCallable) // @ game+0x34b7b20
	void AddInputActionNoHandler(struct UDataTable* DataTable, struct FName RowName); // Function CommonUILegacy.CommonActivatablePanel.AddInputActionNoHandler // (Final|Native|Public|BlueprintCallable) // @ game+0x34b79d8
	void AddInputActionHandlerWithProgressPopup(struct UDataTable* DataTable, struct FName RowName, struct FDelegate CommitedEvent, struct FDelegate ProgressEvent, struct UCommonPopupMenu* PopupMenu); // Function CommonUILegacy.CommonActivatablePanel.AddInputActionHandlerWithProgressPopup // (Final|Native|Public|BlueprintCallable) // @ game+0x34b77a4
	void AddInputActionHandlerWithProgress(struct UDataTable* DataTable, struct FName RowName, struct FDelegate CommitedEvent, struct FDelegate ProgressEvent); // Function CommonUILegacy.CommonActivatablePanel.AddInputActionHandlerWithProgress // (Final|Native|Public|BlueprintCallable) // @ game+0x34b75ec
	void AddInputActionHandlerWithPopup(struct UDataTable* DataTable, struct FName RowName, struct FDelegate CommitedEvent, struct UCommonPopupMenu* PopupMenu); // Function CommonUILegacy.CommonActivatablePanel.AddInputActionHandlerWithPopup // (Final|Native|Public|BlueprintCallable) // @ game+0x34b7404
	void AddInputActionHandler(struct UDataTable* DataTable, struct FName RowName, struct FDelegate CommitedEvent); // Function CommonUILegacy.CommonActivatablePanel.AddInputActionHandler // (Final|Native|Public|BlueprintCallable) // @ game+0x34b72b4
};

// Class CommonUILegacy.CommonButton
// Size: 0xbf0 (Inherited: 0xba0)
struct UCommonButton : UCommonButtonBase {
	struct FMulticastInlineDelegate OnSelectedChanged; // 0xba0(0x10)
	struct FMulticastInlineDelegate OnButtonClicked; // 0xbb0(0x10)
	struct FMulticastInlineDelegate OnButtonDoubleClicked; // 0xbc0(0x10)
	struct FMulticastInlineDelegate OnButtonHovered; // 0xbd0(0x10)
	struct FMulticastInlineDelegate OnButtonUnhovered; // 0xbe0(0x10)

	void SetTriggeredInputActionLegacy(struct FDataTableRowHandle InputActionRow, struct UCommonActivatablePanel* OldPanel); // Function CommonUILegacy.CommonButton.SetTriggeredInputActionLegacy // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34b99cc
	void HandleOnSelectedChanged(struct UCommonButtonBase* Button, bool InSelected); // Function CommonUILegacy.CommonButton.HandleOnSelectedChanged // (Final|Native|Protected) // @ game+0x1512518
	void HandleOnButtonUnhovered(struct UCommonButtonBase* Button); // Function CommonUILegacy.CommonButton.HandleOnButtonUnhovered // (Final|Native|Protected) // @ game+0x1510dec
	void HandleOnButtonHovered(struct UCommonButtonBase* Button); // Function CommonUILegacy.CommonButton.HandleOnButtonHovered // (Final|Native|Protected) // @ game+0x1510ed8
	void HandleOnButtonDoubleClicked(struct UCommonButtonBase* Button); // Function CommonUILegacy.CommonButton.HandleOnButtonDoubleClicked // (Final|Native|Protected) // @ game+0x34b84b4
	void HandleOnButtonClicked(struct UCommonButtonBase* Button); // Function CommonUILegacy.CommonButton.HandleOnButtonClicked // (Final|Native|Protected) // @ game+0x151265c
};

// Class CommonUILegacy.CommonButtonInternal
// Size: 0x488 (Inherited: 0x488)
struct UCommonButtonInternal : UCommonButtonInternalBase {
};

// Class CommonUILegacy.CommonButtonGroup
// Size: 0x1b0 (Inherited: 0x110)
struct UCommonButtonGroup : UCommonButtonGroupBase {
	struct FMulticastInlineDelegate OnSelectedButtonChanged; // 0x110(0x10)
	char UnknownData_120[0x18]; // 0x120(0x18)
	struct FMulticastInlineDelegate OnHoveredButtonChanged; // 0x138(0x10)
	char UnknownData_148[0x18]; // 0x148(0x18)
	struct FMulticastInlineDelegate OnButtonClicked; // 0x160(0x10)
	char UnknownData_170[0x18]; // 0x170(0x18)
	struct FMulticastInlineDelegate OnButtonDoubleClicked; // 0x188(0x10)
	char UnknownData_198[0x18]; // 0x198(0x18)

	void OnSelectionStateChanged(struct UCommonButton* BaseButton, bool bIsSelected); // Function CommonUILegacy.CommonButtonGroup.OnSelectionStateChanged // (Native|Protected) // @ game+0x2a15ba0
	void OnHandleButtonDoubleClicked(struct UCommonButton* BaseButton); // Function CommonUILegacy.CommonButtonGroup.OnHandleButtonDoubleClicked // (Native|Protected) // @ game+0x2a15b10
	void OnHandleButtonClicked(struct UCommonButton* BaseButton); // Function CommonUILegacy.CommonButtonGroup.OnHandleButtonClicked // (Native|Protected) // @ game+0x2a15a80
	void OnButtonUnhovered(struct UCommonButton* BaseButton); // Function CommonUILegacy.CommonButtonGroup.OnButtonUnhovered // (Native|Protected) // @ game+0x2a159f0
	void OnButtonHovered(struct UCommonButton* BaseButton); // Function CommonUILegacy.CommonButtonGroup.OnButtonHovered // (Native|Protected) // @ game+0x2a15960
	void HandleOnSelectedButtonChanged(struct UCommonButtonBase* BaseButton, int32_t InSelectedButtonIndex); // Function CommonUILegacy.CommonButtonGroup.HandleOnSelectedButtonChanged // (Final|Native|Protected) // @ game+0x1512890
	void HandleOnHoveredButtonChanged(struct UCommonButtonBase* BaseButton, int32_t InSelectedButtonIndex); // Function CommonUILegacy.CommonButtonGroup.HandleOnHoveredButtonChanged // (Final|Native|Protected) // @ game+0x1512ab4
	void HandleOnButtonDoubleClicked(struct UCommonButtonBase* BaseButton, int32_t InSelectedButtonIndex); // Function CommonUILegacy.CommonButtonGroup.HandleOnButtonDoubleClicked // (Final|Native|Protected) // @ game+0x34b8550
	void HandleOnButtonClicked(struct UCommonButtonBase* BaseButton, int32_t InSelectedButtonIndex); // Function CommonUILegacy.CommonButtonGroup.HandleOnButtonClicked // (Final|Native|Protected) // @ game+0x1e2b7fc
	void HandleNativeOnSelectedButtonChanged(struct UCommonButtonBase* BaseButton, int32_t InSelectedButtonIndex); // Function CommonUILegacy.CommonButtonGroup.HandleNativeOnSelectedButtonChanged // (Final|Native|Protected) // @ game+0x34b83cc
	void HandleNativeOnHoveredButtonChanged(struct UCommonButtonBase* BaseButton, int32_t InSelectedButtonIndex); // Function CommonUILegacy.CommonButtonGroup.HandleNativeOnHoveredButtonChanged // (Final|Native|Protected) // @ game+0x34b82e4
	void HandleNativeOnButtonDoubleClicked(struct UCommonButtonBase* BaseButton, int32_t InSelectedButtonIndex); // Function CommonUILegacy.CommonButtonGroup.HandleNativeOnButtonDoubleClicked // (Final|Native|Protected) // @ game+0x34b81fc
	void HandleNativeOnButtonClicked(struct UCommonButtonBase* BaseButton, int32_t InSelectedButtonIndex); // Function CommonUILegacy.CommonButtonGroup.HandleNativeOnButtonClicked // (Final|Native|Protected) // @ game+0x34b8114
	struct UCommonButton* GetSelectedButton(); // Function CommonUILegacy.CommonButtonGroup.GetSelectedButton // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b7ef8
	struct UCommonButton* GetButtonAtIndex(int32_t Index); // Function CommonUILegacy.CommonButtonGroup.GetButtonAtIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b7d3c
	struct UCommonButtonGroup* CreateButtonGroup(struct UObject* ContextObject, bool bInSelectionRequired); // Function CommonUILegacy.CommonButtonGroup.CreateButtonGroup // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x34b7b48
};

// Class CommonUILegacy.CommonGlobalInputHandler
// Size: 0x70 (Inherited: 0x28)
struct UCommonGlobalInputHandler : UObject {
	char UnknownData_28[0x48]; // 0x28(0x48)
};

// Class CommonUILegacy.CommonInputManager
// Size: 0x108 (Inherited: 0x28)
struct UCommonInputManager : UObject {
	char UnknownData_28[0x80]; // 0x28(0x80)
	struct TScriptInterface<None> CurrentlyHeldActionInputHandler; // 0xa8(0x10)
	struct TArray<struct UCommonActivatablePanel*> ActivatablePanelStack; // 0xb8(0x10)
	struct UCommonGlobalInputHandler* GlobalInputHandler; // 0xc8(0x08)
	char UnknownData_D0[0x18]; // 0xd0(0x18)
	struct TArray<struct FOperation> Operations; // 0xe8(0x10)
	char UnknownData_F8[0x10]; // 0xf8(0x10)

	void SuspendStartingOperationProcessing(); // Function CommonUILegacy.CommonInputManager.SuspendStartingOperationProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0x34b9e0c
	bool StopListeningForExistingHeldAction(struct FDataTableRowHandle InputActionDataRow, struct FDelegate CompleteEvent, struct FDelegate ProgressEvent); // Function CommonUILegacy.CommonInputManager.StopListeningForExistingHeldAction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34b9c6c
	bool StartListeningForExistingHeldAction(struct FDataTableRowHandle InputActionDataRow, struct FDelegate CompleteEvent, struct FDelegate ProgressEvent); // Function CommonUILegacy.CommonInputManager.StartListeningForExistingHeldAction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34b9acc
	void SetGlobalInputHandlerPriorityFilter(int32_t InFilterPriority); // Function CommonUILegacy.CommonInputManager.SetGlobalInputHandlerPriorityFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x34b93bc
	void ResumeStartingOperationProcessing(); // Function CommonUILegacy.CommonInputManager.ResumeStartingOperationProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8bb8
	void PushActivatablePanel(struct UCommonActivatablePanel* ActivatablePanel, bool bIntroPanel, bool bOutroPanelBelow); // Function CommonUILegacy.CommonInputManager.PushActivatablePanel // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8908
	void PopActivatablePanel(struct UCommonActivatablePanel* ActivatablePanel); // Function CommonUILegacy.CommonInputManager.PopActivatablePanel // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8830
	bool IsPanelOnStack(struct UCommonActivatablePanel* InPanel); // Function CommonUILegacy.CommonInputManager.IsPanelOnStack // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b86c4
	bool IsInputSuspended(); // Function CommonUILegacy.CommonInputManager.IsInputSuspended // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b8680
	struct UCommonActivatablePanel* GetTopPanel(); // Function CommonUILegacy.CommonInputManager.GetTopPanel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b8050
	int32_t GetGlobalInputHandlerPriorityFilter(); // Function CommonUILegacy.CommonInputManager.GetGlobalInputHandlerPriorityFilter // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b7de4
	bool GetAvailableInputActions(struct TArray<struct FCommonInputActionHandlerData> AvailableInputActions); // Function CommonUILegacy.CommonInputManager.GetAvailableInputActions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34b7c80
};

// Class CommonUILegacy.CommonInputReflector
// Size: 0x2b8 (Inherited: 0x288)
struct UCommonInputReflector : UCommonUserWidget {
	struct UCommonButton* ButtonType; // 0x288(0x08)
	struct TArray<struct UCommonButton*> ActiveButtons; // 0x290(0x10)
	struct TArray<struct UCommonButton*> InactiveButtons; // 0x2a0(0x10)
	char UnknownData_2B0[0x8]; // 0x2b0(0x08)

	void OnButtonAdded(struct UCommonButton* AddedButton, struct FCommonInputActionHandlerData Data); // Function CommonUILegacy.CommonInputReflector.OnButtonAdded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
};

// Class CommonUILegacy.CommonPopupButton
// Size: 0xc00 (Inherited: 0xbf0)
struct UCommonPopupButton : UCommonButton {
	struct UMenuAnchor* PopupMenuAnchor; // 0xbf0(0x08)
	struct UCommonPopupMenu* PopupMenu; // 0xbf8(0x08)

	struct UUserWidget* GetMenuAnchorWidget(); // Function CommonUILegacy.CommonPopupButton.GetMenuAnchorWidget // (Final|Native|Private) // @ game+0x34b7ee0
};

// Class CommonUILegacy.CommonPopupMenu
// Size: 0x470 (Inherited: 0x458)
struct UCommonPopupMenu : UCommonActivatablePanel {
	bool bUseInputStack; // 0x458(0x01)
	char UnknownData_459[0x3]; // 0x459(0x03)
	struct FWeakObjectPtr<struct UMenuAnchor> OwningMenuAnchor; // 0x45c(0x08)
	struct FWeakObjectPtr<struct UObject> ContextProvidingObject; // 0x464(0x08)
	char UnknownData_46C[0x4]; // 0x46c(0x04)

	void SetOwningMenuAnchor(struct UMenuAnchor* MenuAnchor); // Function CommonUILegacy.CommonPopupMenu.SetOwningMenuAnchor // (Final|Native|Public|BlueprintCallable) // @ game+0x34b9930
	void SetContextProvider(struct UObject* ContextProvidingObject); // Function CommonUILegacy.CommonPopupMenu.SetContextProvider // (Final|Native|Public|BlueprintCallable) // @ game+0x34b9320
	void RequestClose(); // Function CommonUILegacy.CommonPopupMenu.RequestClose // (Final|Native|Protected|BlueprintCallable) // @ game+0x34b8ba4
	void OnIsOpenChanged(bool IsOpen); // Function CommonUILegacy.CommonPopupMenu.OnIsOpenChanged // (Final|Native|Protected) // @ game+0x34b8794
	void HandlePreDifferentContextProviderSet(); // Function CommonUILegacy.CommonPopupMenu.HandlePreDifferentContextProviderSet // (Native|Event|Protected|BlueprintEvent) // @ game+0x34b8650
	void HandlePostDifferentContextProviderSet(); // Function CommonUILegacy.CommonPopupMenu.HandlePostDifferentContextProviderSet // (Native|Event|Protected|BlueprintEvent) // @ game+0x34b8638
};

// Class CommonUILegacy.CommonTabListWidget
// Size: 0x378 (Inherited: 0x358)
struct UCommonTabListWidget : UCommonTabListWidgetBase {
	struct FMulticastInlineDelegate OnTabButtonCreated; // 0x358(0x10)
	struct FMulticastInlineDelegate OnTabButtonRemoved; // 0x368(0x10)

	void OnTabButtonRemoved__DelegateSignature(struct FName TabId, struct UCommonButton* TabButton); // DelegateFunction CommonUILegacy.CommonTabListWidget.OnTabButtonRemoved__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0xbd830c
	void OnTabButtonCreated__DelegateSignature(struct FName TabId, struct UCommonButton* TabButton); // DelegateFunction CommonUILegacy.CommonTabListWidget.OnTabButtonCreated__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0xbd830c
	void HandleTabRemoved(struct FName TabNameID, struct UCommonButton* TabButton); // Function CommonUILegacy.CommonTabListWidget.HandleTabRemoved // (Native|Event|Protected|BlueprintEvent) // @ game+0x1b6cae0
	void HandleTabCreated(struct FName TabNameID, struct UCommonButton* TabButton); // Function CommonUILegacy.CommonTabListWidget.HandleTabCreated // (Native|Event|Protected|BlueprintEvent) // @ game+0x140dea0
	void HandleOnTabButtonRemoved(struct FName TabId, struct UCommonButtonBase* TabButton); // Function CommonUILegacy.CommonTabListWidget.HandleOnTabButtonRemoved // (Final|Native|Protected) // @ game+0x15109dc
	void HandleOnTabButtonCreated(struct FName TabId, struct UCommonButtonBase* TabButton); // Function CommonUILegacy.CommonTabListWidget.HandleOnTabButtonCreated // (Final|Native|Protected) // @ game+0x1510acc
	struct UCommonButton* GetTabButtonByID(struct FName TabNameID); // Function CommonUILegacy.CommonTabListWidget.GetTabButtonByID // (Final|Native|Protected|BlueprintCallable) // @ game+0x34b7f4c
};

// Class CommonUILegacy.CommonUIActionRouter
// Size: 0x108 (Inherited: 0x100)
struct UCommonUIActionRouter : UCommonUIActionRouterBase {
	char UnknownData_100[0x8]; // 0x100(0x08)
};

// Class CommonUILegacy.CommonUISubsystem
// Size: 0x70 (Inherited: 0x40)
struct UCommonUISubsystem : UCommonUISubsystemBase {
	struct FMulticastInlineDelegate OnInputSuspensionChanged; // 0x40(0x10)
	struct UCommonInputManager* CommonInputManager; // 0x50(0x08)
	char UnknownData_58[0x18]; // 0x58(0x18)

	void InputSuspensionChanged__DelegateSignature(bool bInputSuspended); // DelegateFunction CommonUILegacy.CommonUISubsystem.InputSuspensionChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0xbd830c
	struct UCommonInputManager* GetInputManager(); // Function CommonUILegacy.CommonUISubsystem.GetInputManager // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34b7ec8
};

// Class CommonUILegacy.CommonWidgetStack
// Size: 0x168 (Inherited: 0x168)
struct UCommonWidgetStack : UCommonVisibilitySwitcher {

	void PushWidget(struct UWidget* InWidget); // Function CommonUILegacy.CommonWidgetStack.PushWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x34b8a4c
	struct UWidget* PopWidget(); // Function CommonUILegacy.CommonWidgetStack.PopWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x34b88e4
	void DeactivateWidget(); // Function CommonUILegacy.CommonWidgetStack.DeactivateWidget // (Final|Native|Protected|BlueprintCallable) // @ game+0x34b7c40
	void ActivateWidget(); // Function CommonUILegacy.CommonWidgetStack.ActivateWidget // (Final|Native|Protected|BlueprintCallable) // @ game+0x34b72a0
};

// Class CommonUILegacy.CommonWidgetSwitcher
// Size: 0x1b8 (Inherited: 0x190)
struct UCommonWidgetSwitcher : UCommonAnimatedSwitcher {
	struct FMulticastInlineDelegate OnActiveWidgetDeactivated; // 0x190(0x10)
	struct FMulticastInlineDelegate OnActiveWidgetChanged; // 0x1a0(0x10)
	char UnknownData_1B0[0x1]; // 0x1b0(0x01)
	bool bWidgetActivationEnabled; // 0x1b1(0x01)
	bool bOutroPanelBelow; // 0x1b2(0x01)
	char UnknownData_1B3[0x5]; // 0x1b3(0x05)

	void SetActiveWidgetIndex_Advanced(int32_t Index, bool AttemptActivationChange); // Function CommonUILegacy.CommonWidgetSwitcher.SetActiveWidgetIndex_Advanced // (Final|Native|Public|BlueprintCallable) // @ game+0x34b9144
	void SetActiveWidget_Advanced(struct UWidget* Widget, bool AttemptActivationChange); // Function CommonUILegacy.CommonWidgetSwitcher.SetActiveWidget_Advanced // (Final|Native|Public|BlueprintCallable) // @ game+0x34b922c
	void HandleActiveWidgetDeactivated(struct UCommonActivatablePanel* DeactivatedPanel); // Function CommonUILegacy.CommonWidgetSwitcher.HandleActiveWidgetDeactivated // (Final|Native|Private) // @ game+0x34b8070
	void DeactivateWidget(); // Function CommonUILegacy.CommonWidgetSwitcher.DeactivateWidget // (Native|Public|BlueprintCallable) // @ game+0x34b7c54
	void ActivateWidget(); // Function CommonUILegacy.CommonWidgetSwitcher.ActivateWidget // (Native|Public|BlueprintCallable) // @ game+0x153e8cc
};

