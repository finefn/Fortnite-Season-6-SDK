// BlueprintGeneratedClass B_BasePetInstance.B_BasePetInstance_C
// Size: 0x2a8 (Inherited: 0x298)
struct AB_BasePetInstance_C : AFortPlayerPet {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)
	struct UAnimInstance* LinkedLayerAnimClass; // 0x2a0(0x08)

	void PetMaterialsOverride(); // Function B_BasePetInstance.B_BasePetInstance_C.PetMaterialsOverride // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_BasePetInstance.B_BasePetInstance_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_BasePetInstance(int32_t EntryPoint); // Function B_BasePetInstance.B_BasePetInstance_C.ExecuteUbergraph_B_BasePetInstance // (Final|UbergraphFunction) // @ game+0xbd830c
};

