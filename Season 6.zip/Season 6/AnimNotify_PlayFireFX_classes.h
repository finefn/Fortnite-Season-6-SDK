// BlueprintGeneratedClass AnimNotify_PlayFireFX.AnimNotify_PlayFireFX_C
// Size: 0x38 (Inherited: 0x38)
struct UAnimNotify_PlayFireFX_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_PlayFireFX.AnimNotify_PlayFireFX_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
};

