// BlueprintGeneratedClass B_Prj_Arrow_Flame_Athena.B_Prj_Arrow_Flame_Athena_C
// Size: 0xcd4 (Inherited: 0xc38)
struct AB_Prj_Arrow_Flame_Athena_C : AB_Prj_Athena_Arrow_Generic_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc38(0x08)
	struct ABuildingGameplayActor* FireMeshActorClass; // 0xc40(0x08)
	struct FScalableFloat Row_FireMagnitude; // 0xc48(0x28)
	struct FScalableFloat Row_PropagationFuel; // 0xc70(0x28)
	struct FScalableFloat Row_IgnitionRadius; // 0xc98(0x28)
	float DirectFireApplicationDelay; // 0xcc0(0x04)
	bool FireballClass; // 0xcc4(0x01)
	char UnknownData_CC5[0x3]; // 0xcc5(0x03)
	struct FRotator ZeroRotator; // 0xcc8(0x0c)

	void OnFullyChargedImpact(struct FHitResult Hit Result); // Function B_Prj_Arrow_Flame_Athena.B_Prj_Arrow_Flame_Athena_C.OnFullyChargedImpact // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Arrow_Flame_Athena(int32_t EntryPoint); // Function B_Prj_Arrow_Flame_Athena.B_Prj_Arrow_Flame_Athena_C.ExecuteUbergraph_B_Prj_Arrow_Flame_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

