// SolarisGeneratedClass Core_TimeUtil.Context_TimeUtil_wait
// Size: 0x9c (Inherited: 0x98)
struct UContext_TimeUtil_wait : UCoroutineContext {
	float __verse_0x06F35629_seconds; // 0x98(0x04)

	int32_t Update(); // Function Core_TimeUtil.Context_TimeUtil_wait.Update // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed63b0
};

// SolarisGeneratedClass Core_TimeUtil.Context_TimeUtil_waitForever
// Size: 0x98 (Inherited: 0x98)
struct UContext_TimeUtil_waitForever : UCoroutineContext {

	int32_t Update(); // Function Core_TimeUtil.Context_TimeUtil_waitForever.Update // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6374
};

// SolarisGeneratedClass Core_TimeUtil.Context_TimeUtil_waitNext
// Size: 0x98 (Inherited: 0x98)
struct UContext_TimeUtil_waitNext : UCoroutineContext {

	int32_t Update(); // Function Core_TimeUtil.Context_TimeUtil_waitNext.Update // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed638c
};

// SolarisGeneratedClass Core_TimeUtil.TimeUtil
// Size: 0x28 (Inherited: 0x28)
struct UTimeUtil : UObject {

	float GetServerTime(); // Function Core_TimeUtil.TimeUtil.GetServerTime // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6d30
	void $InitInstance(); // Function Core_TimeUtil.TimeUtil.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Core_TimeUtil.TimeUtil.$InitCDO // () // @ game+0xbd830c
};

