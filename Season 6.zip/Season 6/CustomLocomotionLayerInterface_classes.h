// AnimBlueprintGeneratedClass CustomLocomotionLayerInterface.CustomLocomotionLayerInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UCustomLocomotionLayerInterface_C : UAnimLayerInterface {

	void CustomLocomotionFullBodyAdditive(struct FPoseLink InPoseFullBodyAdditive, struct FPoseLink CustomLocomotionFullBodyAdditive); // Function CustomLocomotionLayerInterface.CustomLocomotionLayerInterface_C.CustomLocomotionFullBodyAdditive // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CustomLocomotionPreIKLayer(struct FPoseLink InPosePreIK, struct FPoseLink CustomLocomotionPreIKLayer); // Function CustomLocomotionLayerInterface.CustomLocomotionLayerInterface_C.CustomLocomotionPreIKLayer // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CustomLocomotionFullBodyLayer(struct FPoseLink PassThroughCustomFullBody, struct FPoseLink CustomLocomotionFullBodyLayer); // Function CustomLocomotionLayerInterface.CustomLocomotionLayerInterface_C.CustomLocomotionFullBodyLayer // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

