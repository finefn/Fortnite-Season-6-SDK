// BlueprintGeneratedClass Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C
// Size: 0x28 (Inherited: 0x28)
struct UAthena_IGiveSneakySnowman_C : UInterface {

	void GetMaterialInt(int32_t MatInt); // Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.GetMaterialInt // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnParticles(); // Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.SpawnParticles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetNewSnowmanTransform(struct FTransform Transform); // Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.GetNewSnowmanTransform // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnTookSneakySnowman(); // Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.OnTookSneakySnowman // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStartedJumpingIn(); // Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.OnStartedJumpingIn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void MovePlayer(struct AActor* Player); // Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.MovePlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnGaveSneakySnowman(); // Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.OnGaveSneakySnowman // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

