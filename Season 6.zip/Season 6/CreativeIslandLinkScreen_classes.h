// WidgetBlueprintGeneratedClass CreativeIslandLinkScreen.CreativeIslandLinkScreen_C
// Size: 0x668 (Inherited: 0x5c8)
struct UCreativeIslandLinkScreen_C : UFortCreativeIslandLinkScreen {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5c8(0x08)
	struct UWidgetAnimation* Loading; // 0x5d0(0x08)
	struct UImage* Image_3; // 0x5d8(0x08)
	struct UImage* Image_IslandImage; // 0x5e0(0x08)
	struct UImage* Image_Shadow; // 0x5e8(0x08)
	struct UOverlay* IslandListContent; // 0x5f0(0x08)
	struct ULightningViolator_C* LightningViolator; // 0x5f8(0x08)
	struct UImage* MatchmakingSpinner; // 0x600(0x08)
	struct UOverlay* NoIslandsContent; // 0x608(0x08)
	struct UOverlay* Overlay_Violator; // 0x610(0x08)
	struct USafeZone* SafeZone_1; // 0x618(0x08)
	struct UCommonWidgetSwitcher* Switcher_IslandsList; // 0x620(0x08)
	struct UCommonTextBlock* Text_NoIslands; // 0x628(0x08)
	struct UCommonTextBlock* Text_WebURL; // 0x630(0x08)
	struct FLinearColor ViolatorColor_Error; // 0x638(0x10)
	struct FLinearColor ViolatorColor_Success; // 0x648(0x10)
	struct ABGA_IslandPortal_C* Portal; // 0x658(0x08)
	struct USoundBase* SelectPlotSound; // 0x660(0x08)

	void Construct(); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnIslandLinkEntryTextChanged(struct FText Text); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.OnIslandLinkEntryTextChanged // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnCreativeIslandLinksPopulated(); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.OnCreativeIslandLinksPopulated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void InitFromObject(struct UObject* InitObject); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.InitFromObject // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnAddedToActivationStack(); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.OnAddedToActivationStack // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Destruct(); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnCreativeIslandLinkValidated(enum class EFortCreativeIslandLinkValidationResult ValidateResult); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.OnCreativeIslandLinkValidated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnActivated(); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Button_Refresh_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.BndEvt__Button_Refresh_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CreativeIslandLinkScreen(int32_t EntryPoint); // Function CreativeIslandLinkScreen.CreativeIslandLinkScreen_C.ExecuteUbergraph_CreativeIslandLinkScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

