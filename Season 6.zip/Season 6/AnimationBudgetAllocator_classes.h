// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x39f33b8
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x39f32d0
};

// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xf10 (Inherited: 0xee0)
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	char UnknownData_EE0[0x20]; // 0xee0(0x20)
	char bAutoRegisterWithBudgetAllocator : 1; // 0xf00(0x01)
	char bAutoCalculateSignificance : 1; // 0xf00(0x01)
	char bShouldUseActorRenderedFlag : 1; // 0xf00(0x01)
	char UnknownData_F00_3 : 5; // 0xf00(0x01)
	char UnknownData_F01[0xf]; // 0xf01(0x0f)

	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator // (Final|Native|Public|BlueprintCallable) // @ game+0x39f34b4
};

