// BlueprintGeneratedClass B_Grenade_Playset_Athena.B_Grenade_Playset_Athena_C
// Size: 0xd60 (Inherited: 0xd49)
struct AB_Grenade_Playset_Athena_C : AB_Grenade_Tower_Athena_C {
	char UnknownData_D49[0x7]; // 0xd49(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd50(0x08)
	struct UFortPlaysetGrenadeInputComponent* AthenaPlaysetGrenadeInput; // 0xd58(0x08)

	void K2_OnUnEquip(); // Function B_Grenade_Playset_Athena.B_Grenade_Playset_Athena_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_Grenade_Playset_Athena.B_Grenade_Playset_Athena_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Grenade_Playset_Athena.B_Grenade_Playset_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Grenade_Playset_Athena(int32_t EntryPoint); // Function B_Grenade_Playset_Athena.B_Grenade_Playset_Athena_C.ExecuteUbergraph_B_Grenade_Playset_Athena // (Final|UbergraphFunction) // @ game+0xbd830c
};

