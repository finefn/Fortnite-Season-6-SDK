// BlueprintGeneratedClass Creative_Radio_AudioToMPC.Creative_Radio_AudioToMPC_C
// Size: 0x100 (Inherited: 0x100)
struct UCreative_Radio_AudioToMPC_C : UFortAudioToMPCComponent {

	void OnGatheredFFTData(struct TArray<struct FChannelData> FFTData, float OutAmplitudeAverage); // Function Creative_Radio_AudioToMPC.Creative_Radio_AudioToMPC_C.OnGatheredFFTData // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

