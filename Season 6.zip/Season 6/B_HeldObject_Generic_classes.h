// BlueprintGeneratedClass B_HeldObject_Generic.B_HeldObject_Generic_C
// Size: 0xd50 (Inherited: 0xd40)
struct AB_HeldObject_Generic_C : AFortWeapon {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd40(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0xd48(0x08)

	void ReceiveBeginPlay(); // Function B_HeldObject_Generic.B_HeldObject_Generic_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_HeldObject_Generic(int32_t EntryPoint); // Function B_HeldObject_Generic.B_HeldObject_Generic_C.ExecuteUbergraph_B_HeldObject_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

