// BlueprintGeneratedClass B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C
// Size: 0xa82 (Inherited: 0x998)
struct AB_Prj_Arrow_Athena_Parent_C : AFortProjectileAthena {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x998(0x08)
	struct UStaticMeshComponent* ArrowStaticMesh; // 0x9a0(0x08)
	struct UNiagaraComponent* NS_ProjectileTrail; // 0x9a8(0x08)
	struct UParticleSystemComponent* ProjectileTrail; // 0x9b0(0x08)
	struct UStaticMeshComponent* TracerStaticMesh; // 0x9b8(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x9c0(0x08)
	struct UParticleSystem* FX_WaterImpact; // 0x9c8(0x08)
	struct USoundBase* Sound_WaterImpact; // 0x9d0(0x08)
	bool DestroyOnHit; // 0x9d8(0x01)
	bool ExplodeOnDestroy; // 0x9d9(0x01)
	bool HideAndKill; // 0x9da(0x01)
	char UnknownData_9DB[0x1]; // 0x9db(0x01)
	struct FHitResult NullHit; // 0x9dc(0x88)
	float LifespanAfterHideAndKill; // 0xa64(0x04)
	float AutoDestroyLifespan; // 0xa68(0x04)
	float DrawDistance; // 0xa6c(0x04)
	struct UNiagaraSystem* NS_WaterImpact; // 0xa70(0x08)
	float TracerWPOMin; // 0xa78(0x04)
	float TracerWPOMax; // 0xa7c(0x04)
	bool bHideTracerOnImpact; // 0xa80(0x01)
	bool bDetachTracerOnHitWater; // 0xa81(0x01)

	void GetWaterImpactLocationForFX(struct FVector WaterSurfaceLocation, struct FVector ImpactLocation); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.GetWaterImpactLocationForFX // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void PreDestroyEvent(); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.PreDestroyEvent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_HideAndKill(); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.OnRep_HideAndKill // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Event_Building_Actor_Destroyed(); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.Event_Building_Actor_Destroyed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnTouched(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FHitResult HitResult, bool bIsOverlap); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.OnTouched // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void HideAndKillActor(); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.HideAndKillActor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ForceKill(); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.ForceKill // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayWaterImpactFX(struct UFortWaterInteractionComponent* WaterInteractionComponent); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.PlayWaterImpactFX // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Arrow_Athena_Parent(int32_t EntryPoint); // Function B_Prj_Arrow_Athena_Parent.B_Prj_Arrow_Athena_Parent_C.ExecuteUbergraph_B_Prj_Arrow_Athena_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

