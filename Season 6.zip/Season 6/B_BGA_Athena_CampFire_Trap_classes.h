// BlueprintGeneratedClass B_BGA_Athena_CampFire_Trap.B_BGA_Athena_CampFire_Trap_C
// Size: 0xac0 (Inherited: 0xab8)
struct AB_BGA_Athena_CampFire_Trap_C : AB_BGA_Athena_EnvCampFire_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xab8(0x08)

	void OnBuildingActorInitialized(enum class EFortBuildingInitializationReason InitializationReason, enum class EFortBuildingPersistentState BuildingPersistentState); // Function B_BGA_Athena_CampFire_Trap.B_BGA_Athena_CampFire_Trap_C.OnBuildingActorInitialized // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_BGA_Athena_CampFire_Trap(int32_t EntryPoint); // Function B_BGA_Athena_CampFire_Trap.B_BGA_Athena_CampFire_Trap_C.ExecuteUbergraph_B_BGA_Athena_CampFire_Trap // (Final|UbergraphFunction) // @ game+0xbd830c
};

