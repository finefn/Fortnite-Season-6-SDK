// SolarisGeneratedClass Components_DynamicActivationComponent.Context_DynamicActivationComponent_WaitForTransitionComplete
// Size: 0xa0 (Inherited: 0x98)
struct UContext_DynamicActivationComponent_WaitForTransitionComplete : UCoroutineContext {
	struct UDynamicActivationComponent* _Self; // 0x98(0x08)

	int32_t Update(); // Function Components_DynamicActivationComponent.Context_DynamicActivationComponent_WaitForTransitionComplete.Update // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed62e4
};

// SolarisGeneratedClass Components_DynamicActivationComponent.Context_DynamicActivationComponent_WaitForTransitionStart
// Size: 0xa0 (Inherited: 0x98)
struct UContext_DynamicActivationComponent_WaitForTransitionStart : UCoroutineContext {
	struct UDynamicActivationComponent* _Self; // 0x98(0x08)

	int32_t Update(); // Function Components_DynamicActivationComponent.Context_DynamicActivationComponent_WaitForTransitionStart.Update // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6308
};

// SolarisGeneratedClass Components_DynamicActivationComponent.DynamicActivationComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UDynamicActivationComponent : UEntityDynamicActivationComponent {
	char UnknownData_B8[0x18]; // 0xb8(0x18)

	void unlinkComponent(struct UEntityComponent* __verse_0xEE9D0EE3_componentToUnlink); // Function Components_DynamicActivationComponent.DynamicActivationComponent.unlinkComponent // (Native|Public|BlueprintCallable) // @ game+0x3ed741c
	void startTransition(float __verse_0xFD6BB246_secondsToChange, enum class ActivationState __verse_0xDE4C766A_targetState); // Function Components_DynamicActivationComponent.DynamicActivationComponent.startTransition // (Native|Public|BlueprintCallable) // @ game+0x3ed72c4
	void Reset(); // Function Components_DynamicActivationComponent.DynamicActivationComponent.Reset // (Native|Public|BlueprintCallable) // @ game+0x3ed7084
	void linkComponent(struct UEntityComponent* __verse_0x5F2F2619_componentToLink); // Function Components_DynamicActivationComponent.DynamicActivationComponent.linkComponent // (Native|Public|BlueprintCallable) // @ game+0x3ed6fb4
	void $InitInstance(); // Function Components_DynamicActivationComponent.DynamicActivationComponent.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Components_DynamicActivationComponent.DynamicActivationComponent.$InitCDO // () // @ game+0xbd830c
};

