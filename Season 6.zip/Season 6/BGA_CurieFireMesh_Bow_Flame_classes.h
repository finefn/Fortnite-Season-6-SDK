// BlueprintGeneratedClass BGA_CurieFireMesh_Bow_Flame.BGA_CurieFireMesh_Bow_Flame_C
// Size: 0x8e8 (Inherited: 0x868)
struct ABGA_CurieFireMesh_Bow_Flame_C : ABGA_GenericCurieFuel_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x868(0x08)
	struct FScalableFloat Row_FireMagnitude; // 0x870(0x28)
	struct FScalableFloat Row_PropagationFuel; // 0x898(0x28)
	struct FScalableFloat Row_IgnitionRadius; // 0x8c0(0x28)

	void ReceiveBeginPlay(); // Function BGA_CurieFireMesh_Bow_Flame.BGA_CurieFireMesh_Bow_Flame_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_CurieFireMesh_Bow_Flame(int32_t EntryPoint); // Function BGA_CurieFireMesh_Bow_Flame.BGA_CurieFireMesh_Bow_Flame_C.ExecuteUbergraph_BGA_CurieFireMesh_Bow_Flame // (Final|UbergraphFunction) // @ game+0xbd830c
};

