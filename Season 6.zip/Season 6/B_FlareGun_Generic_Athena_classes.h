// BlueprintGeneratedClass B_FlareGun_Generic_Athena.B_FlareGun_Generic_Athena_C
// Size: 0x12f0 (Inherited: 0x12dc)
struct AB_FlareGun_Generic_Athena_C : AB_Ranged_Generic_C {
	char UnknownData_12DC[0x4]; // 0x12dc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x12e0(0x08)
	struct UParticleSystemComponent* RearMuzzle; // 0x12e8(0x08)

	void Muzzle Flash FX(bool Persistent Fire); // Function B_FlareGun_Generic_Athena.B_FlareGun_Generic_Athena_C.Muzzle Flash FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_FlareGun_Generic_Athena(int32_t EntryPoint); // Function B_FlareGun_Generic_Athena.B_FlareGun_Generic_Athena_C.ExecuteUbergraph_B_FlareGun_Generic_Athena // (Final|UbergraphFunction) // @ game+0xbd830c
};

