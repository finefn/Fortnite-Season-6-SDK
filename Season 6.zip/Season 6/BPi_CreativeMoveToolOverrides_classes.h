// BlueprintGeneratedClass BPi_CreativeMoveToolOverrides.BPi_CreativeMoveToolOverrides_C
// Size: 0x28 (Inherited: 0x28)
struct UBPi_CreativeMoveToolOverrides_C : UInterface {

	void GetCreativeActorBounds(bool Override Bounds, struct FVector Bounds); // Function BPi_CreativeMoveToolOverrides.BPi_CreativeMoveToolOverrides_C.GetCreativeActorBounds // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetCreativeActorOrigin(bool Override, struct FVector Center); // Function BPi_CreativeMoveToolOverrides.BPi_CreativeMoveToolOverrides_C.GetCreativeActorOrigin // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

