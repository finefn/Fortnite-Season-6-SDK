// BlueprintGeneratedClass B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C
// Size: 0x930 (Inherited: 0x878)
struct AB_Prj_Athena_SneakySnowmanV2_C : AFortProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x878(0x08)
	struct USkeletalMeshComponent* SK_Sneaky_Snowman_Throw; // 0x880(0x08)
	struct UParticleSystemComponent* FX_Trail; // 0x888(0x08)
	struct UFortCollisionAudioComponent* FortCollisionAudio; // 0x890(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x898(0x08)
	struct UAudioComponent* Audio_InAir; // 0x8a0(0x08)
	struct USoundBase* Cue_HitPlayer; // 0x8a8(0x08)
	struct UFortWorldItemDefinition* SnowmanItemDef; // 0x8b0(0x08)
	bool HitPlayer; // 0x8b8(0x01)
	char UnknownData_8B9[0x7]; // 0x8b9(0x07)
	struct UGameplayEffect* GE_ApplyEnemySnowman; // 0x8c0(0x08)
	struct UParticleSystem* SnowmanSpawnFX; // 0x8c8(0x08)
	struct FScalableFloat ShouldSnowmanEnemies; // 0x8d0(0x28)
	struct USoundBase* SoundOnExplo; // 0x8f8(0x08)
	struct FVector HitLocation; // 0x900(0x0c)
	char UnknownData_90C[0x4]; // 0x90c(0x04)
	struct AActor* HitActor; // 0x910(0x08)
	struct TArray<struct UFortItem*> SnowmanItemInstances; // 0x918(0x10)
	struct AActor* PropClass; // 0x928(0x08)

	void UpdateQuest(struct AFortPlayerController* FortPC); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.UpdateQuest // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool ShouldApplySnowman?(struct UObject* PlayerPawn); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.ShouldApplySnowman? // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void Should Bounce?(struct FVector Hit Normal); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.Should Bounce? // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnTouched(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FHitResult HitResult, bool bIsOverlap); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.OnTouched // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Explode(); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.Explode // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void Apply Snowman To Self(); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.Apply Snowman To Self // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_SneakySnowmanV2(int32_t EntryPoint); // Function B_Prj_Athena_SneakySnowmanV2.B_Prj_Athena_SneakySnowmanV2_C.ExecuteUbergraph_B_Prj_Athena_SneakySnowmanV2 // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

