// BlueprintGeneratedClass B_Prj_Petrol.B_Prj_Petrol_C
// Size: 0x988 (Inherited: 0x8b0)
struct AB_Prj_Petrol_C : AFortProjectilePetrol {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8b0(0x08)
	struct UParticleSystemComponent* P_Petrol_Prj_Trail; // 0x8b8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x8c0(0x08)
	struct FGameplayTagContainer RefillableVehicleTag; // 0x8c8(0x20)
	struct ABGA_Petrol_Pickup_C* ClosestPetrolPickupBGA; // 0x8e8(0x08)
	struct ABGA_Petrol_Pickup_C* NullBGA; // 0x8f0(0x08)
	float ShortestDistance; // 0x8f8(0x04)
	int32_t ClosestPetrolPickupBGAIndex; // 0x8fc(0x04)
	struct TArray<struct AActor*> HitActors; // 0x900(0x10)
	struct FScalableFloat OverrideFuelToAddToPetrolPickup; // 0x910(0x28)
	int32_t FuelToAddToPetrolPickup; // 0x938(0x04)
	char UnknownData_93C[0x4]; // 0x93c(0x04)
	struct FGameplayTagContainer T_Quest; // 0x940(0x20)
	struct FScalableFloat Hotfix_RefillVehicleAmount; // 0x960(0x28)

	void UserConstructionScript(); // Function B_Prj_Petrol.B_Prj_Petrol_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStop(struct FHitResult Hit); // Function B_Prj_Petrol.B_Prj_Petrol_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Petrol.B_Prj_Petrol_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Petrol.B_Prj_Petrol_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function B_Prj_Petrol.B_Prj_Petrol_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // Function B_Prj_Petrol.B_Prj_Petrol_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Petrol(int32_t EntryPoint); // Function B_Prj_Petrol.B_Prj_Petrol_C.ExecuteUbergraph_B_Prj_Petrol // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

