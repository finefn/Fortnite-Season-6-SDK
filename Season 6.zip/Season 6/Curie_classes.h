// Class Curie.CurieComponent
// Size: 0xe0 (Inherited: 0xb0)
struct UCurieComponent : UActorComponent {
	char UnknownData_B0[0x8]; // 0xb0(0x08)
	struct FGameplayTag Identifier; // 0xb8(0x08)
	enum class ECurieEntityType EntityType; // 0xc0(0x01)
	char UnknownData_C1[0x1f]; // 0xc1(0x1f)

	bool IsInteractingWithElement(struct FGameplayTag Element); // Function Curie.CurieComponent.IsInteractingWithElement // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x34d0f24
	bool HasStateAttached(struct FGameplayTag StateIdentifier); // Function Curie.CurieComponent.HasStateAttached // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34d0e74
	bool HasElementAttached(struct FGameplayTag ElementIdentifier); // Function Curie.CurieComponent.HasElementAttached // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34d0dcc
	bool HasAnyElementAttached(struct FGameplayTagContainer ElementIdentifiers); // Function Curie.CurieComponent.HasAnyElementAttached // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34d0c94
	void HandleOwningActorDestroyed(struct AActor* Owner); // Function Curie.CurieComponent.HandleOwningActorDestroyed // (Native|Protected) // @ game+0x34d0bf4
};

// Class Curie.CurieElementBehavior
// Size: 0x98 (Inherited: 0x28)
struct UCurieElementBehavior : UObject {
	struct TArray<struct FCurieEffectContainer> OnBeginAttachmentEffects; // 0x28(0x10)
	struct TArray<struct FCurieEffectContainer> OngoingAttachmentEffects; // 0x38(0x10)
	struct TArray<struct FCurieEffectContainer> OnEndAttachmentEffects; // 0x48(0x10)
	struct TArray<struct FCurieEffectContainer> OnInstantInteractionEffects; // 0x58(0x10)
	struct TArray<struct FCurieEffectContainer> OnBeginInteractionEffects; // 0x68(0x10)
	struct TArray<struct FCurieEffectContainer> OngoingInteractionEffects; // 0x78(0x10)
	struct TArray<struct FCurieEffectContainer> OnEndInteractionEffects; // 0x88(0x10)
};

// Class Curie.CurieEntityStateBehavior
// Size: 0xc0 (Inherited: 0x28)
struct UCurieEntityStateBehavior : UObject {
	struct FGameplayTagContainer RequiredAttachedElements; // 0x28(0x20)
	struct FGameplayTagContainer RequiredInteractingElements; // 0x48(0x20)
	struct FGameplayTagContainer AllowedAttachmentEntityTypes; // 0x68(0x20)
	struct TArray<struct FCurieEffectContainer> OnBeginEffects; // 0x88(0x10)
	struct TArray<struct FCurieEffectContainer> OngoingEffects; // 0x98(0x10)
	struct TArray<struct FCurieEffectContainer> OnEndEffects; // 0xa8(0x10)
	char bIsConsumable : 1; // 0xb8(0x01)
	char bShouldDetach : 1; // 0xb8(0x01)
	char bSkipExecuteAttachDetach : 1; // 0xb8(0x01)
	char UnknownData_B8_3 : 5; // 0xb8(0x01)
	char UnknownData_B9[0x7]; // 0xb9(0x07)
};

// Class Curie.CurieGlobals
// Size: 0x50 (Inherited: 0x28)
struct UCurieGlobals : UObject {
	bool bEnableCurie; // 0x28(0x01)
	char UnknownData_29[0x7]; // 0x29(0x07)
	struct FSoftClassPath CurieGlobalsClassName; // 0x30(0x18)
	struct UCurieManager* RegisteredCurieManager; // 0x48(0x08)
};

// Class Curie.CurieInterface
// Size: 0x28 (Inherited: 0x28)
struct UCurieInterface : UInterface {

	void OnCurieStateDetached_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag StateTag); // Function Curie.CurieInterface.OnCurieStateDetached_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieStateConsumed_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag StateTag); // Function Curie.CurieInterface.OnCurieStateConsumed_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieStateAttached_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag StateTag); // Function Curie.CurieInterface.OnCurieStateAttached_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementInteractEnded_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag, struct FCurieInteractParamsHandle InteractParamsHandle); // Function Curie.CurieInterface.OnCurieElementInteractEnded_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementInteractBegun_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag, struct FCurieInteractParamsHandle InteractParamsHandle); // Function Curie.CurieInterface.OnCurieElementInteractBegun_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementInteract_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag, struct FCurieInteractParamsHandle InteractParamsHandle); // Function Curie.CurieInterface.OnCurieElementInteract_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementDetached_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag); // Function Curie.CurieInterface.OnCurieElementDetached_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementAttached_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag); // Function Curie.CurieInterface.OnCurieElementAttached_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieContainerShutdown_BP(struct FCurieContainerHandle CurieContainerHandle); // Function Curie.CurieInterface.OnCurieContainerShutdown_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieContainerInitialized_BP(struct FCurieContainerHandle CurieContainerHandle); // Function Curie.CurieInterface.OnCurieContainerInitialized_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
};

// Class Curie.CurieManager
// Size: 0x2e8 (Inherited: 0xb0)
struct UCurieManager : UGameStateComponent {
	struct UCurieComponent* CurieComponentClass; // 0xb0(0x08)
	struct FName MaterialDataRegistryName; // 0xb8(0x08)
	struct FName ElementDataRegistryName; // 0xc0(0x08)
	struct FName EntityStateDataRegistryName; // 0xc8(0x08)
	struct UDataTable* MaterialDefinitionsTable; // 0xd0(0x08)
	struct UDataTable* ElementDefinitionsTable; // 0xd8(0x08)
	struct UDataTable* EntityStateDefinitionsTable; // 0xe0(0x08)
	char UnknownData_E8[0x1f8]; // 0xe8(0x1f8)
	char UnknownData_2E0_0 : 1; // 0x2e0(0x01)
	char bUseDataRegistry : 1; // 0x2e0(0x01)
	char UnknownData_2E0_2 : 6; // 0x2e0(0x01)
	char UnknownData_2E1[0x7]; // 0x2e1(0x07)

	void UnbindDelegateForCurieStateDetached(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.UnbindDelegateForCurieStateDetached // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1d8ec24
	void UnbindDelegateForCurieStateAttached(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.UnbindDelegateForCurieStateAttached // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1d8eaa8
	void UnbindDelegateForCurieElementInteract(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.UnbindDelegateForCurieElementInteract // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d1b18
	void UnbindDelegateForCurieElementEndInteract(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.UnbindDelegateForCurieElementEndInteract // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d184c
	void UnbindDelegateForCurieElementDetached(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.UnbindDelegateForCurieElementDetached // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d1580
	void UnbindDelegateForCurieElementBeginInteract(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.UnbindDelegateForCurieElementBeginInteract // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d12b4
	void UnbindDelegateForCurieElementAttached(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.UnbindDelegateForCurieElementAttached // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d0fe8
	void BindDelegateForCurieStateDetached(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.BindDelegateForCurieStateDetached // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d09d0
	void BindDelegateForCurieStateAttached(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.BindDelegateForCurieStateAttached // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d07ac
	void BindDelegateForCurieElementInteract(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.BindDelegateForCurieElementInteract // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d0588
	void BindDelegateForCurieElementEndInteract(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.BindDelegateForCurieElementEndInteract // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d0364
	void BindDelegateForCurieElementDetached(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.BindDelegateForCurieElementDetached // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34d0140
	void BindDelegateForCurieElementBeginInteract(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.BindDelegateForCurieElementBeginInteract // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34cff1c
	void BindDelegateForCurieElementAttached(struct UObject* CurieOwner, struct FDelegate Delegate); // Function Curie.CurieManager.BindDelegateForCurieElementAttached // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34cfcf8
};

