// BlueprintGeneratedClass B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C
// Size: 0xbdc (Inherited: 0x898)
struct AB_Prj_Athena_GiftBox_C : AFortSuperTowerGrenadeProjectile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x898(0x08)
	struct UParticleSystemComponent* Trail; // 0x8a0(0x08)
	struct UStaticMeshComponent* Mesh; // 0x8a8(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x8b0(0x08)
	struct FVector BaseDestination; // 0x8b8(0x0c)
	char UnknownData_8C4[0x4]; // 0x8c4(0x04)
	struct UParticleSystem* P_BuildBuilding; // 0x8c8(0x08)
	struct USoundBase* Cue_CloseSound; // 0x8d0(0x08)
	struct USoundBase* Cue_DistantSound; // 0x8d8(0x08)
	struct FVector GridExplosionOffset; // 0x8e0(0x0c)
	float GridSizeXY; // 0x8ec(0x04)
	float GridSizeZ; // 0x8f0(0x04)
	float GridYOffset; // 0x8f4(0x04)
	float GridZOffset; // 0x8f8(0x04)
	enum class ECardinalDirection CardinalDirection; // 0x8fc(0x01)
	char UnknownData_8FD[0x3]; // 0x8fd(0x03)
	struct TMap<enum class ECardinalDirection, float> OrientationYawOffsets; // 0x900(0x50)
	struct TMap<enum class ECardinalDirection, struct FVector> OrientationLocationOffsets; // 0x950(0x50)
	bool IsDebug; // 0x9a0(0x01)
	char UnknownData_9A1[0x3]; // 0x9a1(0x03)
	float TracedActorBuildDelay; // 0x9a4(0x04)
	struct FVector BaseDestinationOffsetUnderground; // 0x9a8(0x0c)
	char UnknownData_9B4[0x4]; // 0x9b4(0x04)
	struct TArray<struct FVector> ClearedCells_Normal; // 0x9b8(0x10)
	struct FVector LastBounceLocation; // 0x9c8(0x0c)
	float MinBounceDistance; // 0x9d4(0x04)
	float LastBounceTime; // 0x9d8(0x04)
	float MinTimeBetweenBounces; // 0x9dc(0x04)
	struct USoundBase* BounceSound; // 0x9e0(0x08)
	struct TArray<struct FVector> ClearedCells_Underground; // 0x9e8(0x10)
	bool b_SpawnTracedActors; // 0x9f8(0x01)
	char UnknownData_9F9[0x7]; // 0x9f9(0x07)
	struct TArray<struct AActor*> BGAClasses_Traced; // 0xa00(0x10)
	struct TArray<struct FVector> BGALocations_Traced; // 0xa10(0x10)
	struct TArray<struct FRotator> BGARotations_Traced; // 0xa20(0x10)
	struct FVector DoorTraceOffsetHigh; // 0xa30(0x0c)
	struct FVector DoorTraceOffsetLow; // 0xa3c(0x0c)
	bool b_HitTerrain; // 0xa48(0x01)
	char UnknownData_A49[0x7]; // 0xa49(0x07)
	struct USoundBase* InAirLoopSound; // 0xa50(0x08)
	struct UAudioComponent* InAirLoopComponent; // 0xa58(0x08)
	float BounceTimeout; // 0xa60(0x04)
	char UnknownData_A64[0x4]; // 0xa64(0x04)
	struct AActor* BuilderClass; // 0xa68(0x08)
	struct AActor* BuilderClassBasement; // 0xa70(0x08)
	struct TArray<struct FVector> BGAScales_Traced; // 0xa78(0x10)
	struct FVector LootSpawnLocation; // 0xa88(0x0c)
	struct FRotator LootSpawnRotation; // 0xa94(0x0c)
	struct FVector QuestTraceExtentTall; // 0xaa0(0x0c)
	struct FVector QuestTraceExtent; // 0xaac(0x0c)
	struct FVector QuestTractOffsetTall; // 0xab8(0x0c)
	struct FVector QuestTraceOffset; // 0xac4(0x0c)
	struct AFortPlayerController* ControllerWhoThrew; // 0xad0(0x08)
	struct UFortQuestItemDefinition* QuestItem; // 0xad8(0x08)
	struct FName ObjBackendName; // 0xae0(0x08)
	struct USoundBase* QuestSuccessSound; // 0xae8(0x08)
	struct UParticleSystem* QuestSuccessEmitter; // 0xaf0(0x08)
	struct UParticleSystem* P_BuildBuilding_Tall; // 0xaf8(0x08)
	struct FVector Offset_ParticleSystem; // 0xb00(0x0c)
	struct FVector Offset_ParticleSystem_Tall; // 0xb0c(0x0c)
	struct USoundBase* ThrowSound; // 0xb18(0x08)
	struct FName Loot Table; // 0xb20(0x08)
	bool B Hit Water; // 0xb28(0x01)
	char UnknownData_B29[0x7]; // 0xb29(0x07)
	struct FGameplayTagContainer T_SourceTagsAmmo; // 0xb30(0x20)
	float SpawnDelay; // 0xb50(0x04)
	struct FHitResult Null Hit; // 0xb54(0x88)

	void CheckForGiftedTargets(struct FVector TraceLocation, struct FVector BoxExtent); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.CheckForGiftedTargets // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnProps(struct FVector ReferenceLocation); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.SpawnProps // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ClearOnly(struct TArray<struct FVector> ClearedGridCells, bool DestroyFloorsQuickly); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.ClearOnly // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CallDynamicBuilder(struct AActor* Class, struct FVector Location); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.CallDynamicBuilder // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CalculateCardinalDirection(); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.CalculateCardinalDirection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleProps(struct TArray<struct AActor*> Array); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.HandleProps // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnContents(struct FVector ReferenceLocation); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.SpawnContents // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ClearAndBuild(struct TArray<struct FVector> ClearedGridCells, struct TArray<struct AActor*> BGAClassArray, struct TArray<struct FVector> BGALocationArray, struct TArray<struct FRotator> BGARotationArray, bool DestroyFloorsQuickly); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.ClearAndBuild // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CreateBaseSection(struct FVector ReferenceLocation, struct TArray<struct AActor*> BGAClassArray, struct TArray<struct FVector> BGALocationArray, struct TArray<struct FRotator> BGARotationArray); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.CreateBaseSection // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetBaseDestination(struct FHitResult Hit); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.SetBaseDestination // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStop(struct FHitResult Hit); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Handle Bounce(struct FVector Hit Location); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.Handle Bounce // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Delete another actor(); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.Delete another actor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnBeginPlayQuestCheck(); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.OnBeginPlayQuestCheck // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Play Quest Success FX(); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.Play Quest Success FX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_2_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_2_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_GiftBox(int32_t EntryPoint); // Function B_Prj_Athena_GiftBox.B_Prj_Athena_GiftBox_C.ExecuteUbergraph_B_Prj_Athena_GiftBox // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

