// BlueprintGeneratedClass B_Prj_Arrow_ExplodeOnImpact_Athena_Parent.B_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C
// Size: 0xa18 (Inherited: 0x998)
struct AB_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C : AFortProjectileAthena {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x998(0x08)
	struct UParticleSystemComponent* ProjectileTrail; // 0x9a0(0x08)
	struct UStaticMeshComponent* TracerMesh; // 0x9a8(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x9b0(0x08)
	struct UAudioComponent* GrenadeFuse_AudioComponent; // 0x9b8(0x08)
	struct UParticleSystem* P_Explosion; // 0x9c0(0x08)
	struct USoundBase* Cue_DistantSound; // 0x9c8(0x08)
	struct USoundBase* Cue_CloseSound; // 0x9d0(0x08)
	struct FRotator HitRotation; // 0x9d8(0x0c)
	struct FVector HitLocation; // 0x9e4(0x0c)
	float DrawDistance; // 0x9f0(0x04)
	bool HitPlayer; // 0x9f4(0x01)
	char UnknownData_9F5[0x3]; // 0x9f5(0x03)
	struct FVector DecalSize; // 0x9f8(0x0c)
	struct FGameplayTag FeedbackCue; // 0xa04(0x08)
	char UnknownData_A0C[0x4]; // 0xa0c(0x04)
	struct UParticleSystem* WaterImpactFX; // 0xa10(0x08)

	void OnRep_HitLocation(); // Function B_Prj_Arrow_ExplodeOnImpact_Athena_Parent.B_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C.OnRep_HitLocation // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function B_Prj_Arrow_ExplodeOnImpact_Athena_Parent.B_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Event_Building_Actor_Destroyed(); // Function B_Prj_Arrow_ExplodeOnImpact_Athena_Parent.B_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C.Event_Building_Actor_Destroyed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Arrow_ExplodeOnImpact_Athena_Parent.B_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnTouched(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FHitResult HitResult, bool bIsOverlap); // Function B_Prj_Arrow_ExplodeOnImpact_Athena_Parent.B_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C.OnTouched // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Arrow_ExplodeOnImpact_Athena_Parent.B_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Arrow_ExplodeOnImpact_Athena_Parent(int32_t EntryPoint); // Function B_Prj_Arrow_ExplodeOnImpact_Athena_Parent.B_Prj_Arrow_ExplodeOnImpact_Athena_Parent_C.ExecuteUbergraph_B_Prj_Arrow_ExplodeOnImpact_Athena_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

