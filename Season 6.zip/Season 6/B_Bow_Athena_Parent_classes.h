// BlueprintGeneratedClass B_Bow_Athena_Parent.B_Bow_Athena_Parent_C
// Size: 0x13e8 (Inherited: 0x12dc)
struct AB_Bow_Athena_Parent_C : AB_Ranged_Generic_C {
	char UnknownData_12DC[0x4]; // 0x12dc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x12e0(0x08)
	struct UAudioComponent* Charge_AudioComponent; // 0x12e8(0x08)
	struct UAudioComponent* FullCharge_AudioComponent; // 0x12f0(0x08)
	struct AFortPlayerPawn* PlayerPawn; // 0x12f8(0x08)
	bool ReachedMaxCharge; // 0x1300(0x01)
	bool ReachedMinCharge; // 0x1301(0x01)
	bool Charging; // 0x1302(0x01)
	char UnknownData_1303[0x5]; // 0x1303(0x05)
	struct AFortProjectileBase* Prj_Dummy; // 0x1308(0x08)
	struct AFortProjectileBase* DummyProjectile; // 0x1310(0x08)
	float DummyExtent; // 0x1318(0x04)
	float DummyMaxSpeed; // 0x131c(0x04)
	float ProjectileVelocity; // 0x1320(0x04)
	float DummyFriction; // 0x1324(0x04)
	float DummyBouncieness; // 0x1328(0x04)
	float DummyGravity; // 0x132c(0x04)
	float DummyTimeStep; // 0x1330(0x04)
	enum class ECollisionChannel DummyCollisionChannel; // 0x1334(0x01)
	char UnknownData_1335[0x3]; // 0x1335(0x03)
	struct FScalableFloat Row_MaxProjectileSpeed; // 0x1338(0x28)
	struct AActor* TrajectoryClass; // 0x1360(0x08)
	struct ABP_ProjectileTrajectory_Bow_Generic_C* BowTrajectory; // 0x1368(0x08)
	struct FTimerHandle Timer_UpdateTrajectorySpline; // 0x1370(0x08)
	bool IsBowEquipped; // 0x1378(0x01)
	char UnknownData_1379[0x7]; // 0x1379(0x07)
	struct USoundBase* LowTensionFire; // 0x1380(0x08)
	struct USoundBase* NormalTensionFire; // 0x1388(0x08)
	struct USoundBase* FullTensionFire; // 0x1390(0x08)
	struct USoundBase* FullTensionFireP1; // 0x1398(0x08)
	struct USoundBase* LowTensionFireP1; // 0x13a0(0x08)
	struct USoundBase* NormalTensionFireP1; // 0x13a8(0x08)
	struct UParticleSystem* FX_AdditionalFire; // 0x13b0(0x08)
	struct UParticleSystem* FX_FullyCharge; // 0x13b8(0x08)
	struct USoundBase* Sound_OnCharge; // 0x13c0(0x08)
	struct UNiagaraSystem* NS_AdditionalFire; // 0x13c8(0x08)
	struct UNiagaraSystem* NS_FullyCHarge; // 0x13d0(0x08)
	struct UFXSystemComponent* FX_FullyCharged; // 0x13d8(0x08)
	struct USoundBase* Sound_OnFullyCharged; // 0x13e0(0x08)

	void SpawnFullyChargedFX(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.SpawnFullyChargedFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct USoundBase* GetChargedWeaponFireSound(enum class EFortWeaponSoundState Channel, bool bSecondaryFire); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.GetChargedWeaponFireSound // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	struct USoundBase* GetFireSoundToPlay(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.GetFireSoundToPlay // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetMaxChargeReachedAndPlayAudio(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.SetMaxChargeReachedAndPlayAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StopDrawAudio(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.StopDrawAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StartDrawAudio(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.StartDrawAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetupProjectileVariables(struct FVector StartLocation, struct FVector InitialVelocity, float ProjectileVelocity, struct FRotator OutRotation); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.SetupProjectileVariables // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void CalculateVelocity(float Velocity); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.CalculateVelocity // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void CalculateTrajectorySpline(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.CalculateTrajectorySpline // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetDummyVariables(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.SetDummyVariables // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetupTrajectoryProjectile(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.SetupTrajectoryProjectile // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnReachedMinCharge(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnReachedMinCharge // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnStartCharge(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnStartCharge // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void EndOfCharge(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.EndOfCharge // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void K2_OnUnEquip(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnChargeDown(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnChargeDown // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnChargeUp(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnChargeUp // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnEndCharge(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnEndCharge // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ResetCharge(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.ResetCharge // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void IncreaseDrawStrength(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.IncreaseDrawStrength // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveTick(float DeltaSeconds); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnReachedMaxCharge(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnReachedMaxCharge // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void DeactivateFullyChargedFX(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.DeactivateFullyChargedFX // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRemoteClientReachedMaxCharge(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnRemoteClientReachedMaxCharge // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnRemoteClientReachedMinCharge(); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.OnRemoteClientReachedMinCharge // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Bow_Athena_Parent(int32_t EntryPoint); // Function B_Bow_Athena_Parent.B_Bow_Athena_Parent_C.ExecuteUbergraph_B_Bow_Athena_Parent // (Final|UbergraphFunction) // @ game+0xbd830c
};

