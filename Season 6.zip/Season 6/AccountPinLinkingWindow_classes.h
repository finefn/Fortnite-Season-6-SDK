// WidgetBlueprintGeneratedClass AccountPinLinkingWindow.AccountPinLinkingWindow_C
// Size: 0x5e8 (Inherited: 0x5d0)
struct UAccountPinLinkingWindow_C : UFortAccountPinLinkingWindow {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5d0(0x08)
	struct UImage* Image_84; // 0x5d8(0x08)
	struct UImage* Image_256; // 0x5e0(0x08)

	void BndEvt__Switcher_Main_K2Node_ComponentBoundEvent_0_OnActiveWidgetChanged__DelegateSignature(struct UWidget* ActiveWidget, int32_t ActiveWidgetIndex); // Function AccountPinLinkingWindow.AccountPinLinkingWindow_C.BndEvt__Switcher_Main_K2Node_ComponentBoundEvent_0_OnActiveWidgetChanged__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AccountPinLinkingWindow(int32_t EntryPoint); // Function AccountPinLinkingWindow.AccountPinLinkingWindow_C.ExecuteUbergraph_AccountPinLinkingWindow // (Final|UbergraphFunction) // @ game+0xbd830c
};

