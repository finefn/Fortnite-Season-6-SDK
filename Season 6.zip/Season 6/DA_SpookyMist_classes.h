// BlueprintGeneratedClass DA_SpookyMist.DA_SpookyMist_C
// Size: 0xe08 (Inherited: 0xdc8)
struct ADA_SpookyMist_C : AFortCustomizableAbilityDecoTool {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xdc8(0x08)
	struct FTimerHandle CanCancelTimer; // 0xdd0(0x08)
	struct FScalableFloat CancelDelay; // 0xdd8(0x28)
	struct AFortPlayerPawn* PlayerPawn; // 0xe00(0x08)

	void BPPressSecondaryFire(struct AFortDecoHelper* FortDecoHelper); // Function DA_SpookyMist.DA_SpookyMist_C.BPPressSecondaryFire // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BPPressTrigger(struct AFortDecoHelper* FortDecoHelper); // Function DA_SpookyMist.DA_SpookyMist_C.BPPressTrigger // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BPOnUnEquip(); // Function DA_SpookyMist.DA_SpookyMist_C.BPOnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BPReleaseSecondaryFire(struct AFortDecoHelper* FortDecoHelper); // Function DA_SpookyMist.DA_SpookyMist_C.BPReleaseSecondaryFire // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void CanCancel(); // Function DA_SpookyMist.DA_SpookyMist_C.CanCancel // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function DA_SpookyMist.DA_SpookyMist_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void On DBNO(); // Function DA_SpookyMist.DA_SpookyMist_C.On DBNO // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_DA_SpookyMist(int32_t EntryPoint); // Function DA_SpookyMist.DA_SpookyMist_C.ExecuteUbergraph_DA_SpookyMist // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

