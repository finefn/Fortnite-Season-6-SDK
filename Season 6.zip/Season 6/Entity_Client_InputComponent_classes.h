// SolarisGeneratedClass Entity_Client_InputComponent.InputComponent
// Size: 0x68 (Inherited: 0x68)
struct UInputComponent : UEntityActorLocalInputComponent {

	void SetEnabled(char __verse_0x5CDFC2A5_Enabled); // Function Entity_Client_InputComponent.InputComponent.SetEnabled // (Native|Public|BlueprintCallable) // @ game+0x3ed711c
	void setAutoReceiveInput(enum class LocalControllerSlot __verse_0x4A284B23_ControllerSlot); // Function Entity_Client_InputComponent.InputComponent.setAutoReceiveInput // (Native|Public|BlueprintCallable) // @ game+0x3ed70dc
	float getCurrentInputAxisValue(struct FString __verse_0xB2EFD1C1_AxisName); // Function Entity_Client_InputComponent.InputComponent.getCurrentInputAxisValue // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6a10
	void bindToInputAxis(struct FString __verse_0xB2EFD1C1_AxisName); // Function Entity_Client_InputComponent.InputComponent.bindToInputAxis // (Native|Public|BlueprintCallable) // @ game+0x3ed6404
	void $InitInstance(); // Function Entity_Client_InputComponent.InputComponent.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Entity_Client_InputComponent.InputComponent.$InitCDO // () // @ game+0xbd830c
};

