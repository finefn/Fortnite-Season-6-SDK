// BlueprintGeneratedClass AthenaFunctionLibrary.AthenaFunctionLibrary_C
// Size: 0x28 (Inherited: 0x28)
struct UAthenaFunctionLibrary_C : UBlueprintFunctionLibrary {

	struct FGameplayEffectContextHandle MakeSimpleFortEffectContext(struct AActor* Instigator, struct AActor* Damage Source, struct UObject* __WorldContext); // Function AthenaFunctionLibrary.AthenaFunctionLibrary_C.MakeSimpleFortEffectContext // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void SpawnLootFromTable(struct FName TierGroupName, int32_t WorldLevel, int32_t ForcedLootTier, struct FVector Position, struct FVector Direction, int32_t OverrideMaxStackCount, bool bToss, bool bRandomRotation, bool bBlockedFromAutoPickup, int32_t PickupInstigatorHandle, enum class EFortPickupSourceTypeFlag SourceType, enum class EFortPickupSpawnSource Source, struct AFortPlayerController* OptionalOwnerPC, bool bPickupOnlyRelevantToOwner, struct UObject* __WorldContext, struct TArray<struct AFortPickup*> ItemPickupsSpawned); // Function AthenaFunctionLibrary.AthenaFunctionLibrary_C.SpawnLootFromTable // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool RowToBool(struct FScalableFloat Input, float Level, struct UObject* __WorldContext); // Function AthenaFunctionLibrary.AthenaFunctionLibrary_C.RowToBool // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void AllOnSameTeam(struct AActor* Actor, struct TArray<struct AActor*> ActorArray, struct UObject* __WorldContext, bool Result); // Function AthenaFunctionLibrary.AthenaFunctionLibrary_C.AllOnSameTeam // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CreateEnvironmentalKnockbackExplosion(struct FVector ExplosionSourcePoint, float ExplosionRadius, float Intensity, float MinKnockbackAngle, bool Reverse, struct AActor* SpecificActor, struct UObject* __WorldContext); // Function AthenaFunctionLibrary.AthenaFunctionLibrary_C.CreateEnvironmentalKnockbackExplosion // (Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

