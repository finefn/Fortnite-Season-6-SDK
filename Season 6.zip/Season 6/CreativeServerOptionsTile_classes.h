// WidgetBlueprintGeneratedClass CreativeServerOptionsTile.CreativeServerOptionsTile_C
// Size: 0xd34 (Inherited: 0xc08)
struct UCreativeServerOptionsTile_C : UFortCreativeServerOptionTile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc08(0x08)
	struct UWidgetAnimation* Hover; // 0xc10(0x08)
	struct UWidgetAnimation* Selected_2; // 0xc18(0x08)
	struct UWidgetAnimation* PrivacyToggle; // 0xc20(0x08)
	struct UWidgetAnimation* HoverToggle; // 0xc28(0x08)
	struct UWidgetAnimation* ViewPlayers; // 0xc30(0x08)
	struct UWidgetAnimation* Selected; // 0xc38(0x08)
	struct USimpleCommonButtonWithInput_C* Button_CloseFriends; // 0xc40(0x08)
	struct USimpleCommonButtonWithInput_C* Button_ShowFriends; // 0xc48(0x08)
	struct UCommonBorder* CommonBorder_NewServerContent; // 0xc50(0x08)
	struct UCommonBorder* CommonBorder_ServerDetails; // 0xc58(0x08)
	struct UVerticalBox* CreateServerContent; // 0xc60(0x08)
	struct UIconTextButton_C* CreateServerPrivacy; // 0xc68(0x08)
	struct UDynamicEntryBox* EntryBox_ServerFriendList; // 0xc70(0x08)
	struct UImage* Image_29; // 0xc78(0x08)
	struct UImage* Image_113; // 0xc80(0x08)
	struct UImage* Image_114; // 0xc88(0x08)
	struct UImage* Image_115; // 0xc90(0x08)
	struct UImage* Image_116; // 0xc98(0x08)
	struct UImage* Image_117; // 0xca0(0x08)
	struct UImage* Image_ColorFill; // 0xca8(0x08)
	struct UImage* Image_Fill; // 0xcb0(0x08)
	struct UImage* Image_Gradient; // 0xcb8(0x08)
	struct UImage* Image_NewServer; // 0xcc0(0x08)
	struct UImage* Image_ServerImage; // 0xcc8(0x08)
	struct UCommonWidgetSwitcher* ImageTypeSwitcher; // 0xcd0(0x08)
	struct UOverlay* JoinServerContent; // 0xcd8(0x08)
	struct UCommonTextBlock* LimitedAccessDateCalloutText; // 0xce0(0x08)
	struct UOverlay* LimitedAccessServerContent; // 0xce8(0x08)
	struct URichTextBlock* RichText_JoinServerFriendCount; // 0xcf0(0x08)
	struct UCommonWidgetSwitcher* ServerTypeSwitcher; // 0xcf8(0x08)
	struct UCommonTextBlock* Text_JoinServerName; // 0xd00(0x08)
	struct UCommonTextBlock* TextPrivacyToggle; // 0xd08(0x08)
	struct TArray<struct FString> FriendListOutput; // 0xd10(0x10)
	bool PlayersShown; // 0xd20(0x01)
	bool NewServerIsPrivate; // 0xd21(0x01)
	char UnknownData_D22[0x2]; // 0xd22(0x02)
	struct FLinearColor DisabledColor; // 0xd24(0x10)

	void InitServerInfo(struct UFortCreativeServerInfo* ServerInfo); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.InitServerInfo // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_3534B041413498BC4DD6D2B727558DF9(struct UObject* Loaded); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.OnLoaded_3534B041413498BC4DD6D2B727558DF9 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__IconTextButton_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BndEvt__IconTextButton_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CreateServerPrivacy_K2Node_ComponentBoundEvent_3_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BndEvt__CreateServerPrivacy_K2Node_ComponentBoundEvent_3_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CreateServerPrivacy_K2Node_ComponentBoundEvent_4_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BndEvt__CreateServerPrivacy_K2Node_ComponentBoundEvent_4_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void SetBPData(struct UFortCreativeServerInfo* ServerInfo); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.SetBPData // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Button_CloseFriends_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BndEvt__Button_CloseFriends_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Button_ShowFriends_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BndEvt__Button_ShowFriends_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BP_OnSelected(); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnDeselected(); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void InitializeSelectedButton(); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.InitializeSelectedButton // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void InputMethodChanged(enum class ECommonInputType bNewInputType); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.InputMethodChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SetBackgroundImage(int32_t ArrayIndex); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.SetBackgroundImage // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CreativeServerOptionsTile(int32_t EntryPoint); // Function CreativeServerOptionsTile.CreativeServerOptionsTile_C.ExecuteUbergraph_CreativeServerOptionsTile // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

