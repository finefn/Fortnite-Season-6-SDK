// Class ConcertTransport.ConcertEndpointConfig
// Size: 0x38 (Inherited: 0x28)
struct UConcertEndpointConfig : UObject {
	struct FConcertEndpointSettings EndpointSettings; // 0x28(0x0c)
	char UnknownData_34[0x4]; // 0x34(0x04)
};

