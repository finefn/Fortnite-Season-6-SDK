// BlueprintGeneratedClass Athena_Prop_SnowmanV3.Athena_Prop_SnowmanV3_C
// Size: 0xd60 (Inherited: 0xce0)
struct AAthena_Prop_SnowmanV3_C : AAthena_Prop_SneakySnowmanV2_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xce0(0x08)
	struct FScalableFloat LaunchSpeed; // 0xce8(0x28)
	struct FScalableFloat FrostExplosionRadius; // 0xd10(0x28)
	struct FScalableFloat Enabled; // 0xd38(0x28)

	void OnReady_AD4F5A8A441B21F821A089A2E6DA49B3(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function Athena_Prop_SnowmanV3.Athena_Prop_SnowmanV3_C.OnReady_AD4F5A8A441B21F821A089A2E6DA49B3 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Athena_Prop_SnowmanV3.Athena_Prop_SnowmanV3_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Athena_Prop_SnowmanV3.Athena_Prop_SnowmanV3_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Prop_SnowmanV3(int32_t EntryPoint); // Function Athena_Prop_SnowmanV3.Athena_Prop_SnowmanV3_C.ExecuteUbergraph_Athena_Prop_SnowmanV3 // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

