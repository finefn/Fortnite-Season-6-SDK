// BlueprintGeneratedClass Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C
// Size: 0xa2d (Inherited: 0x7f0)
struct AAthena_Player_SneakySnowmanV2_C : ABuildingGameplayActorBalloon {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7f0(0x08)
	struct UStaticMeshComponent* Cylinder; // 0x7f8(0x08)
	struct UStaticMeshComponent* SM_SneakySnowman; // 0x800(0x08)
	struct USceneComponent* Scene; // 0x808(0x08)
	float UpDOwn_NewTrack_0_BD67B22A4CF8433C66D2D5AAD822DE34; // 0x810(0x04)
	enum class ETimelineDirection UpDOwn__Direction_BD67B22A4CF8433C66D2D5AAD822DE34; // 0x814(0x01)
	char UnknownData_815[0x3]; // 0x815(0x03)
	struct UTimelineComponent* UpDOwn; // 0x818(0x08)
	float RotateToGroundTimeline_Rot_470A54CC466D5762D035668F5DF86D12; // 0x820(0x04)
	enum class ETimelineDirection RotateToGroundTimeline__Direction_470A54CC466D5762D035668F5DF86D12; // 0x824(0x01)
	char UnknownData_825[0x3]; // 0x825(0x03)
	struct UTimelineComponent* RotateToGroundTimeline; // 0x828(0x08)
	float DropToFloor_Rot_129CAD134FB32339D63E11AA09B71F56; // 0x830(0x04)
	float DropToFloor_Pos_129CAD134FB32339D63E11AA09B71F56; // 0x834(0x04)
	enum class ETimelineDirection DropToFloor__Direction_129CAD134FB32339D63E11AA09B71F56; // 0x838(0x01)
	char UnknownData_839[0x7]; // 0x839(0x07)
	struct UTimelineComponent* DropToFloor; // 0x840(0x08)
	float AdjustSnowman_Progress_F0A878244A424741C496E29D1303F240; // 0x848(0x04)
	enum class ETimelineDirection AdjustSnowman__Direction_F0A878244A424741C496E29D1303F240; // 0x84c(0x01)
	char UnknownData_84D[0x3]; // 0x84d(0x03)
	struct UTimelineComponent* AdjustSnowman; // 0x850(0x08)
	struct AFortPlayerPawn* PlayerPawn; // 0x858(0x08)
	float TotalDamageTaken; // 0x860(0x04)
	char UnknownData_864[0x4]; // 0x864(0x04)
	struct FScalableFloat MaxHealth; // 0x868(0x28)
	struct FRotator Adjust_StartZRot; // 0x890(0x0c)
	struct FRotator Adjust_GoalRot; // 0x89c(0x0c)
	struct FVector Adjust_StartLocation; // 0x8a8(0x0c)
	bool StartHidden; // 0x8b4(0x01)
	char UnknownData_8B5[0x3]; // 0x8b5(0x03)
	struct FVector Drop_StartPos; // 0x8b8(0x0c)
	struct FVector Drop_GoalPos; // 0x8c4(0x0c)
	struct FRotator Drop_GoalRot; // 0x8d0(0x0c)
	bool Attached; // 0x8dc(0x01)
	char UnknownData_8DD[0x3]; // 0x8dd(0x03)
	struct USoundBase* SoundOnJumpIn; // 0x8e0(0x08)
	struct USoundBase* SoundOnJumpOut; // 0x8e8(0x08)
	bool ShouldSpawnDeathFX; // 0x8f0(0x01)
	char UnknownData_8F1[0x3]; // 0x8f1(0x03)
	struct FVector PropPosOffset; // 0x8f4(0x0c)
	struct FVector AttachmentOffset; // 0x900(0x0c)
	struct FVector FakePosOffset; // 0x90c(0x0c)
	struct FVector RotationOffsetOnAttach; // 0x918(0x0c)
	char UnknownData_924[0x4]; // 0x924(0x04)
	struct AActor* PropToSpawnOnExit; // 0x928(0x08)
	bool CurrentlyReplacedByFake; // 0x930(0x01)
	char UnknownData_931[0x7]; // 0x931(0x07)
	struct ABuildingGameplayActor* FakeActorClass; // 0x938(0x08)
	struct AAthena_Fake_SneakySnowmanV2_C* FakeActor; // 0x940(0x08)
	bool ShouldMaintainRotationWhileHiding; // 0x948(0x01)
	bool IsPoppingOut; // 0x949(0x01)
	char UnknownData_94A[0x6]; // 0x94a(0x06)
	struct FMulticastInlineDelegate OnPopOut; // 0x950(0x10)
	struct FMulticastInlineDelegate OnPopIn; // 0x960(0x10)
	struct UParticleSystem* P_JumpingOut; // 0x970(0x08)
	struct FMulticastInlineDelegate OnJumpOut; // 0x978(0x10)
	bool PlayerIsBeingForcedOut; // 0x988(0x01)
	bool SnapRotationToForwardOnStand; // 0x989(0x01)
	bool RotateOnEnter; // 0x98a(0x01)
	char UnknownData_98B[0x5]; // 0x98b(0x05)
	struct UParticleSystem* P_Death_Effects; // 0x990(0x08)
	struct USoundBase* Death_SoundFX; // 0x998(0x08)
	bool IsBeingReplacedWithProp; // 0x9a0(0x01)
	char UnknownData_9A1[0x7]; // 0x9a1(0x07)
	struct USoundBase* SoundOnCrouch; // 0x9a8(0x08)
	bool CurrentlyCrouching; // 0x9b0(0x01)
	char UnknownData_9B1[0x3]; // 0x9b1(0x03)
	struct FRotator Fake_GoalRot; // 0x9b4(0x0c)
	bool RotateFakeToMatchGroundNormal; // 0x9c0(0x01)
	char UnknownData_9C1[0x7]; // 0x9c1(0x07)
	struct USoundBase* SoundOnStand; // 0x9c8(0x08)
	bool SelfHidden; // 0x9d0(0x01)
	bool PlayerHidden; // 0x9d1(0x01)
	char UnknownData_9D2[0x2]; // 0x9d2(0x02)
	struct FRotator Fake_StartRot; // 0x9d4(0x0c)
	float Wobble_OriginalZ; // 0x9e0(0x04)
	char UnknownData_9E4[0x4]; // 0x9e4(0x04)
	struct FMulticastInlineDelegate OnSpawnProp; // 0x9e8(0x10)
	bool Interacting; // 0x9f8(0x01)
	bool Swimming; // 0x9f9(0x01)
	char UnknownData_9FA[0x2]; // 0x9fa(0x02)
	struct FVector PreviousLocation; // 0x9fc(0x0c)
	struct AAthena_SneakySnowmanV2_InteractSphere_C* InteractSphereRef; // 0xa08(0x08)
	bool RotatePropToMatchGroundNormal; // 0xa10(0x01)
	bool RemoveTags; // 0xa11(0x01)
	char UnknownData_A12[0x2]; // 0xa12(0x02)
	float JumpOut_LateralSpeed; // 0xa14(0x04)
	float JumpOut_VerticalSpeed; // 0xa18(0x04)
	bool TFS_HidePlayerIfUsingFake; // 0xa1c(0x01)
	char UnknownData_A1D[0x3]; // 0xa1d(0x03)
	struct FVector TFS_CrouchedLocation; // 0xa20(0x0c)
	bool TFS_RotateFakeToGroundAngle; // 0xa2c(0x01)

	void IsMeshHeightScalePositive(bool bReturnValue); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.IsMeshHeightScalePositive // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void FlattestHitResult(struct TArray<struct FHitResult> NewParam, struct FHitResult Flattest); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.FlattestHitResult // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckForClipping_(bool Clipping); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.CheckForClipping_ // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInterruptInteractWithSphere(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnInterruptInteractWithSphere // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnBeginInteractWithSphere(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnBeginInteractWithSphere // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_PlayerHidden(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnRep_PlayerHidden // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_SelfHidden(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnRep_SelfHidden // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FRotator GetFakeRotation(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.GetFakeRotation // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponChange(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnWeaponChange // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStoppedUsingFake(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnStoppedUsingFake // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStartedUsingFake(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnStartedUsingFake // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FVector GetCrouchedLoc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.GetCrouchedLoc // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void CheckIfCanJumpOut(struct UObject* InteractingPawn, bool CanInteract); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.CheckIfCanJumpOut // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AdjustSnowman__FinishedFunc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.AdjustSnowman__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void AdjustSnowman__UpdateFunc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.AdjustSnowman__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void DropToFloor__FinishedFunc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.DropToFloor__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void DropToFloor__UpdateFunc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.DropToFloor__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void RotateToGroundTimeline__FinishedFunc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.RotateToGroundTimeline__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void RotateToGroundTimeline__UpdateFunc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.RotateToGroundTimeline__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void UpDOwn__FinishedFunc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.UpDOwn__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void UpDOwn__UpdateFunc(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.UpDOwn__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnNotifyEnd_260935FE4E6B93550ACE848A0EA63F7B(struct FName NotifyName); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnNotifyEnd_260935FE4E6B93550ACE848A0EA63F7B // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnNotifyBegin_260935FE4E6B93550ACE848A0EA63F7B(struct FName NotifyName); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnNotifyBegin_260935FE4E6B93550ACE848A0EA63F7B // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInterrupted_260935FE4E6B93550ACE848A0EA63F7B(struct FName NotifyName); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnInterrupted_260935FE4E6B93550ACE848A0EA63F7B // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnBlendOut_260935FE4E6B93550ACE848A0EA63F7B(struct FName NotifyName); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnBlendOut_260935FE4E6B93550ACE848A0EA63F7B // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnCompleted_260935FE4E6B93550ACE848A0EA63F7B(struct FName NotifyName); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnCompleted_260935FE4E6B93550ACE848A0EA63F7B // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void CrouchedCheck(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.CrouchedCheck // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Wobble(float Strength, bool MoveUpAndDown); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.Wobble // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnEffects(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.SpawnEffects // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Destroyed(struct AActor* DestroyedActor); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.Destroyed // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnProp(bool PlayMontage, bool RemoveTags); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.SpawnProp // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StopHiding(bool LaunchPlayer); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.StopHiding // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Destroy(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.Destroy // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void MovementUpdated(float DeltaSeconds, struct FVector OldLocation, struct FVector OldVelocity); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.MovementUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ToggleFakeSnowman_Multicast(bool ToggleFakeOn, struct FVector CrouchedLoc, bool RotateToGround, bool SetPoppingOut); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.ToggleFakeSnowman_Multicast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetFakeActor(struct AAthena_Fake_SneakySnowmanV2_C* FakeActor); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.SetFakeActor // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void JustAttached(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.JustAttached // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInteractWithFake(struct AFortPawn* InteractingPawn); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnInteractWithFake // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StopRotatingFake(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.StopRotatingFake // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void RotateToGround(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.RotateToGround // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void RotateToStraight(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.RotateToStraight // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnEnterVehicle(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnEnterVehicle // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetPrevLocation(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.SetPrevLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ToggleFakeSnowman(bool ToggleFakeOn, bool HidePlayerIfTrue, struct FVector CrouchedLoc, bool RotateToGround, bool SetPoppingOut); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.ToggleFakeSnowman // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetPlayerHidden(bool PlayerHidden); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.SetPlayerHidden // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetSnowmanHidden(bool Hidden, bool InstantOnAll); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.SetSnowmanHidden // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StateChangedDelegate_Event_1(struct AFortMinigame* Minigame, enum class EFortMinigameState MinigameState); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.StateChangedDelegate_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnClientExitVolume_Event_1(struct APlayerState* Client, struct AFortVolume* Volume); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnClientExitVolume_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShowFakeActor(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.ShowFakeActor // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPlayerGotSnowman(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnPlayerGotSnowman // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DBNO(struct AFortPawn* FortPawn, bool bInIsDBNO); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.DBNO // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayerDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.PlayerDied // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Player_SneakySnowmanV2(int32_t EntryPoint); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.ExecuteUbergraph_Athena_Player_SneakySnowmanV2 // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void OnSpawnProp__DelegateSignature(struct AActor* Prop); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnSpawnProp__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnJumpOut__DelegateSignature(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnJumpOut__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPopIn__DelegateSignature(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnPopIn__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPopOut__DelegateSignature(); // Function Athena_Player_SneakySnowmanV2.Athena_Player_SneakySnowmanV2_C.OnPopOut__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

