// WidgetBlueprintGeneratedClass CreativePlayModal.CreativePlayModal_C
// Size: 0x540 (Inherited: 0x4c0)
struct UCreativePlayModal_C : UFortCreativePlayOptions {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c0(0x08)
	struct UWidgetAnimation* FriendsAdded; // 0x4c8(0x08)
	struct UWidgetAnimation* Intro; // 0x4d0(0x08)
	struct UIconTextButton_C* AddFriendsButton; // 0x4d8(0x08)
	struct USizeBox* AddFriendsContent; // 0x4e0(0x08)
	struct UCommonTextBlock* AddFriendsText; // 0x4e8(0x08)
	struct UCloseButton_C* CloseButton; // 0x4f0(0x08)
	struct UCreativeLobbyAdSpace_C* CreativeLobbyAdSpace; // 0x4f8(0x08)
	struct UImage* Image_159; // 0x500(0x08)
	struct UImage* Image_IdlePulse; // 0x508(0x08)
	struct UIconTextButton_C* IslandCodeButton; // 0x510(0x08)
	struct USizeBox* IslandCodeContent; // 0x518(0x08)
	struct UOverlay* OverlayTitle; // 0x520(0x08)
	struct USafeZone* SafeZone_1; // 0x528(0x08)
	struct USafeZone* SafeZone_4; // 0x530(0x08)
	struct UCommonTextBlock* StartIslandText; // 0x538(0x08)

	void ManageCancelButton(); // Function CreativePlayModal.CreativePlayModal_C.ManageCancelButton // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetStartIsland(struct FText StartIslandName); // Function CreativePlayModal.CreativePlayModal_C.SetStartIsland // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleSocialImportClosed(); // Function CreativePlayModal.CreativePlayModal_C.HandleSocialImportClosed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void InitializeAddFriends(); // Function CreativePlayModal.CreativePlayModal_C.InitializeAddFriends // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void NullActionHandler(bool bPassThrough); // Function CreativePlayModal.CreativePlayModal_C.NullActionHandler // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void InitFromObject(struct UObject* InitObject); // Function CreativePlayModal.CreativePlayModal_C.InitFromObject // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CreativeOptionsServers_K2Node_ComponentBoundEvent_0_OnSelectedServerChanged__DelegateSignature(struct UFortCreativeServerInfo* ServerInfo); // Function CreativePlayModal.CreativePlayModal_C.BndEvt__CreativeOptionsServers_K2Node_ComponentBoundEvent_0_OnSelectedServerChanged__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function CreativePlayModal.CreativePlayModal_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BP_OnActivated(); // Function CreativePlayModal.CreativePlayModal_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnDeactivated(); // Function CreativePlayModal.CreativePlayModal_C.BP_OnDeactivated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnBeginOutro(); // Function CreativePlayModal.CreativePlayModal_C.OnBeginOutro // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__AddFriendsButton_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativePlayModal.CreativePlayModal_C.BndEvt__AddFriendsButton_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__IslandCodeButton_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativePlayModal.CreativePlayModal_C.BndEvt__IslandCodeButton_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void CreativeIslandCodeConfirmedEvent(struct UFortCreativeIslandLink* IslandLink); // Function CreativePlayModal.CreativePlayModal_C.CreativeIslandCodeConfirmedEvent // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInputMethodChanged(enum class ECommonInputType bNewInputType); // Function CreativePlayModal.CreativePlayModal_C.OnInputMethodChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CloseButton_K2Node_ComponentBoundEvent_3_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativePlayModal.CreativePlayModal_C.BndEvt__CloseButton_K2Node_ComponentBoundEvent_3_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CreativePlayModal(int32_t EntryPoint); // Function CreativePlayModal.CreativePlayModal_C.ExecuteUbergraph_CreativePlayModal // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

