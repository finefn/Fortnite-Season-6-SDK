// BlueprintGeneratedClass BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C
// Size: 0xad9 (Inherited: 0x8fd)
struct ABGA_Athena_CuddleFish_Jumper_C : ABGA_Athena_WithGravity_Parent_C {
	char UnknownData_8FD[0x3]; // 0x8fd(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x900(0x08)
	struct UNiagaraComponent* FriendlyVFX; // 0x908(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x910(0x08)
	struct USceneComponent* MeshPivot; // 0x918(0x08)
	struct UAudioComponent* AmbientHumAudio; // 0x920(0x08)
	struct USphereComponent* JumpTrigger; // 0x928(0x08)
	struct FScalableFloat JumpRadius; // 0x930(0x28)
	struct FScalableFloat DamageRadius; // 0x958(0x28)
	struct FScalableFloat TimeToArm; // 0x980(0x28)
	struct FScalableFloat JumpDelay; // 0x9a8(0x28)
	struct FText InteractText; // 0x9d0(0x18)
	bool IsExlode?; // 0x9e8(0x01)
	char UnknownData_9E9[0x3]; // 0x9e9(0x03)
	struct FGameplayTag CameraShakeGC; // 0x9ec(0x08)
	bool IsInteract?; // 0x9f4(0x01)
	char UnknownData_9F5[0x3]; // 0x9f5(0x03)
	struct USoundBase* ExplodeSound; // 0x9f8(0x08)
	struct UParticleSystemComponent* BeepParticles; // 0xa00(0x08)
	struct UFortWorldItemDefinition* ItemToPickUpOnDisarm; // 0xa08(0x08)
	struct UGameplayEffect* ExplosionGE; // 0xa10(0x08)
	struct USoundBase* PickupSound; // 0xa18(0x08)
	enum class None MyTeam; // 0xa20(0x01)
	bool Jumped; // 0xa21(0x01)
	bool TeamHasBeenSet; // 0xa22(0x01)
	char UnknownData_A23[0x5]; // 0xa23(0x05)
	struct UFortAbilitySystemComponent* DamageDealingAbilitySystemComponent; // 0xa28(0x08)
	struct FGameplayEffectContextHandle ExplosionEffectContext; // 0xa30(0x18)
	struct AFortPawn* JumpTarget; // 0xa48(0x08)
	struct AFortPawn* StuckToPawn; // 0xa50(0x08)
	struct FScalableFloat PredictionDelta; // 0xa58(0x28)
	struct USoundBase* ArmedSound; // 0xa80(0x08)
	struct USoundBase* JumpTriggeredSound; // 0xa88(0x08)
	bool HasAttached; // 0xa90(0x01)
	char UnknownData_A91[0x7]; // 0xa91(0x07)
	struct UNiagaraSystem* ExplosionVFX; // 0xa98(0x08)
	struct UNiagaraSystem* LandedVFX; // 0xaa0(0x08)
	struct UAudioComponent* JumpAudio; // 0xaa8(0x08)
	struct FName LandedTag; // 0xab0(0x08)
	struct FName FallingTag; // 0xab8(0x08)
	struct UAnimMontage* LandingMontage; // 0xac0(0x08)
	bool HasLanded; // 0xac8(0x01)
	bool IsFalling; // 0xac9(0x01)
	char UnknownData_ACA[0x6]; // 0xaca(0x06)
	struct USoundBase* ExplodeSFX; // 0xad0(0x08)
	bool JumpTriggered; // 0xad8(0x01)

	void CheckForHostilePawn(bool HostileFound, struct AFortPawn* FortPawn); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.CheckForHostilePawn // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleNPC_AI(struct ANPC_Pawn_Parent_C* NPC Pawn, bool Success, bool CanStick); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.HandleNPC_AI // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void AttachToBindedActor(struct UPrimitiveComponent* AttachComp); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.AttachToBindedActor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleWildlife(struct ANPC_Pawn_Wildlife_Parent_C* WildlifePawn, bool Success, bool CanStick); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.HandleWildlife // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	struct FVector GetFocusedSocketLocation(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.GetFocusedSocketLocation // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	bool CanBeSavedToCreativeVolume(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.CanBeSavedToCreativeVolume // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void GetAllPawns(struct TArray<struct AActor*> _Array, struct TArray<struct AActor*> _Result); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.GetAllPawns // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool Is in Infiltration Mode(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.Is in Infiltration Mode // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void Init(struct FVector GravHitNormal); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FilterByLOS(struct TArray<struct AActor*> _Array, struct TArray<struct AActor*> _Result); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.FilterByLOS // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void UserConstructionScript(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnNotifyEnd_1831763E4715DB104E905EAB6E220FB3(struct FName NotifyName); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.OnNotifyEnd_1831763E4715DB104E905EAB6E220FB3 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnNotifyBegin_1831763E4715DB104E905EAB6E220FB3(struct FName NotifyName); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.OnNotifyBegin_1831763E4715DB104E905EAB6E220FB3 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInterrupted_1831763E4715DB104E905EAB6E220FB3(struct FName NotifyName); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.OnInterrupted_1831763E4715DB104E905EAB6E220FB3 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnBlendOut_1831763E4715DB104E905EAB6E220FB3(struct FName NotifyName); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.OnBlendOut_1831763E4715DB104E905EAB6E220FB3 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnCompleted_1831763E4715DB104E905EAB6E220FB3(struct FName NotifyName); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.OnCompleted_1831763E4715DB104E905EAB6E220FB3 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ExplosionTrigger_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.BndEvt__ExplosionTrigger_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void HandleJump(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.HandleJump // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void SpawnFXSounds(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.SpawnFXSounds // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ExplosionTrigger_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.BndEvt__ExplosionTrigger_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void DetachAndLaunch(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.DetachAndLaunch // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Explode(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.Explode // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Destroyed(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.Destroyed // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_4_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_4_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void StopSim(struct FHitResult Hit); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.StopSim // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInstigatorDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.OnInstigatorDied // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_6_OnProjectileStopDelegate__DelegateSignature(struct FHitResult ImpactResult); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_6_OnProjectileStopDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void SetMyTeam(enum class None Team); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.SetMyTeam // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnExplosionParticles(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.SpawnExplosionParticles // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void RestartSimulation(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.RestartSimulation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckAffiliationChange(); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.CheckAffiliationChange // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_CuddleFish_Jumper(int32_t EntryPoint); // Function BGA_Athena_CuddleFish_Jumper.BGA_Athena_CuddleFish_Jumper_C.ExecuteUbergraph_BGA_Athena_CuddleFish_Jumper // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

