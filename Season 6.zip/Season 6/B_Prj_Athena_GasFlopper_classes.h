// BlueprintGeneratedClass B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C
// Size: 0x919 (Inherited: 0x878)
struct AB_Prj_Athena_GasFlopper_C : AFortProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x878(0x08)
	struct USkeletalMeshComponent* Gas_Fish; // 0x880(0x08)
	struct UPostProcessComponent* PostProcessComponent; // 0x888(0x08)
	struct USphereComponent* PostProcessParentShape; // 0x890(0x08)
	struct UStaticMeshComponent* SmokeVolumeMesh; // 0x898(0x08)
	struct UParticleSystemComponent* P_GasGrenade_InnerSmoke; // 0x8a0(0x08)
	struct UAudioComponent* AudioReleaseSmoke; // 0x8a8(0x08)
	struct UCapsuleComponent* OverlapCapsule; // 0x8b0(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x8b8(0x08)
	struct UParticleSystemComponent* SmokeTrail_Particle; // 0x8c0(0x08)
	struct UAudioComponent* GrenadeFuse_AudioComponent; // 0x8c8(0x08)
	struct UParticleSystemComponent* Effect_Distance; // 0x8d0(0x08)
	float FadeSmokeTL_Float_C90907DC49F4658FC5BA0CA0E7EFC1E9; // 0x8d8(0x04)
	enum class ETimelineDirection FadeSmokeTL__Direction_C90907DC49F4658FC5BA0CA0E7EFC1E9; // 0x8dc(0x01)
	char UnknownData_8DD[0x3]; // 0x8dd(0x03)
	struct UTimelineComponent* FadeSmokeTL; // 0x8e0(0x08)
	struct USoundBase* Cue_CloseSound; // 0x8e8(0x08)
	float DoT_TickRate; // 0x8f0(0x04)
	float GasDuration; // 0x8f4(0x04)
	float GasDelayBeforeFadeIn; // 0x8f8(0x04)
	float GasFadeOutTime; // 0x8fc(0x04)
	float GasFadeInTime; // 0x900(0x04)
	char UnknownData_904[0x4]; // 0x904(0x04)
	struct UMaterialInstanceDynamic* SmokeVolumeMeshMID; // 0x908(0x08)
	float GasGrenadeRadius; // 0x910(0x04)
	float SyncedDelay; // 0x914(0x04)
	bool HitWater; // 0x918(0x01)

	void UserConstructionScript(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FadeSmokeTL__FinishedFunc(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.FadeSmokeTL__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void FadeSmokeTL__UpdateFunc(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.FadeSmokeTL__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnStop(struct FHitResult Hit); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Stop_Rotation(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.Stop_Rotation // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DamageTick(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.DamageTick // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FadeIn(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.FadeIn // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FadeOut(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.FadeOut // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SyncedTimer(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.SyncedTimer // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update Gas Duration(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.Update Gas Duration // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update Tick Rate(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.Update Tick Rate // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update PostProcess Scale(); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.Update PostProcess Scale // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnShot(struct FHitResult Hit); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.OnShot // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_GasFlopper(int32_t EntryPoint); // Function B_Prj_Athena_GasFlopper.B_Prj_Athena_GasFlopper_C.ExecuteUbergraph_B_Prj_Athena_GasFlopper // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

