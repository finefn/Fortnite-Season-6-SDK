// BlueprintGeneratedClass DA_Butterfly.DA_Butterfly_C
// Size: 0xdd0 (Inherited: 0xdc8)
struct ADA_Butterfly_C : AFortCustomizableAbilityDecoTool {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xdc8(0x08)

	void BPPressSecondaryFire(struct AFortDecoHelper* FortDecoHelper); // Function DA_Butterfly.DA_Butterfly_C.BPPressSecondaryFire // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BPPressTrigger(struct AFortDecoHelper* FortDecoHelper); // Function DA_Butterfly.DA_Butterfly_C.BPPressTrigger // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BPOnUnEquip(); // Function DA_Butterfly.DA_Butterfly_C.BPOnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BPReleaseSecondaryFire(struct AFortDecoHelper* FortDecoHelper); // Function DA_Butterfly.DA_Butterfly_C.BPReleaseSecondaryFire // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_DA_Butterfly(int32_t EntryPoint); // Function DA_Butterfly.DA_Butterfly_C.ExecuteUbergraph_DA_Butterfly // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

