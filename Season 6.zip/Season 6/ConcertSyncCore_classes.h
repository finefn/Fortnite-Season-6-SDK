// Class ConcertSyncCore.ConcertSyncConfig
// Size: 0x70 (Inherited: 0x28)
struct UConcertSyncConfig : UObject {
	bool bInteractiveHotReload; // 0x28(0x01)
	bool bShowPresenceInPIE; // 0x29(0x01)
	char UnknownData_2A[0x2]; // 0x2a(0x02)
	float SnapshotTransactionsPerSecond; // 0x2c(0x04)
	struct TArray<struct FTransactionClassFilter> IncludeObjectClassFilters; // 0x30(0x10)
	struct TArray<struct FTransactionClassFilter> ExcludeTransactionClassFilters; // 0x40(0x10)
	struct TArray<FieldPathProperty> AllowedTransientProperties; // 0x50(0x10)
	struct TArray<struct FPackageClassFilter> ExcludePackageClassFilters; // 0x60(0x10)
};

