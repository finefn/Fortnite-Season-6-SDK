// BlueprintGeneratedClass AnimNotify_PlayReloadFX.AnimNotify_PlayReloadFX_C
// Size: 0x39 (Inherited: 0x38)
struct UAnimNotify_PlayReloadFX_C : UAnimNotify {
	enum class EFortReloadFXState ReloadStage; // 0x38(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_PlayReloadFX.AnimNotify_PlayReloadFX_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
};

