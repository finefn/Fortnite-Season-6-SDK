// WidgetBlueprintGeneratedClass ArrowCursorWidget.ArrowCursorWidget_C
// Size: 0x260 (Inherited: 0x260)
struct UArrowCursorWidget_C : UUserWidget {

	struct FSlateBrush GetBackground_1(); // Function ArrowCursorWidget.ArrowCursorWidget_C.GetBackground_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
};

