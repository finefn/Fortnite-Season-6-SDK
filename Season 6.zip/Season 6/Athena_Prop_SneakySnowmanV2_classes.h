// BlueprintGeneratedClass Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C
// Size: 0xce0 (Inherited: 0xbc0)
struct AAthena_Prop_SneakySnowmanV2_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc0(0x08)
	struct UCapsuleComponent* OverlapCheck; // 0xbc8(0x08)
	float Timeline_0_RotationAlpha_4116426F45EB954F1A0ACDA6058E6CCC; // 0xbd0(0x04)
	enum class ETimelineDirection Timeline_0__Direction_4116426F45EB954F1A0ACDA6058E6CCC; // 0xbd4(0x01)
	char UnknownData_BD5[0x3]; // 0xbd5(0x03)
	struct UTimelineComponent* Timeline_1; // 0xbd8(0x08)
	struct UGameplayEffect* GE_ApplyEnemySnowman; // 0xbe0(0x08)
	struct FScalableFloat ShouldSnowmanEnemies; // 0xbe8(0x28)
	struct AFortPickupAthena* PickupAthena; // 0xc10(0x08)
	struct TArray<struct AActor*> Ignored Actors; // 0xc18(0x10)
	struct TArray<enum class EObjectTypeQuery> LineTraceObjects; // 0xc28(0x10)
	bool DestroyAfterHit; // 0xc38(0x01)
	char UnknownData_C39[0x3]; // 0xc39(0x03)
	float InitialGravityScale; // 0xc3c(0x04)
	bool GamestateLoaded; // 0xc40(0x01)
	char UnknownData_C41[0x7]; // 0xc41(0x07)
	struct TArray<enum class EObjectTypeQuery> ObjectTypes; // 0xc48(0x10)
	struct FScalableFloat FallHeightToDestroy; // 0xc58(0x28)
	struct FScalableFloat ShouldSpawnSnowball; // 0xc80(0x28)
	bool Dead; // 0xca8(0x01)
	char UnknownData_CA9[0x3]; // 0xca9(0x03)
	struct FVector StartLocation; // 0xcac(0x0c)
	struct FVector EndLocation; // 0xcb8(0x0c)
	char UnknownData_CC4[0x4]; // 0xcc4(0x04)
	struct UGameplayEffect* ApplicationEffect; // 0xcc8(0x08)
	struct UParticleSystem* Jumpinto; // 0xcd0(0x08)
	struct USoundBase* JumpInSound; // 0xcd8(0x08)

	void GetMaterialInt(int32_t MatInt); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.GetMaterialInt // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetNewSnowmanTransform(struct FTransform Transform); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.GetNewSnowmanTransform // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void TraceStartAndEnd(struct FVector Start, struct FVector End); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.TraceStartAndEnd // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void OnRep_bSimulationRunning(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.OnRep_bSimulationRunning // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Timeline_0__FinishedFunc(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_0__UpdateFunc(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnGaveSneakySnowman(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.OnGaveSneakySnowman // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnDamagePlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.OnDamagePlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__OverlapCheck_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.BndEvt__OverlapCheck_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void PlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer PlaylistContextTags); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.PlaylistLoaded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void WobbleAnims(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.WobbleAnims // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void WorldPropSupportDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.WorldPropSupportDied // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void MovePlayer(struct AActor* Player); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.MovePlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStartedJumpingIn(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.OnStartedJumpingIn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DisableCollision(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.DisableCollision // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnTookSneakySnowman(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.OnTookSneakySnowman // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void SpawnParticles(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.SpawnParticles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnParticlesMulticast(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.SpawnParticlesMulticast // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Timeout(); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.Timeout // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Prop_SneakySnowmanV2(int32_t EntryPoint); // Function Athena_Prop_SneakySnowmanV2.Athena_Prop_SneakySnowmanV2_C.ExecuteUbergraph_Athena_Prop_SneakySnowmanV2 // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

