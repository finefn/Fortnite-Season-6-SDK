// BlueprintGeneratedClass B_Prj_Arrow_Stink_Athena.B_Prj_Arrow_Stink_Athena_C
// Size: 0xc60 (Inherited: 0xc38)
struct AB_Prj_Arrow_Stink_Athena_C : AB_Prj_Athena_Arrow_Generic_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc38(0x08)
	struct AFortAreaOfEffectCloud* StinkAoEClass; // 0xc40(0x08)
	struct FRotator ZeroRotator; // 0xc48(0x0c)
	char UnknownData_C54[0x4]; // 0xc54(0x04)
	struct ABuildingGameplayActor* StinkCloudBGAClass; // 0xc58(0x08)

	void OnFullyChargedImpact(struct FHitResult Hit Result); // Function B_Prj_Arrow_Stink_Athena.B_Prj_Arrow_Stink_Athena_C.OnFullyChargedImpact // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Arrow_Stink_Athena(int32_t EntryPoint); // Function B_Prj_Arrow_Stink_Athena.B_Prj_Arrow_Stink_Athena_C.ExecuteUbergraph_B_Prj_Arrow_Stink_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

