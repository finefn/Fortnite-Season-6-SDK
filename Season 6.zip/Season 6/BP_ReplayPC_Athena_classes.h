// BlueprintGeneratedClass BP_ReplayPC_Athena.BP_ReplayPC_Athena_C
// Size: 0x3af0 (Inherited: 0x3a30)
struct ABP_ReplayPC_Athena_C : AFortReplaySpectatorAthena {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a30(0x08)
	struct UPostProcessComponent* PostProcess; // 0x3a38(0x08)
	struct UUnderwaterAudioComponent_C* UnderwaterAudioComponent; // 0x3a40(0x08)
	struct TMap<float, struct USoundMix*> PlaybackRateMap; // 0x3a48(0x50)
	float CurrentPlayRate; // 0x3a98(0x04)
	bool bIsFast; // 0x3a9c(0x01)
	char UnknownData_3A9D[0x3]; // 0x3a9d(0x03)
	struct UAudioComponent* SpeedupLoop; // 0x3aa0(0x08)
	struct UAudioComponent* SlowdownLoop; // 0x3aa8(0x08)
	bool bIsHudVisible; // 0x3ab0(0x01)
	char UnknownData_3AB1[0x7]; // 0x3ab1(0x07)
	struct UAudioComponent* ZoomOutLoop; // 0x3ab8(0x08)
	struct UAudioComponent* ZoomInLoop; // 0x3ac0(0x08)
	bool bIsSkydivingAudioEnabled; // 0x3ac8(0x01)
	bool bIsTargetParachuting; // 0x3ac9(0x01)
	bool bIsTargetSkydiving; // 0x3aca(0x01)
	char UnknownData_3ACB[0x5]; // 0x3acb(0x05)
	struct UAudioComponent* SkydivingAudioLoop; // 0x3ad0(0x08)
	bool bIsPaused; // 0x3ad8(0x01)
	char UnknownData_3AD9[0x7]; // 0x3ad9(0x07)
	struct USoundBase* CurrentSkydivingSound; // 0x3ae0(0x08)
	struct USoundMix* PauseMIx; // 0x3ae8(0x08)

	void IsGameplayCamera(bool IsGameplayCamera); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.IsGameplayCamera // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetSkydivingAudioEnabled(bool Enabled); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.SetSkydivingAudioEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct USoundBase* GetSkydivingSound(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.GetSkydivingSound // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void UserConstructionScript(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnNotifyNewPlaybackMultiplier(float NewMultiplier); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.OnNotifyNewPlaybackMultiplier // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void  Speedup Loops(float Playback Multiplier); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C. Speedup Loops // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnReplayHudVisibilityChanged(enum class EHudVisibilityState IsVisible); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.OnReplayHudVisibilityChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnZoomOutEnd(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.OnZoomOutEnd // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnZoomOutBegin(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.OnZoomOutBegin // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnZoomInEnd(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.OnZoomInEnd // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnZoomInBegin(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.OnZoomInBegin // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void On Pause State Changed(bool bPaused); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.On Pause State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Handle Parachute Audio State(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.Handle Parachute Audio State // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Looping Audio Update(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.Looping Audio Update // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update Sound Mix(); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.Update Sound Mix // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_ReplayPC_Athena(int32_t EntryPoint); // Function BP_ReplayPC_Athena.BP_ReplayPC_Athena_C.ExecuteUbergraph_BP_ReplayPC_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

