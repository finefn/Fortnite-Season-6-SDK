// WidgetBlueprintGeneratedClass BattlePassRewardChallengesEntry.BattlePassRewardChallengesEntry_C
// Size: 0x2d0 (Inherited: 0x2a8)
struct UBattlePassRewardChallengesEntry_C : UBattlePassRewardChallengesEntry {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a8(0x08)
	struct UWidgetSwitcher* CheckSwitcher; // 0x2b0(0x08)
	struct UCommonTextBlock* DoneTag; // 0x2b8(0x08)
	struct UImage* Empty; // 0x2c0(0x08)
	struct UHorizontalBox* ProgressHB; // 0x2c8(0x08)

	void OnChallengeComplete(); // Function BattlePassRewardChallengesEntry.BattlePassRewardChallengesEntry_C.OnChallengeComplete // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnResetChallenge(); // Function BattlePassRewardChallengesEntry.BattlePassRewardChallengesEntry_C.OnResetChallenge // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BattlePassRewardChallengesEntry(int32_t EntryPoint); // Function BattlePassRewardChallengesEntry.BattlePassRewardChallengesEntry_C.ExecuteUbergraph_BattlePassRewardChallengesEntry // (Final|UbergraphFunction) // @ game+0xbd830c
};

