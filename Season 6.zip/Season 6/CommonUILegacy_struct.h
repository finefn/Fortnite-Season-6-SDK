// Enum CommonUILegacy.EOperation
enum class EOperation : uint8 {
	Intro,
	Outro,
	Push,
	Pop,
	Invalid,
	EOperation_MAX,
};

// ScriptStruct CommonUILegacy.Operation
// Size: 0x28 (Inherited: 0x00)
struct FOperation {
	enum class EOperation Operation; // 0x00(0x01)
	char UnknownData_1[0x7]; // 0x01(0x07)
	struct UCommonActivatablePanel* Panel; // 0x08(0x08)
	bool bIntroPanel; // 0x10(0x01)
	bool bActivatePanel; // 0x11(0x01)
	bool bOutroPanelBelow; // 0x12(0x01)
	char UnknownData_13[0x15]; // 0x13(0x15)
};

