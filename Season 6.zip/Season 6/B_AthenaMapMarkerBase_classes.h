// BlueprintGeneratedClass B_AthenaMapMarkerBase.B_AthenaMapMarkerBase_C
// Size: 0x558 (Inherited: 0x418)
struct AB_AthenaMapMarkerBase_C : AFortPlayerMarkerBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x418(0x08)
	struct UStaticMeshComponent* PingMarkerProto; // 0x420(0x08)
	struct UStaticMeshComponent* SM-Target; // 0x428(0x08)
	float OnProtoMarkerPlaced_RampPow_83EEC58A4783B077FB03728C433B4B7E; // 0x430(0x04)
	float OnProtoMarkerPlaced_Pinch_83EEC58A4783B077FB03728C433B4B7E; // 0x434(0x04)
	float OnProtoMarkerPlaced_Glow_83EEC58A4783B077FB03728C433B4B7E; // 0x438(0x04)
	enum class ETimelineDirection OnProtoMarkerPlaced__Direction_83EEC58A4783B077FB03728C433B4B7E; // 0x43c(0x01)
	char UnknownData_43D[0x3]; // 0x43d(0x03)
	struct UTimelineComponent* OnProtoMarkerPlaced; // 0x440(0x08)
	bool bUseProtoMarker; // 0x448(0x01)
	char UnknownData_449[0x7]; // 0x449(0x07)
	struct UMaterialInstanceDynamic* MIDProtoMarker; // 0x450(0x08)
	struct FFortWorldMarkerData MarkerData; // 0x458(0x100)

	void UserConstructionScript(); // Function B_AthenaMapMarkerBase.B_AthenaMapMarkerBase_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnProtoMarkerPlaced__FinishedFunc(); // Function B_AthenaMapMarkerBase.B_AthenaMapMarkerBase_C.OnProtoMarkerPlaced__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnProtoMarkerPlaced__UpdateFunc(); // Function B_AthenaMapMarkerBase.B_AthenaMapMarkerBase_C.OnProtoMarkerPlaced__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnMarkerPlaced(); // Function B_AthenaMapMarkerBase.B_AthenaMapMarkerBase_C.OnMarkerPlaced // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnSetupMarker(struct FFortWorldMarkerData MarkerData); // Function B_AthenaMapMarkerBase.B_AthenaMapMarkerBase_C.OnSetupMarker // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnMarkerColorChanged(struct FLinearColor InColor); // Function B_AthenaMapMarkerBase.B_AthenaMapMarkerBase_C.OnMarkerColorChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_AthenaMapMarkerBase(int32_t EntryPoint); // Function B_AthenaMapMarkerBase.B_AthenaMapMarkerBase_C.ExecuteUbergraph_B_AthenaMapMarkerBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

