// BlueprintGeneratedClass B_HidingProp.B_HidingProp_C
// Size: 0xeb8 (Inherited: 0xbc0)
struct AB_HidingProp_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc0(0x08)
	struct USceneComponent* ProjectileLocation_ForwardVector; // 0xbc8(0x08)
	struct UStaticMeshComponent* LandedOnCollisionMesh; // 0xbd0(0x08)
	struct USphereComponent* Sphere; // 0xbd8(0x08)
	struct USceneComponent* HideLocation_ForwardVector; // 0xbe0(0x08)
	struct FScalableFloat Enabled; // 0xbe8(0x28)
	struct FScalableFloat HidingEnabled; // 0xc10(0x28)
	struct FScalableFloat PlayerLimit; // 0xc38(0x28)
	struct FScalableFloat TeleportEnabled; // 0xc60(0x28)
	struct FScalableFloat CanTeleport; // 0xc88(0x28)
	struct TArray<struct AFortPawn*> HidingPlayers; // 0xcb0(0x10)
	struct FGameplayTag EnterGameplayCue; // 0xcc0(0x08)
	struct FGameplayTag ExitGameplayCue; // 0xcc8(0x08)
	struct FGameplayTag LandedOnGameplayCue; // 0xcd0(0x08)
	struct UMaterialInstanceDynamic* Mid; // 0xcd8(0x08)
	struct FGameplayTag RustleGameplayCue; // 0xce0(0x08)
	struct FGameplayTag ExitGameplayCue_Player; // 0xce8(0x08)
	struct FGameplayTag WhileEnteringGameplayCue; // 0xcf0(0x08)
	float ObstructionTraceLength; // 0xcf8(0x04)
	char UnknownData_CFC[0x4]; // 0xcfc(0x04)
	struct TArray<enum class EObjectTypeQuery> DestroyObjectTypes; // 0xd00(0x10)
	struct TArray<struct AFortPawn*> Array; // 0xd10(0x10)
	int32_t Int; // 0xd20(0x04)
	struct FVector DeimosPropSpawnerOffset; // 0xd24(0x0c)
	bool FixedEntranceDirection; // 0xd30(0x01)
	char UnknownData_D31[0x3]; // 0xd31(0x03)
	float MaxInteractAngle; // 0xd34(0x04)
	struct FVector WobbleLocationOffset; // 0xd38(0x0c)
	float InteractBelowPropDistance; // 0xd44(0x04)
	struct TMap<struct AFortPawn*, float> HiddenPlayersAndEnterTimes; // 0xd48(0x50)
	struct AFortPawn* LastPawnToInteract; // 0xd98(0x08)
	struct AB_HidingProp_C* TargetTeleporter; // 0xda0(0x08)
	struct FGameplayTag TeleporterEnterGameplayCue; // 0xda8(0x08)
	struct FGameplayTag TeleporterExitGameplayCue; // 0xdb0(0x08)
	struct FGameplayTag LoopingTeleportingCue; // 0xdb8(0x08)
	struct FGameplayTag GC_Wobble; // 0xdc0(0x08)
	struct FTimerHandle WobbleTimerHandle; // 0xdc8(0x08)
	struct TArray<struct FGameplayTag> BlockEntranceTags; // 0xdd0(0x10)
	struct TArray<struct FGameplayTag> BlockExitTags; // 0xde0(0x10)
	struct UAnimMontage* EnterAnimMontage; // 0xdf0(0x08)
	struct UAnimMontage* ExitAnimMontage; // 0xdf8(0x08)
	struct AFortPawn* LastPawnToHide; // 0xe00(0x08)
	struct FGameplayTag TeleportingStateGC; // 0xe08(0x08)
	bool RandomWobbleNormal; // 0xe10(0x01)
	bool SingleOccupant; // 0xe11(0x01)
	bool Teleporting; // 0xe12(0x01)
	bool JumpOut; // 0xe13(0x01)
	bool DestroyInNonSpyLTM; // 0xe14(0x01)
	bool ActiveInSpyLTM; // 0xe15(0x01)
	char UnknownData_E16[0x2]; // 0xe16(0x02)
	struct TArray<struct FGameplayTag> ForceAllowInteractTags; // 0xe18(0x10)
	struct FGameplayTag IsTeleporter; // 0xe28(0x08)
	struct FGameplayTag ContainsPlayerRepNof; // 0xe30(0x08)
	struct FVector ObstructionTraceExtents; // 0xe38(0x0c)
	struct FVector ObstructionTraceStartOffSet; // 0xe44(0x0c)
	float ExitLaunchVelocity; // 0xe50(0x04)
	struct FVector AdditionalLaunchVelocity; // 0xe54(0x0c)
	struct FVector FixedEntraceObstructionTraceEndOffset; // 0xe60(0x0c)
	bool isActiveTeleportExit; // 0xe6c(0x01)
	char UnknownData_E6D[0x3]; // 0xe6d(0x03)
	struct UGameplayEffect* GE_TeleportAbilityGranted; // 0xe70(0x08)
	bool DisableWhenSubmergedInWater; // 0xe78(0x01)
	char UnknownData_E79[0x7]; // 0xe79(0x07)
	struct FGameplayTagContainer DisableWhenSubmergedExceptionTags; // 0xe80(0x20)
	struct TArray<struct AFortPawn*> NonCosmeticPawns; // 0xea0(0x10)
	struct UCameraModifier* CameraModifier; // 0xeb0(0x08)

	void Allow Cosmetics For Pawn(struct AFortPawn* Pawn, bool Allow); // Function B_HidingProp.B_HidingProp_C.Allow Cosmetics For Pawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_ContainsPlayer(); // Function B_HidingProp.B_HidingProp_C.OnRep_ContainsPlayer // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_IsTeleporter(); // Function B_HidingProp.B_HidingProp_C.OnRep_IsTeleporter // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool CheckCanUsePassage(struct UObject* Object); // Function B_HidingProp.B_HidingProp_C.CheckCanUsePassage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool IsInInfiltrationLTM(); // Function B_HidingProp.B_HidingProp_C.IsInInfiltrationLTM // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void OnRep_Teleporting(); // Function B_HidingProp.B_HidingProp_C.OnRep_Teleporting // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetFailedInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetFailedInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void RemoveHiddenPlayer(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.RemoveHiddenPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AddHiddenPlayer(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.AddHiddenPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_HidingPlayers(); // Function B_HidingProp.B_HidingProp_C.OnRep_HidingPlayers // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function B_HidingProp.B_HidingProp_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void OnReady_64CBF02E419FF250B433D5B2A6E5D744(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function B_HidingProp.B_HidingProp_C.OnReady_64CBF02E419FF250B433D5B2A6E5D744 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnCurieActive_F2BFC8C54691C42FB5230BA7B7DEE141(); // Function B_HidingProp.B_HidingProp_C.OnCurieActive_F2BFC8C54691C42FB5230BA7B7DEE141 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function B_HidingProp.B_HidingProp_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__S_Athena_Launchpad_Collision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function B_HidingProp.B_HidingProp_C.BndEvt__S_Athena_Launchpad_Collision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void LandedOnHayStack(struct AFortPlayerPawn* PlayerPawn, float Z Velocity Mag); // Function B_HidingProp.B_HidingProp_C.LandedOnHayStack // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void LaunchPlayersOffTop(struct AFortPlayerPawn* PlayerPawn); // Function B_HidingProp.B_HidingProp_C.LaunchPlayersOffTop // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function B_HidingProp.B_HidingProp_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void StopHidingLoop(); // Function B_HidingProp.B_HidingProp_C.StopHidingLoop // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HidingPlayerCountChanged(); // Function B_HidingProp.B_HidingProp_C.HidingPlayerCountChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void InteractEnter(); // Function B_HidingProp.B_HidingProp_C.InteractEnter // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void EndHidingAnalyticSession(struct AFortPawn* FortPawn, enum class EEnvironmentalItemEndReason EndReason); // Function B_HidingProp.B_HidingProp_C.EndHidingAnalyticSession // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void WatchForPlayerDeath(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.WatchForPlayerDeath // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Pawn Died(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_HidingProp.B_HidingProp_C.Pawn Died // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StopHiding(struct AFortPawn* Pawn); // Function B_HidingProp.B_HidingProp_C.StopHiding // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_HidingProp.B_HidingProp_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Teleport(struct AActor* Pawn); // Function B_HidingProp.B_HidingProp_C.Teleport // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void IgnorePawnCollision(struct AFortPawn* Target, float InIgnoreDuration); // Function B_HidingProp.B_HidingProp_C.IgnorePawnCollision // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ToggleCameraCollisionForClients(); // Function B_HidingProp.B_HidingProp_C.ToggleCameraCollisionForClients // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StartHiding(struct AFortPawn* InteractingPawn); // Function B_HidingProp.B_HidingProp_C.StartHiding // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TurnClientCameraCollisionOn(); // Function B_HidingProp.B_HidingProp_C.TurnClientCameraCollisionOn // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters CueParameters); // Function B_HidingProp.B_HidingProp_C.AddGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void RemoveGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters CueParameters); // Function B_HidingProp.B_HidingProp_C.RemoveGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters CueParameters); // Function B_HidingProp.B_HidingProp_C.ExecuteGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnMatchStarted(); // Function B_HidingProp.B_HidingProp_C.OnMatchStarted // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_HidingProp(int32_t EntryPoint); // Function B_HidingProp.B_HidingProp_C.ExecuteUbergraph_B_HidingProp // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

