// WidgetBlueprintGeneratedClass AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C
// Size: 0xdf4 (Inherited: 0xcb8)
struct UAthenaCustomizationSlotButton_C : UAthenaCustomizationSlotSelectorButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xcb8(0x08)
	struct UWidgetAnimation* WarningPulse; // 0xcc0(0x08)
	struct UWidgetAnimation* OnBackedOutFromSelection; // 0xcc8(0x08)
	struct UWidgetAnimation* OnConfirmedSelection; // 0xcd0(0x08)
	struct UWidgetAnimation* OnSelected; // 0xcd8(0x08)
	struct UWidgetAnimation* OnHover; // 0xce0(0x08)
	struct UImage* ConfirmSelectionFlash; // 0xce8(0x08)
	struct UImage* ConfirmSelectionShine; // 0xcf0(0x08)
	struct UImage* ExclusiveFill; // 0xcf8(0x08)
	struct UOverlay* ExclusiveWarningOvr; // 0xd00(0x08)
	struct UFortLazyImage* Image_Empty; // 0xd08(0x08)
	struct UImage* InactiveFilledSlot; // 0xd10(0x08)
	struct UCommonTextBlock* Text_Plus; // 0xd18(0x08)
	struct FText TooltipBody; // 0xd20(0x18)
	struct FText TooltipHeader; // 0xd38(0x18)
	bool ShowSubTypeIcon; // 0xd50(0x01)
	char UnknownData_D51[0x7]; // 0xd51(0x07)
	struct FSlateBrush SubTypeIcon; // 0xd58(0x88)
	bool bSuppressTooltip; // 0xde0(0x01)
	char UnknownData_DE1[0x3]; // 0xde1(0x03)
	float TypeIconVerticalOffset; // 0xde4(0x04)
	struct UMaterialInstanceDynamic* ImageEmptyMID; // 0xde8(0x08)
	float WidthThreshold; // 0xdf0(0x04)

	void HandleWidthChanged(float Width); // Function AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C.HandleWidthChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FString GetSlotDebugName(); // Function AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C.GetSlotDebugName // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void HandleActiveStateChanged(bool CosmeticAvailable, bool Active); // Function AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C.HandleActiveStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnCustomizationSlotActiveStateChanged(bool bInAttachableCosmeticAvailable, bool bInActive); // Function AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C.OnCustomizationSlotActiveStateChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnCardImageAndWidthChanged(struct TSoftObjectPtr<struct UTexture2D> Image, float Width); // Function AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C.OnCardImageAndWidthChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnUpdateExclusiveWarning(bool bShouldWarn); // Function AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C.OnUpdateExclusiveWarning // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaCustomizationSlotButton(int32_t EntryPoint); // Function AthenaCustomizationSlotButton.AthenaCustomizationSlotButton_C.ExecuteUbergraph_AthenaCustomizationSlotButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

