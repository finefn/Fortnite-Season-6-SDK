// BlueprintGeneratedClass B_Athena_Boulder_SpawnedSpawner.B_Athena_Boulder_SpawnedSpawner_C
// Size: 0x328 (Inherited: 0x2c4)
struct AB_Athena_Boulder_SpawnedSpawner_C : AB_ActorSpawner_Parent_C {
	char UnknownData_2C4[0x4]; // 0x2c4(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct FScalableFloat Row_SpawnPhysicsVersion; // 0x2d0(0x28)
	struct AActor* PhysicsVersion; // 0x2f8(0x08)
	struct AActor* NonPhysicsVersion; // 0x300(0x08)
	struct FGameplayTagContainer QuestTags; // 0x308(0x20)

	void OnReady_47210EB345FB102E3FA9A783F925F623(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function B_Athena_Boulder_SpawnedSpawner.B_Athena_Boulder_SpawnedSpawner_C.OnReady_47210EB345FB102E3FA9A783F925F623 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Athena_Boulder_SpawnedSpawner.B_Athena_Boulder_SpawnedSpawner_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ServerActorSpawned(struct AActor* Actor); // Function B_Athena_Boulder_SpawnedSpawner.B_Athena_Boulder_SpawnedSpawner_C.ServerActorSpawned // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Athena_Boulder_SpawnedSpawner(int32_t EntryPoint); // Function B_Athena_Boulder_SpawnedSpawner.B_Athena_Boulder_SpawnedSpawner_C.ExecuteUbergraph_B_Athena_Boulder_SpawnedSpawner // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

