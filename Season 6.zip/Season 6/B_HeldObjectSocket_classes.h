// BlueprintGeneratedClass B_HeldObjectSocket.B_HeldObjectSocket_C
// Size: 0x828 (Inherited: 0x7d8)
struct AB_HeldObjectSocket_C : ABuildingGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7d8(0x08)
	struct USceneComponent* SocketLocation; // 0x7e0(0x08)
	struct USphereComponent* Sphere; // 0x7e8(0x08)
	bool HasSocketedHeldObject; // 0x7f0(0x01)
	char UnknownData_7F1[0x7]; // 0x7f1(0x07)
	struct AB_HeldObject_Parent_C* HeldObject; // 0x7f8(0x08)
	struct FGameplayTagContainer RequiredHeldObjectTags; // 0x800(0x20)
	struct AB_HeldObjectSocketManager_C* HeldObjectSocketManager; // 0x820(0x08)

	void ValidateHeldObject(struct AB_HeldObject_Parent_C* HeldObject Input, struct AB_HeldObject_Parent_C* HeldObject Output, bool IsValid); // Function B_HeldObjectSocket.B_HeldObjectSocket_C.ValidateHeldObject // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_SocketIsFilled(); // Function B_HeldObjectSocket.B_HeldObjectSocket_C.OnRep_SocketIsFilled // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_HeldObjectSocket.B_HeldObjectSocket_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnHitHeldObject(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult Hit); // Function B_HeldObjectSocket.B_HeldObjectSocket_C.OnHitHeldObject // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void EventOnSocketFilled(); // Function B_HeldObjectSocket.B_HeldObjectSocket_C.EventOnSocketFilled // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void EventOnSocketEmptied(); // Function B_HeldObjectSocket.B_HeldObjectSocket_C.EventOnSocketEmptied // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_HeldObjectSocket(int32_t EntryPoint); // Function B_HeldObjectSocket.B_HeldObjectSocket_C.ExecuteUbergraph_B_HeldObjectSocket // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

