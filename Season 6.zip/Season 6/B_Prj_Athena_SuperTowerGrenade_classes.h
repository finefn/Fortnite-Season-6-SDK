// BlueprintGeneratedClass B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C
// Size: 0xab1 (Inherited: 0x898)
struct AB_Prj_Athena_SuperTowerGrenade_C : AFortSuperTowerGrenadeProjectile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x898(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x8a0(0x08)
	struct UStaticMeshComponent* Mesh; // 0x8a8(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x8b0(0x08)
	struct FVector BaseDestination; // 0x8b8(0x0c)
	char UnknownData_8C4[0x4]; // 0x8c4(0x04)
	struct UParticleSystem* P_BuildBuilding; // 0x8c8(0x08)
	struct USoundBase* Cue_CloseSound; // 0x8d0(0x08)
	struct USoundBase* Cue_DistantSound; // 0x8d8(0x08)
	struct FVector GridExplosionOffset; // 0x8e0(0x0c)
	float GridSizeXY; // 0x8ec(0x04)
	float GridSizeZ; // 0x8f0(0x04)
	float GridYOffset; // 0x8f4(0x04)
	float GridZOffset; // 0x8f8(0x04)
	enum class ECardinalDirection CardinalDirection; // 0x8fc(0x01)
	char UnknownData_8FD[0x3]; // 0x8fd(0x03)
	struct TMap<enum class ECardinalDirection, float> OrientationYawOffsets; // 0x900(0x50)
	struct TMap<enum class ECardinalDirection, struct FVector> OrientationLocationOffsets; // 0x950(0x50)
	bool IsDebug; // 0x9a0(0x01)
	char UnknownData_9A1[0x3]; // 0x9a1(0x03)
	float TireBuildDelay; // 0x9a4(0x04)
	struct TArray<struct FVector> ClearedCells_Normal; // 0x9a8(0x10)
	struct FVector LastBounceLocation; // 0x9b8(0x0c)
	float MinBounceDistance; // 0x9c4(0x04)
	float LastBounceTime; // 0x9c8(0x04)
	float MinTimeBetweenBounces; // 0x9cc(0x04)
	struct USoundBase* BounceSound; // 0x9d0(0x08)
	struct TArray<struct FVector> ClearedCells_Underground; // 0x9d8(0x10)
	struct TArray<struct AActor*> BGAClasses_Tires; // 0x9e8(0x10)
	struct TArray<struct FVector> BGALocations_Tires; // 0x9f8(0x10)
	struct TArray<struct FRotator> BGARotations_Tires; // 0xa08(0x10)
	struct TMap<enum class ECardinalDirection, struct FVector> OrientationDoortraceOffsets; // 0xa18(0x50)
	struct FVector DoorTraceOffsetHigh; // 0xa68(0x0c)
	struct FVector DoorTraceOffsetLow; // 0xa74(0x0c)
	bool b_HitTerrain; // 0xa80(0x01)
	char UnknownData_A81[0x7]; // 0xa81(0x07)
	struct USoundBase* InAirLoopSound; // 0xa88(0x08)
	struct UAudioComponent* InAirLoopComponent; // 0xa90(0x08)
	float BounceTimeout; // 0xa98(0x04)
	char UnknownData_A9C[0x4]; // 0xa9c(0x04)
	struct AActor* BuilderClass; // 0xaa0(0x08)
	struct AActor* BuilderClassBasement; // 0xaa8(0x08)
	bool b_SpawnTires; // 0xab0(0x01)

	void ClearOnly(struct TArray<struct FVector> ClearedGridCells, bool DestroyFloorsQuickly); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.ClearOnly // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CallDynamicBuilder(struct AActor* Class, struct FVector Location); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.CallDynamicBuilder // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CalculateCardinalDirection(); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.CalculateCardinalDirection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleProps(struct TArray<struct AActor*> Array); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.HandleProps // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnTires(struct FVector ReferenceLocation); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.SpawnTires // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ClearAndBuild(struct TArray<struct FVector> ClearedGridCells, struct TArray<struct AActor*> BGAClassArray, struct TArray<struct FVector> BGALocationArray, struct TArray<struct FRotator> BGARotationArray, bool DestroyFloorsQuickly); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.ClearAndBuild // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CreateBaseSection(struct FVector ReferenceLocation, struct TArray<struct AActor*> BGAClassArray, struct TArray<struct FVector> BGALocationArray, struct TArray<struct FRotator> BGARotationArray); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.CreateBaseSection // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetBaseDestination(struct FHitResult Hit); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.SetBaseDestination // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStop(struct FHitResult Hit); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Handle Bounce(struct FVector Hit Location); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.Handle Bounce // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Delete another actor(); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.Delete another actor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_SuperTowerGrenade(int32_t EntryPoint); // Function B_Prj_Athena_SuperTowerGrenade.B_Prj_Athena_SuperTowerGrenade_C.ExecuteUbergraph_B_Prj_Athena_SuperTowerGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

