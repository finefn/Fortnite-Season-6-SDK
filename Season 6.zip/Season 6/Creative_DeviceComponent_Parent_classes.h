// BlueprintGeneratedClass Creative_DeviceComponent_Parent.Creative_DeviceComponent_Parent_C
// Size: 0xb8 (Inherited: 0xb0)
struct UCreative_DeviceComponent_Parent_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)

	void Owning Actor Activated(); // Function Creative_DeviceComponent_Parent.Creative_DeviceComponent_Parent_C.Owning Actor Activated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Owning Actor Initialized(); // Function Creative_DeviceComponent_Parent.Creative_DeviceComponent_Parent_C.Owning Actor Initialized // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Creative_DeviceComponent_Parent.Creative_DeviceComponent_Parent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Creative_DeviceComponent_Parent(int32_t EntryPoint); // Function Creative_DeviceComponent_Parent.Creative_DeviceComponent_Parent_C.ExecuteUbergraph_Creative_DeviceComponent_Parent // (Final|UbergraphFunction) // @ game+0xbd830c
};

