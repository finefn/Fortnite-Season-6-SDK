// BlueprintGeneratedClass BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C
// Size: 0xb08 (Inherited: 0xad8)
struct ABP_DamageBalloon_Athena_C : ABuildingSMActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xad8(0x08)
	struct UParticleSystemComponent* ExplosionParticle; // 0xae0(0x08)
	struct UFortHealthBarComponent* FortHealthBar; // 0xae8(0x08)
	bool DestroyBalloon; // 0xaf0(0x01)
	bool DontPlayDestroyAudio; // 0xaf1(0x01)
	char UnknownData_AF2[0x6]; // 0xaf2(0x06)
	struct FMulticastInlineDelegate OnBalloonDestroyed; // 0xaf8(0x10)

	void OnRep_DestroyBalloon(); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.OnRep_DestroyBalloon // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void CrateIsGone(); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.CrateIsGone // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_DamageBalloon_Athena(int32_t EntryPoint); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.ExecuteUbergraph_BP_DamageBalloon_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void OnBalloonDestroyed__DelegateSignature(); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.OnBalloonDestroyed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

