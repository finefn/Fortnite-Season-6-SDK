// BlueprintGeneratedClass BP_DetailLevelMesh.BP_DetailLevelMesh_C
// Size: 0x23a (Inherited: 0x220)
struct ABP_DetailLevelMesh_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	bool AlwaysVisible; // 0x238(0x01)
	bool NotVisibleOnSwitch; // 0x239(0x01)

	void ExecuteUbergraph_BP_DetailLevelMesh(int32_t EntryPoint); // Function BP_DetailLevelMesh.BP_DetailLevelMesh_C.ExecuteUbergraph_BP_DetailLevelMesh // (Final|UbergraphFunction) // @ game+0xbd830c
};

