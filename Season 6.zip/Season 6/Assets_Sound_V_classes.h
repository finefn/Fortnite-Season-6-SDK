// SolarisGeneratedClass Assets_Sound_V.Sound_V
// Size: 0x80 (Inherited: 0x80)
struct USound_V : UClientAsset {

	struct USound_V* createAndLoad(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_Sound_V.Sound_V.createAndLoad // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	struct USound_V* Create(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_Sound_V.Sound_V.Create // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	void $InitInstance(); // Function Assets_Sound_V.Sound_V.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Assets_Sound_V.Sound_V.$InitCDO // () // @ game+0xbd830c
};

