// WidgetBlueprintGeneratedClass CreativeLobbyAd.CreativeLobbyAd_C
// Size: 0x320 (Inherited: 0x2f8)
struct UCreativeLobbyAd_C : UFortCreativeAdTile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2f8(0x08)
	struct UCommonTextBlock* Text_Description; // 0x300(0x08)
	struct UCommonTextBlock* Text_Header; // 0x308(0x08)
	struct UCommonTextBlock* Text_SubHeader; // 0x310(0x08)
	struct UCommonBorder* Violator; // 0x318(0x08)

	void OnCMSDataUpdated(); // Function CreativeLobbyAd.CreativeLobbyAd_C.OnCMSDataUpdated // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function CreativeLobbyAd.CreativeLobbyAd_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function CreativeLobbyAd.CreativeLobbyAd_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CreativeLobbyAd(int32_t EntryPoint); // Function CreativeLobbyAd.CreativeLobbyAd_C.ExecuteUbergraph_CreativeLobbyAd // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

