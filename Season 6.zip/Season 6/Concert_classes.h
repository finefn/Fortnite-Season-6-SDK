// Class Concert.ConcertServerConfig
// Size: 0x128 (Inherited: 0x28)
struct UConcertServerConfig : UObject {
	bool bAutoArchiveOnReboot; // 0x28(0x01)
	bool bAutoArchiveOnShutdown; // 0x29(0x01)
	bool bCleanWorkingDir; // 0x2a(0x01)
	char UnknownData_2B[0x1]; // 0x2b(0x01)
	int32_t NumSessionsToKeep; // 0x2c(0x04)
	struct FString ServerName; // 0x30(0x10)
	struct FString DefaultSessionName; // 0x40(0x10)
	struct TSet<struct FString> AuthorizedClientKeys; // 0x50(0x50)
	struct FString DefaultSessionToRestore; // 0xa0(0x10)
	struct FConcertSessionSettings DefaultSessionSettings; // 0xb0(0x28)
	struct FConcertServerSettings ServerSettings; // 0xd8(0x08)
	struct FConcertEndpointSettings EndpointSettings; // 0xe0(0x0c)
	char UnknownData_EC[0x4]; // 0xec(0x04)
	struct FString WorkingDir; // 0xf0(0x10)
	struct FString ArchiveDir; // 0x100(0x10)
	struct FString SessionRepositoryRootDir; // 0x110(0x10)
	bool bMountDefaultSessionRepository; // 0x120(0x01)
	char UnknownData_121[0x7]; // 0x121(0x07)
};

// Class Concert.ConcertClientConfig
// Size: 0x100 (Inherited: 0x28)
struct UConcertClientConfig : UObject {
	bool bIsHeadless; // 0x28(0x01)
	bool bInstallEditorToolbarButton; // 0x29(0x01)
	bool bAutoConnect; // 0x2a(0x01)
	bool bRetryAutoConnectOnError; // 0x2b(0x01)
	char UnknownData_2C[0x4]; // 0x2c(0x04)
	struct FString DefaultServerURL; // 0x30(0x10)
	struct FString DefaultSessionName; // 0x40(0x10)
	struct FString DefaultSessionToRestore; // 0x50(0x10)
	struct FString DefaultSaveSessionAs; // 0x60(0x10)
	struct FConcertClientSettings ClientSettings; // 0x70(0x80)
	struct FConcertSourceControlSettings SourceControlSettings; // 0xf0(0x01)
	char UnknownData_F1[0x3]; // 0xf1(0x03)
	struct FConcertEndpointSettings EndpointSettings; // 0xf4(0x0c)
};

