// BlueprintGeneratedClass B_Prj_Bow_ClusterBomb_Secondary_Athena.B_Prj_Bow_ClusterBomb_Secondary_Athena_C
// Size: 0xa58 (Inherited: 0x9e8)
struct AB_Prj_Bow_ClusterBomb_Secondary_Athena_C : AB_Prj_Athena_Grenade_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9e8(0x08)
	struct UParticleSystemComponent* Trail; // 0x9f0(0x08)
	struct FScalableFloat MinExplodeDelay; // 0x9f8(0x28)
	struct FScalableFloat MaxExplodeDelay; // 0xa20(0x28)
	bool bUseRandomDelay; // 0xa48(0x01)
	char UnknownData_A49[0x7]; // 0xa49(0x07)
	struct USoundBase* Cue_LastExplosionSound; // 0xa50(0x08)

	void GetExplosionDelay(float Delay); // Function B_Prj_Bow_ClusterBomb_Secondary_Athena.B_Prj_Bow_ClusterBomb_Secondary_Athena_C.GetExplosionDelay // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Bow_ClusterBomb_Secondary_Athena.B_Prj_Bow_ClusterBomb_Secondary_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SetLastBomb(); // Function B_Prj_Bow_ClusterBomb_Secondary_Athena.B_Prj_Bow_ClusterBomb_Secondary_Athena_C.SetLastBomb // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Bow_ClusterBomb_Secondary_Athena(int32_t EntryPoint); // Function B_Prj_Bow_ClusterBomb_Secondary_Athena.B_Prj_Bow_ClusterBomb_Secondary_Athena_C.ExecuteUbergraph_B_Prj_Bow_ClusterBomb_Secondary_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

