// BlueprintGeneratedClass B_Grenade_Molotov_Athena.B_Grenade_Molotov_Athena_C
// Size: 0xd70 (Inherited: 0xd49)
struct AB_Grenade_Molotov_Athena_C : AB_ConsumableSmall_Athena_C {
	char UnknownData_D49[0x7]; // 0xd49(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd50(0x08)
	struct UAudioComponent* AmbientAudio; // 0xd58(0x08)
	struct UNiagaraComponent* Niagara_Light; // 0xd60(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0xd68(0x08)

	void OnWeaponAttached(); // Function B_Grenade_Molotov_Athena.B_Grenade_Molotov_Athena_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void K2_OnUnEquip(); // Function B_Grenade_Molotov_Athena.B_Grenade_Molotov_Athena_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Grenade_Molotov_Athena(int32_t EntryPoint); // Function B_Grenade_Molotov_Athena.B_Grenade_Molotov_Athena_C.ExecuteUbergraph_B_Grenade_Molotov_Athena // (Final|UbergraphFunction) // @ game+0xbd830c
};

