// BlueprintGeneratedClass Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C
// Size: 0xd40 (Inherited: 0xce0)
struct AAthena_Prop_CoolCarpet_C : AAthena_Prop_SneakySnowmanV2_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xce0(0x08)
	struct UStaticMeshComponent* SM_ShadowInsert; // 0xce8(0x08)
	struct UStaticMeshComponent* SM_CoolCarpet_Flap2; // 0xcf0(0x08)
	struct UStaticMeshComponent* SM_CoolCarpet_Flap1; // 0xcf8(0x08)
	float OpenFlaps_Rotation_FDF331244F066E298266B69ACE6D4998; // 0xd00(0x04)
	enum class ETimelineDirection OpenFlaps__Direction_FDF331244F066E298266B69ACE6D4998; // 0xd04(0x01)
	char UnknownData_D05[0x3]; // 0xd05(0x03)
	struct UTimelineComponent* OpenFlaps; // 0xd08(0x08)
	int32_t RandMatInt; // 0xd10(0x04)
	int32_t MatIntOverride; // 0xd14(0x04)
	struct FScalableFloat CanHideInProp; // 0xd18(0x28)

	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void OnRep_MatIntOverride(); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.OnRep_MatIntOverride // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetMaterialInt(int32_t MatInt); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.GetMaterialInt // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OpenFlaps__FinishedFunc(); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.OpenFlaps__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void OpenFlaps__UpdateFunc(); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.OpenFlaps__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OpenFlapsMulticast(); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.OpenFlapsMulticast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CloseFlaps(); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.CloseFlaps // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Prop_CoolCarpet(int32_t EntryPoint); // Function Athena_Prop_CoolCarpet.Athena_Prop_CoolCarpet_C.ExecuteUbergraph_Athena_Prop_CoolCarpet // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

