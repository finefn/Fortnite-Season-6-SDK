// WidgetBlueprintGeneratedClass AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C
// Size: 0xc50 (Inherited: 0xbf0)
struct UAthenaMatchmakingModeButton_C : UCommonButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbf0(0x08)
	struct UWidgetAnimation* OnHover; // 0xbf8(0x08)
	struct UWidgetAnimation* ConfirmSelection; // 0xc00(0x08)
	struct UImage* ConfirmSelectionFlash; // 0xc08(0x08)
	struct UImage* ConfirmSelectionShine; // 0xc10(0x08)
	struct UImage* GameModeIcon; // 0xc18(0x08)
	struct UCommonTextBlock* GameModeName; // 0xc20(0x08)
	struct UImage* LTMModeSubIcon; // 0xc28(0x08)
	struct UCommonTextBlock* SubGameModeName; // 0xc30(0x08)
	struct UHorizontalBox* SubGameModeNameHB; // 0xc38(0x08)
	bool FillSquad; // 0xc40(0x01)
	char UnknownData_C41[0x7]; // 0xc41(0x07)
	struct UFortPlaylistAthena* PlaylistData; // 0xc48(0x08)

	void RefreshLimitedPoolWarning(bool IsCrossplayEnabled); // Function AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C.RefreshLimitedPoolWarning // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void RefreshFillText(); // Function AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C.RefreshFillText // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetSquadFillText(bool bFill); // Function AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C.SetSquadFillText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlaylistChanged(struct UFortPlaylistAthena* NewPlaylist, struct FText OverrideName); // Function AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C.PlaylistChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetTabLabelInfo(struct FFortTabButtonLabelInfo TabLabelInfo); // Function AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C.SetTabLabelInfo // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnMouseLeave(struct FPointerEvent MouseEvent); // Function AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaMatchmakingModeButton(int32_t EntryPoint); // Function AthenaMatchmakingModeButton.AthenaMatchmakingModeButton_C.ExecuteUbergraph_AthenaMatchmakingModeButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

