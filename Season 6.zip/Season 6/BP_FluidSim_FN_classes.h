// BlueprintGeneratedClass BP_FluidSim_FN.BP_FluidSim_FN_C
// Size: 0x549 (Inherited: 0x449)
struct ABP_FluidSim_FN_C : ABP_FluidSim_01_C {
	char UnknownData_449[0x7]; // 0x449(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x450(0x08)
	struct FFluidForceDynamic BoatForceSettings; // 0x458(0x70)
	struct FFluidForceDynamic PlayerForceSettings; // 0x4c8(0x70)
	struct TArray<struct AFortPawn*> RelevantFortPawns; // 0x538(0x10)
	bool Use FN Pawn Forces; // 0x548(0x01)

	void GetFortnitePawnForces(); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetFortnitePawnForces // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetLocalPawn(struct APawn* Pawn); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetLocalPawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void GetPlayerPawnForces(); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetPlayerPawnForces // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_FluidSim_FN(int32_t EntryPoint); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.ExecuteUbergraph_BP_FluidSim_FN // (Final|UbergraphFunction) // @ game+0xbd830c
};

