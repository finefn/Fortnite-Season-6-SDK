// WidgetBlueprintGeneratedClass AthenaEliminationIndicator.AthenaEliminationIndicator_C
// Size: 0x4e8 (Inherited: 0x4c0)
struct UAthenaEliminationIndicator_C : UAthenaEliminationIndicator {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c0(0x08)
	struct UWidgetAnimation* Outro; // 0x4c8(0x08)
	struct UWidgetAnimation* Intro; // 0x4d0(0x08)
	struct UImage* Arrow; // 0x4d8(0x08)
	struct UImage* Image_Diamondpulse; // 0x4e0(0x08)

	void Construct(); // Function AthenaEliminationIndicator.AthenaEliminationIndicator_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaEliminationIndicator(int32_t EntryPoint); // Function AthenaEliminationIndicator.AthenaEliminationIndicator_C.ExecuteUbergraph_AthenaEliminationIndicator // (Final|UbergraphFunction) // @ game+0xbd830c
};

