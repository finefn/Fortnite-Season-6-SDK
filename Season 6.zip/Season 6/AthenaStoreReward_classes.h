// WidgetBlueprintGeneratedClass AthenaStoreReward.AthenaStoreReward_C
// Size: 0xca0 (Inherited: 0xc50)
struct UAthenaStoreReward_C : UFortAthenaReward {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc50(0x08)
	struct UWidgetAnimation* Fade; // 0xc58(0x08)
	struct UWidgetAnimation* Intro; // 0xc60(0x08)
	struct UImage* baking; // 0xc68(0x08)
	struct UImage* Check; // 0xc70(0x08)
	struct UCommonTextBlock* OwnedText; // 0xc78(0x08)
	struct UImage* RarityFlare; // 0xc80(0x08)
	struct UImage* RevealOverlay; // 0xc88(0x08)
	struct UFortItem* StrongItemToRepresent; // 0xc90(0x08)
	struct USoundBase* SoundOnReveal; // 0xc98(0x08)

	void EnableRarityFlare(); // Function AthenaStoreReward.AthenaStoreReward_C.EnableRarityFlare // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayIntro(); // Function AthenaStoreReward.AthenaStoreReward_C.PlayIntro // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRepresentedItemSet(struct UFortItem* RepresentedItem); // Function AthenaStoreReward.AthenaStoreReward_C.OnRepresentedItemSet // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaStoreReward(int32_t EntryPoint); // Function AthenaStoreReward.AthenaStoreReward_C.ExecuteUbergraph_AthenaStoreReward // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

