// BlueprintGeneratedClass EnemyPawn_Interface.EnemyPawn_Interface_C
// Size: 0x28 (Inherited: 0x28)
struct UEnemyPawn_Interface_C : UInterface {

	void Orphaned(bool IsOrphaned, struct AFortPawn* AttachedPawn); // Function EnemyPawn_Interface.EnemyPawn_Interface_C.Orphaned // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

