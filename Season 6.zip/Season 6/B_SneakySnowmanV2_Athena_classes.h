// BlueprintGeneratedClass B_SneakySnowmanV2_Athena.B_SneakySnowmanV2_Athena_C
// Size: 0xd90 (Inherited: 0xd40)
struct AB_SneakySnowmanV2_Athena_C : AB_UtilityItem_Generic_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd40(0x08)
	struct UFortWorldItemDefinition* SnowmanItemDef; // 0xd48(0x08)
	struct AFortPlayerPawn* PlayerPawn; // 0xd50(0x08)
	struct FScalableFloat ShouldSnowmanInTurret; // 0xd58(0x28)
	struct TArray<struct UFortItem*> SnowmanItemInstances; // 0xd80(0x10)

	void K2_OnUnEquip(); // Function B_SneakySnowmanV2_Athena.B_SneakySnowmanV2_Athena_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_SneakySnowmanV2_Athena(int32_t EntryPoint); // Function B_SneakySnowmanV2_Athena.B_SneakySnowmanV2_Athena_C.ExecuteUbergraph_B_SneakySnowmanV2_Athena // (Final|UbergraphFunction) // @ game+0xbd830c
};

