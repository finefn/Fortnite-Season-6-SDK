// SolarisGeneratedClass Assets_ParticleSystem_V.ParticleSystem_V
// Size: 0x80 (Inherited: 0x80)
struct UParticleSystem_V : UClientAsset {

	struct UParticleSystem_V* createAndLoad(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_ParticleSystem_V.ParticleSystem_V.createAndLoad // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	struct UParticleSystem_V* Create(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_ParticleSystem_V.ParticleSystem_V.Create // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	void $InitInstance(); // Function Assets_ParticleSystem_V.ParticleSystem_V.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Assets_ParticleSystem_V.ParticleSystem_V.$InitCDO // () // @ game+0xbd830c
};

