// BlueprintGeneratedClass BattlePassVaultWorld.BattlePassVaultWorld_C
// Size: 0x340 (Inherited: 0x2c9)
struct ABattlePassVaultWorld_C : AVaultWorld_C {
	char UnknownData_2C9[0x7]; // 0x2c9(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct UStaticMeshComponent* Floor; // 0x2d8(0x08)
	float Floor_Visibility_FloorMask_CE7E338346E82397065B65AA77823F50; // 0x2e0(0x04)
	enum class ETimelineDirection Floor_Visibility__Direction_CE7E338346E82397065B65AA77823F50; // 0x2e4(0x01)
	char UnknownData_2E5[0x3]; // 0x2e5(0x03)
	struct UTimelineComponent* Floor-Visibility; // 0x2e8(0x08)
	float Background_Effects_SetStreaks_50767E4640E86998EC96B7B2D57E5E27; // 0x2f0(0x04)
	enum class ETimelineDirection Background_Effects__Direction_50767E4640E86998EC96B7B2D57E5E27; // 0x2f4(0x01)
	char UnknownData_2F5[0x3]; // 0x2f5(0x03)
	struct UTimelineComponent* Background-Effects; // 0x2f8(0x08)
	float TransitionForward_FX_Transition_Fade_46DACBD74D0A8B2278950785C007984A; // 0x300(0x04)
	float TransitionForward_Pre_TransitionOffset_46DACBD74D0A8B2278950785C007984A; // 0x304(0x04)
	float TransitionForward_Forward_46DACBD74D0A8B2278950785C007984A; // 0x308(0x04)
	enum class ETimelineDirection TransitionForward__Direction_46DACBD74D0A8B2278950785C007984A; // 0x30c(0x01)
	char UnknownData_30D[0x3]; // 0x30d(0x03)
	struct UTimelineComponent* TransitionForward; // 0x310(0x08)
	float TransitionBackward_fx_Transition_fade_7073CD0840227233D3A64795A5A1B1B8; // 0x318(0x04)
	float TransitionBackward_Pre_Transition_Offset_7073CD0840227233D3A64795A5A1B1B8; // 0x31c(0x04)
	float TransitionBackward_Backward_7073CD0840227233D3A64795A5A1B1B8; // 0x320(0x04)
	enum class ETimelineDirection TransitionBackward__Direction_7073CD0840227233D3A64795A5A1B1B8; // 0x324(0x01)
	char UnknownData_325[0x3]; // 0x325(0x03)
	struct UTimelineComponent* TransitionBackward; // 0x328(0x08)
	struct UMaterialInstance* FloorMI; // 0x330(0x08)
	struct UMaterialInstanceDynamic* FloorMID; // 0x338(0x08)

	void TransitionBackgroundBackward(float Backward, float PreTransitionOffset, float FXTransitionFade, struct UMaterialInstanceDynamic* Mid); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionBackgroundBackward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TransitionBackgroundForward(float Forward, float PreTransitionOffset, float FXTransitionFade, struct UMaterialInstanceDynamic* Mid); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionBackgroundForward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetupBackgroundMaterial(struct UTexture2D* TextureBackground, struct FTrackDynamicBackground BackgroundInfo, struct UMaterialInstanceDynamic* Mid); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.SetupBackgroundMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TransitionForward__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionForward__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void TransitionForward__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionForward__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void TransitionBackward__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionBackward__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void TransitionBackward__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionBackward__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void Background-Effects__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Background-Effects__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Background-Effects__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Background-Effects__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void Floor-Visibility__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Floor-Visibility__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Floor-Visibility__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Floor-Visibility__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnTransitionBackground(bool bPlayForward); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnTransitionBackground // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnSetupBackground(struct UTexture2D* LoadedBackgroundTexture, struct FTrackDynamicBackground BackgroundInfo); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnSetupBackground // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnUpdateDisplay(bool bShowFloor, bool bShowEffects); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnUpdateDisplay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnInitialBackgroundTransition(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnInitialBackgroundTransition // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BattlePassVaultWorld(int32_t EntryPoint); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.ExecuteUbergraph_BattlePassVaultWorld // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

