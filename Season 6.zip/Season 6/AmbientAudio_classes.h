// Class AmbientAudio.AmbientAudioDataAsset
// Size: 0x58 (Inherited: 0x30)
struct UAmbientAudioDataAsset : UDataAsset {
	struct TArray<struct FAmbientAudioLoop> LoopingSounds; // 0x30(0x10)
	struct TArray<struct FAmbientAudioOneShot> OneShotSounds; // 0x40(0x10)
	float TagCrossfadeTime; // 0x50(0x04)
	char UnknownData_54[0x4]; // 0x54(0x04)
};

// Class AmbientAudio.AmbientAudioStatics
// Size: 0x28 (Inherited: 0x28)
struct UAmbientAudioStatics : UBlueprintFunctionLibrary {

	void RemoveAmbientGameplayTag(struct UObject* WorldContextObject, struct FGameplayTag GameplayTag); // Function AmbientAudio.AmbientAudioStatics.RemoveAmbientGameplayTag // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xea8e48
	void RemoveAmbientEntry(struct UObject* WorldContextObject, struct FName AmbientName); // Function AmbientAudio.AmbientAudioStatics.RemoveAmbientEntry // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x3cfbed8
	void PlaySoundAtLocation(struct UObject* WorldContextObject, struct USoundBase* Sound, struct FVector Location); // Function AmbientAudio.AmbientAudioStatics.PlaySoundAtLocation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x3cfbda0
	struct UAudioComponent* CreateAudioComponent(struct UObject* WorldContextObject, struct USoundBase* Sound); // Function AmbientAudio.AmbientAudioStatics.CreateAudioComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x3cfbca0
	void AddAmbientGameplayTag(struct UObject* WorldContextObject, struct FGameplayTag GameplayTag); // Function AmbientAudio.AmbientAudioStatics.AddAmbientGameplayTag // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x3cfbb18
	void AddAmbientEntry(struct UObject* WorldContextObject, struct FName AmbientName, struct UAmbientAudioDataAsset* Asset, int32_t Priority, float CrossfadeTime); // Function AmbientAudio.AmbientAudioStatics.AddAmbientEntry // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xea8f68
};

// Class AmbientAudio.AmbientAudioSubsystem
// Size: 0x220 (Inherited: 0x30)
struct UAmbientAudioSubsystem : UWorldSubsystem {
	struct FMulticastInlineDelegate OnTagChanged; // 0x30(0x10)
	struct FMulticastInlineDelegate OnEntryChanged; // 0x40(0x10)
	struct TArray<struct AAmbientVolume*> GlobalVolumes; // 0x50(0x10)
	char UnknownData_60[0x1c0]; // 0x60(0x1c0)

	void RemoveGameplayTag(struct FGameplayTag GameplayTag); // Function AmbientAudio.AmbientAudioSubsystem.RemoveGameplayTag // (Final|Native|Public|BlueprintCallable) // @ game+0x3cfc074
	void RemoveAmbientEntry(struct FName AmbientName); // Function AmbientAudio.AmbientAudioSubsystem.RemoveAmbientEntry // (Final|Native|Public|BlueprintCallable) // @ game+0x3cfbfdc
	void AddGameplayTag(struct FGameplayTag GameplayTag); // Function AmbientAudio.AmbientAudioSubsystem.AddGameplayTag // (Final|Native|Public|BlueprintCallable) // @ game+0x3cfbc08
	void AddAmbientEntry(struct FName AmbientName, struct UAmbientAudioDataAsset* Asset, int32_t Priority, float CrossfadeTime); // Function AmbientAudio.AmbientAudioSubsystem.AddAmbientEntry // (Final|Native|Public|BlueprintCallable) // @ game+0x3cfb97c
};

// Class AmbientAudio.AmbientVolume
// Size: 0x270 (Inherited: 0x258)
struct AAmbientVolume : AVolume {
	struct UAmbientAudioDataAsset* AmbientAsset; // 0x258(0x08)
	int32_t Priority; // 0x260(0x04)
	float CrossfadeTime; // 0x264(0x04)
	char bEnabled : 1; // 0x268(0x01)
	char bGlobal : 1; // 0x268(0x01)
	char UnknownData_268_2 : 6; // 0x268(0x01)
	char UnknownData_269[0x7]; // 0x269(0x07)

	void SetPriority(int32_t NewPriority); // Function AmbientAudio.AmbientVolume.SetPriority // (Final|Native|Public|BlueprintCallable) // @ game+0x3cfc2e4
	void SetEnabled(bool bNewEnabled); // Function AmbientAudio.AmbientVolume.SetEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x3cfc248
	void SetCrossfadeTime(float NewCrossfadeTime); // Function AmbientAudio.AmbientVolume.SetCrossfadeTime // (Final|Native|Public|BlueprintCallable) // @ game+0x3cfc1a8
	void SetAmbientAsset(struct UAmbientAudioDataAsset* NewAmbientAsset); // Function AmbientAudio.AmbientVolume.SetAmbientAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x3cfc10c
	void OnRep_bEnabled(); // Function AmbientAudio.AmbientVolume.OnRep_bEnabled // (Native|Protected) // @ game+0x3cfbd88
};

