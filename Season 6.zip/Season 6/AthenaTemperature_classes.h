// WidgetBlueprintGeneratedClass AthenaTemperature.AthenaTemperature_C
// Size: 0x2a0 (Inherited: 0x298)
struct UAthenaTemperature_C : UAthenaTemperatureBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)

	void ShowTemperatureChanged(bool bShowTemperature); // Function AthenaTemperature.AthenaTemperature_C.ShowTemperatureChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function AthenaTemperature.AthenaTemperature_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaTemperature(int32_t EntryPoint); // Function AthenaTemperature.AthenaTemperature_C.ExecuteUbergraph_AthenaTemperature // (Final|UbergraphFunction) // @ game+0xbd830c
};

