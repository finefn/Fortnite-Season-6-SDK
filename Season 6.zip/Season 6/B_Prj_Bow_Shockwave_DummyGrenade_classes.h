// BlueprintGeneratedClass B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C
// Size: 0xac4 (Inherited: 0xa88)
struct AB_Prj_Bow_Shockwave_DummyGrenade_C : AB_Prj_Athena_ShockGrenade_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa88(0x08)
	bool bAttachedToPawn; // 0xa90(0x01)
	char UnknownData_A91[0x7]; // 0xa91(0x07)
	struct APlayerPawn_Athena_C* AttachedPawn; // 0xa98(0x08)
	float LaunchOffsetMagnitude; // 0xaa0(0x04)
	struct FVector LaunchOffset; // 0xaa4(0x0c)
	enum class EShockwaveBowSpecialAttachmentType SpecialAttachmentType; // 0xab0(0x01)
	char UnknownData_AB1[0x7]; // 0xab1(0x07)
	struct AActor* AttachedActor; // 0xab8(0x08)
	float PhysicsObjectLaunchZOffset; // 0xac0(0x04)

	void GetLaunchOriginForPhysicsObject(struct FVector LaunchOrigin); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.GetLaunchOriginForPhysicsObject // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void GetOffsetPoint(struct FVector OriginalLocation, struct FVector OffsetLocation); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.GetOffsetPoint // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void GetLaunchOriginForPawn(struct FVector LaunchOrigin); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.GetLaunchOriginForPawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void CheckSpecialAttachment(struct AActor* AttachedActor, struct FVector ArrowForwardVector); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.CheckSpecialAttachment // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetLaunchOffsetFromArrowDirection(struct FVector ArrowVelocity); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.SetLaunchOffsetFromArrowDirection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetLaunchOriginPoint(struct FVector HitLocation); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.GetLaunchOriginPoint // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void SetAttachedToPawn(struct APlayerPawn_Athena_C* Pawn); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.SetAttachedToPawn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Bow_Shockwave_DummyGrenade(int32_t EntryPoint); // Function B_Prj_Bow_Shockwave_DummyGrenade.B_Prj_Bow_Shockwave_DummyGrenade_C.ExecuteUbergraph_B_Prj_Bow_Shockwave_DummyGrenade // (Final|UbergraphFunction) // @ game+0xbd830c
};

