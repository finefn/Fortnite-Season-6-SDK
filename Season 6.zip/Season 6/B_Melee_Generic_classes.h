// BlueprintGeneratedClass B_Melee_Generic.B_Melee_Generic_C
// Size: 0xe78 (Inherited: 0xd40)
struct AB_Melee_Generic_C : AFortWeapon {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd40(0x08)
	struct UParticleSystemComponent* IdleFX; // 0xd48(0x08)
	struct UParticleSystemComponent* SwingFX; // 0xd50(0x08)
	struct UParticleSystemComponent* AnimTrial; // 0xd58(0x08)
	struct UParticleSystemComponent* MeleeHeavy_PSC; // 0xd60(0x08)
	struct UParticleSystem* IdleFX Template; // 0xd68(0x08)
	bool Has_Idle_Effect; // 0xd70(0x01)
	char UnknownData_D71[0x7]; // 0xd71(0x07)
	struct UParticleSystem* Idle_Effect; // 0xd78(0x08)
	struct UParticleSystemComponent* Idle Effect Component; // 0xd80(0x08)
	struct FName IdleFXAttachSocket; // 0xd88(0x08)
	enum class EAttachmentRule IdleFX Location Rule; // 0xd90(0x01)
	enum class EAttachmentRule Idle FX Rotation Rule; // 0xd91(0x01)
	enum class EAttachmentRule Idle FX Scale Rule; // 0xd92(0x01)
	char UnknownData_D93[0x5]; // 0xd93(0x05)
	struct UParticleSystem* Swing FX Template; // 0xd98(0x08)
	bool Has_Swing_Effect; // 0xda0(0x01)
	char UnknownData_DA1[0x7]; // 0xda1(0x07)
	struct UParticleSystem* Swing_Effect; // 0xda8(0x08)
	struct UParticleSystemComponent* Swing Effect Component; // 0xdb0(0x08)
	struct FName SwingFXSocket; // 0xdb8(0x08)
	enum class EAttachmentRule SwingFX Location Rule; // 0xdc0(0x01)
	enum class EAttachmentRule Swing FX Rotation Rule; // 0xdc1(0x01)
	enum class EAttachmentRule Swing FX Scale Rule; // 0xdc2(0x01)
	bool UseAnimTrails; // 0xdc3(0x01)
	char UnknownData_DC4[0x4]; // 0xdc4(0x04)
	struct UParticleSystem* Anim Trail Template; // 0xdc8(0x08)
	struct FName OverrideFirstSocketName; // 0xdd0(0x08)
	struct FName OverrideSecond Socket Name; // 0xdd8(0x08)
	struct UParticleSystem* AnimTrailsParticles; // 0xde0(0x08)
	struct UParticleSystemComponent* AnimTrail_PSC; // 0xde8(0x08)
	struct FName FirstSocketName; // 0xdf0(0x08)
	struct FName Second Socket Name; // 0xdf8(0x08)
	float Width; // 0xe00(0x04)
	char UnknownData_E04[0x4]; // 0xe04(0x04)
	struct UParticleSystem* MeleeHeavy_ParticleSystem; // 0xe08(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffect; // 0xe10(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffectIcon; // 0xe18(0x08)
	bool UseDestroyEffect; // 0xe20(0x01)
	char UnknownData_E21[0x7]; // 0xe21(0x07)
	struct TArray<struct UAnimMontage*> PokeAnimations; // 0xe28(0x10)
	struct UParticleSystemComponent* Alteration Ambient PS; // 0xe38(0x08)
	struct USoundBase* MeleeHeavy_Sound; // 0xe40(0x08)
	struct FGameplayTag Melee Heavy Launch Gameplay Cue Tag Override; // 0xe48(0x08)
	struct FGameplayTag Melee Heavy Impact Gameplay Cue Tag Override; // 0xe50(0x08)
	struct FVector Effects_Color_Level; // 0xe58(0x0c)
	char UnknownData_E64[0x4]; // 0xe64(0x04)
	struct USoundAttenuation* MeleeHeavySoundAttenuationSettings; // 0xe68(0x08)
	struct USoundConcurrency* MeleeHeavySoundConcurrencySettings; // 0xe70(0x08)

	void Melee_Effect_Color(struct FVector Melee_Color_Set); // Function B_Melee_Generic.B_Melee_Generic_C.Melee_Effect_Color // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayCQCPickaxeEnemyAudio(struct FHitResult Hit Result); // Function B_Melee_Generic.B_Melee_Generic_C.PlayCQCPickaxeEnemyAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetActiveAlterationIdleParticles(bool Active, bool Reset); // Function B_Melee_Generic.B_Melee_Generic_C.SetActiveAlterationIdleParticles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetWpnRarity(); // Function B_Melee_Generic.B_Melee_Generic_C.SetWpnRarity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function B_Melee_Generic.B_Melee_Generic_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_CB594210420542B302428F8181D85E48(struct UObject* Loaded); // Function B_Melee_Generic.B_Melee_Generic_C.OnLoaded_CB594210420542B302428F8181D85E48 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void MeleeSwingRight(bool First Right); // Function B_Melee_Generic.B_Melee_Generic_C.MeleeSwingRight // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void MeleeSwingLeft(bool First Left); // Function B_Melee_Generic.B_Melee_Generic_C.MeleeSwingLeft // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FootStepLeft(); // Function B_Melee_Generic.B_Melee_Generic_C.FootStepLeft // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FootStepRight(); // Function B_Melee_Generic.B_Melee_Generic_C.FootStepRight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void MeleeSwingRight_End(); // Function B_Melee_Generic.B_Melee_Generic_C.MeleeSwingRight_End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void MeleeSwingLeft_End(); // Function B_Melee_Generic.B_Melee_Generic_C.MeleeSwingLeft_End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Melee_Generic.B_Melee_Generic_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Melee_Generic.B_Melee_Generic_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void PlayRClickImpacts(); // Function B_Melee_Generic.B_Melee_Generic_C.PlayRClickImpacts // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPlayImpactFX(struct FHitResult HitResult, enum class EPhysicalSurface ImpactPhysicalSurface, struct UFXSystemComponent* SpawnedPSC); // Function B_Melee_Generic.B_Melee_Generic_C.OnPlayImpactFX // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnEquippedWeaponDestory(); // Function B_Melee_Generic.B_Melee_Generic_C.OnEquippedWeaponDestory // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_Melee_Generic.B_Melee_Generic_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnInitCosmeticAlterations(struct FFortCosmeticModification CosmeticMod); // Function B_Melee_Generic.B_Melee_Generic_C.OnInitCosmeticAlterations // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponVisibilityChanged(bool bVisible, bool bSetForLocalControllerOnly); // Function B_Melee_Generic.B_Melee_Generic_C.OnWeaponVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponDetached(); // Function B_Melee_Generic.B_Melee_Generic_C.OnWeaponDetached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Melee_Generic(int32_t EntryPoint); // Function B_Melee_Generic.B_Melee_Generic_C.ExecuteUbergraph_B_Melee_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

