// WidgetBlueprintGeneratedClass DisableSidekickListEntry.DisableSidekickListEntry_C
// Size: 0xcc0 (Inherited: 0xc18)
struct UDisableSidekickListEntry_C : UFortDisableSidekickListEntry {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc18(0x08)
	struct UWidgetAnimation* Selected; // 0xc20(0x08)
	struct UWidgetAnimation* Hovered; // 0xc28(0x08)
	struct UBorder* AnimatedInputBorder; // 0xc30(0x08)
	struct UImage* Arrow; // 0xc38(0x08)
	struct UIconTextButton_C* EmptyButtonToEatOneMouseUpEvent; // 0xc40(0x08)
	struct UBorder* EntryBorder; // 0xc48(0x08)
	struct UCommonRichTextBlock* Text_LeavePartyText; // 0xc50(0x08)
	struct UUserActionMenuInputButton_C* UserActionMenuInputButton; // 0xc58(0x08)
	struct UMaterialInstance* InviteMaterial; // 0xc60(0x08)
	struct UMaterialInstance* DefaultMaterial; // 0xc68(0x08)
	struct FSlateColor InviteFontColor; // 0xc70(0x28)
	struct FSlateColor DefaultFontColor; // 0xc98(0x28)

	void BP_OnUnhovered(); // Function DisableSidekickListEntry.DisableSidekickListEntry_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(bool bIsOpen); // Function DisableSidekickListEntry.DisableSidekickListEntry_C.BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function DisableSidekickListEntry.DisableSidekickListEntry_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_DisableSidekickListEntry(int32_t EntryPoint); // Function DisableSidekickListEntry.DisableSidekickListEntry_C.ExecuteUbergraph_DisableSidekickListEntry // (Final|UbergraphFunction) // @ game+0xbd830c
};

