// BlueprintGeneratedClass Athena_Player_SneakySnowmanV3.Athena_Player_SneakySnowmanV3_C
// Size: 0xa98 (Inherited: 0xa2d)
struct AAthena_Player_SneakySnowmanV3_C : AAthena_Player_SneakySnowmanV2_C {
	char UnknownData_A2D[0x3]; // 0xa2d(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa30(0x08)
	bool Dead; // 0xa38(0x01)
	char UnknownData_A39[0x7]; // 0xa39(0x07)
	struct FScalableFloat LaunchSpeed; // 0xa40(0x28)
	struct AActor* DamageCauser; // 0xa68(0x08)
	struct FScalableFloat FrostExplosionRadius; // 0xa70(0x28)

	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Athena_Player_SneakySnowmanV3.Athena_Player_SneakySnowmanV3_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Athena_Player_SneakySnowmanV3.Athena_Player_SneakySnowmanV3_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnInteractWithFake(struct AFortPawn* InteractingPawn); // Function Athena_Player_SneakySnowmanV3.Athena_Player_SneakySnowmanV3_C.OnInteractWithFake // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Player_SneakySnowmanV3(int32_t EntryPoint); // Function Athena_Player_SneakySnowmanV3.Athena_Player_SneakySnowmanV3_C.ExecuteUbergraph_Athena_Player_SneakySnowmanV3 // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

