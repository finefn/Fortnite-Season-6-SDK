// BlueprintGeneratedClass B_HeldObject_Snowball.B_HeldObject_Snowball_C
// Size: 0xac4 (Inherited: 0x9b0)
struct AB_HeldObject_Snowball_C : ABGA_HeldObject_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9b0(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x9b8(0x08)
	float DropAnimation_Z_Pos_888F8AB94C79F6A9DEB3149DDCAC3D72; // 0x9c0(0x04)
	enum class ETimelineDirection DropAnimation__Direction_888F8AB94C79F6A9DEB3149DDCAC3D72; // 0x9c4(0x01)
	char UnknownData_9C5[0x3]; // 0x9c5(0x03)
	struct UTimelineComponent* DropAnimation; // 0x9c8(0x08)
	struct FTimerHandle SnowCheckTimer; // 0x9d0(0x08)
	float SnowballScale; // 0x9d8(0x04)
	struct FRotator RotationRate; // 0x9dc(0x0c)
	float StartZPos; // 0x9e8(0x04)
	bool WasThrown; // 0x9ec(0x01)
	char UnknownData_9ED[0x3]; // 0x9ed(0x03)
	float WaterScaleMultiplier; // 0x9f0(0x04)
	char UnknownData_9F4[0x4]; // 0x9f4(0x04)
	struct AFortPlayerPawn* LastHolder; // 0x9f8(0x08)
	bool Held; // 0xa00(0x01)
	char UnknownData_A01[0x7]; // 0xa01(0x07)
	struct FScalableFloat PlayerDamageMultiplier; // 0xa08(0x28)
	struct FScalableFloat EnvDamageMultiplier; // 0xa30(0x28)
	struct FScalableFloat GrowingSpeed; // 0xa58(0x28)
	struct FScalableFloat MaxScale; // 0xa80(0x28)
	struct FVector LastPosition; // 0xaa8(0x0c)
	bool Died; // 0xab4(0x01)
	bool WasJustThrown; // 0xab5(0x01)
	bool DoneDropping; // 0xab6(0x01)
	char UnknownData_AB7[0x1]; // 0xab7(0x01)
	struct FVector ImpactNormal; // 0xab8(0x0c)

	void Server Only Handle Player Controller OnUnPossess(struct APawn* PlayerPawn); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.Server Only Handle Player Controller OnUnPossess // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Server Only Handle Attach To Vehicle(struct FVector HitLoc, struct UPrimitiveComponent* HitComponentToAttachTo); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.Server Only Handle Attach To Vehicle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FilterByLOS(struct TArray<struct AActor*> Array, struct TArray<struct AActor*> _Result); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.FilterByLOS // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void DropAnimation__FinishedFunc(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.DropAnimation__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void DropAnimation__UpdateFunc(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.DropAnimation__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnHit(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.OnHit // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void EventSnowballDeath(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.EventSnowballDeath // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void EnterWater(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.EnterWater // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetInstigator(struct AFortPlayerPawn* Instigator); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.SetInstigator // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_2_OnHeldObjectDropped__DelegateSignature(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_2_OnHeldObjectDropped__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_3_OnHeldObjectPlaced__DelegateSignature(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_3_OnHeldObjectPlaced__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_4_OnHeldObjectPickedUp__DelegateSignature(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_4_OnHeldObjectPickedUp__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BlowUp(struct AFortPlayerPawn* LastHolder); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BlowUp // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StopDropping(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.StopDropping // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_1_OnHeldObjectThrown__DelegateSignature(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_1_OnHeldObjectThrown__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Play Drop Animation(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.Play Drop Animation // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_5_OnLinkedActorDisconnected__DelegateSignature(); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_5_OnLinkedActorDisconnected__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_HeldObject_Snowball(int32_t EntryPoint); // Function B_HeldObject_Snowball.B_HeldObject_Snowball_C.ExecuteUbergraph_B_HeldObject_Snowball // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

