// SolarisGeneratedClass Assets_Material_V.Material_V
// Size: 0x80 (Inherited: 0x80)
struct UMaterial_V : UAsset {

	struct UMaterial_V* createAndLoad(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_Material_V.Material_V.createAndLoad // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	struct UMaterial_V* Create(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_Material_V.Material_V.Create // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	void $InitInstance(); // Function Assets_Material_V.Material_V.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Assets_Material_V.Material_V.$InitCDO // () // @ game+0xbd830c
};

