// WidgetBlueprintGeneratedClass AthenaPlayerLevelCompact.AthenaPlayerLevelCompact_C
// Size: 0x2f0 (Inherited: 0x2d0)
struct UAthenaPlayerLevelCompact_C : UAthenaPlayerLevelDisplay {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct UImage* Image_ProgressBar; // 0x2d8(0x08)
	struct FMulticastInlineDelegate LevelChanged; // 0x2e0(0x10)

	void OnUpdateRewardIcon(struct UFortItem* RewardItem, struct TSoftObjectPtr<struct UTexture2D> RewardTexture, bool bHasAdditionalStylesToDisplay, int32_t RewardLevel, bool bRequiresBattlePass); // Function AthenaPlayerLevelCompact.AthenaPlayerLevelCompact_C.OnUpdateRewardIcon // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnUpdateXpBar(float Progress, bool bIsMaxLevel); // Function AthenaPlayerLevelCompact.AthenaPlayerLevelCompact_C.OnUpdateXpBar // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaPlayerLevelCompact(int32_t EntryPoint); // Function AthenaPlayerLevelCompact.AthenaPlayerLevelCompact_C.ExecuteUbergraph_AthenaPlayerLevelCompact // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void LevelChanged__DelegateSignature(int32_t Level); // Function AthenaPlayerLevelCompact.AthenaPlayerLevelCompact_C.LevelChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

