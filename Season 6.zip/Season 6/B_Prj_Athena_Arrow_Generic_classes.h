// BlueprintGeneratedClass B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C
// Size: 0xc38 (Inherited: 0xa82)
struct AB_Prj_Athena_Arrow_Generic_C : AB_Prj_Arrow_Athena_Parent_C {
	char UnknownData_A82[0x6]; // 0xa82(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa88(0x08)
	bool bSpawnAdditionalActorsOnImpact; // 0xa90(0x01)
	char UnknownData_A91[0x7]; // 0xa91(0x07)
	struct TArray<struct FFArrowAdditionalSpawnProperties> AdditionalSpawns; // 0xa98(0x10)
	struct FVector HitLocation; // 0xaa8(0x0c)
	struct FHitResult CachedHitResult; // 0xab4(0x88)
	char UnknownData_B3C[0x4]; // 0xb3c(0x04)
	struct FScalableFloat Row_ChargeThreshold; // 0xb40(0x28)
	bool bUseDifferentCueOnSecondaryEffect; // 0xb68(0x01)
	char UnknownData_B69[0x3]; // 0xb69(0x03)
	struct FGameplayTag SecondaryEffectCueTag; // 0xb6c(0x08)
	char UnknownData_B74[0x4]; // 0xb74(0x04)
	struct FFChargeDependentAudioSet InAirSounds; // 0xb78(0x10)
	struct UBulletWhipTrackerComponent_C* FullyChargedBulletWhip; // 0xb88(0x08)
	bool bSpawnPersistentArrowOnFullyChargedHit; // 0xb90(0x01)
	char UnknownData_B91[0x7]; // 0xb91(0x07)
	struct UBulletWhipTrackerComponent_C* NormalBulletWhip; // 0xb98(0x08)
	float InAirSoundFadeInTime; // 0xba0(0x04)
	float InAirSoundFadeInTime_FullyCharged; // 0xba4(0x04)
	float InAirSoundFadeOutTime; // 0xba8(0x04)
	char UnknownData_BAC[0x4]; // 0xbac(0x04)
	struct USoundBase* ImpactSoundDefault; // 0xbb0(0x08)
	struct TMap<enum class EPhysicalSurface, int32_t> ImpactSoundSurfaceMap; // 0xbb8(0x50)
	struct UAudioComponent* InAirAudioComp; // 0xc08(0x08)
	struct UParticleSystem* P_PersistentArrow; // 0xc10(0x08)
	struct USoundBase* ImpactSoundLayer; // 0xc18(0x08)
	struct UNiagaraSystem* NS_FullyChargedTrail; // 0xc20(0x08)
	struct UNiagaraSystem* NS_FullyChargedImpactFX; // 0xc28(0x08)
	struct UNiagaraSystem* NS PersistentArrow; // 0xc30(0x08)

	void GetWaterImpactLocationForFX(struct FVector WaterSurfaceLocation, struct FVector ImpactLocation); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.GetWaterImpactLocationForFX // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void ChoosePawnAttachBoneAndLocation(struct FName HitBone, struct FVector Location, struct APlayerPawn_Athena_C* Pawn, struct FName ChosenBone, struct FVector ChosenLocation); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.ChoosePawnAttachBoneAndLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetSoundsFromCharge(); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.SetSoundsFromCharge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetVFXFromCharge(); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.SetVFXFromCharge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetPersistentArrowRotation(struct FRotator Rotation); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.GetPersistentArrowRotation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void AttachArrowToPawn(struct APlayerPawn_Athena_C* Pawn, struct FHitResult HitResult); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.AttachArrowToPawn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AttachPersistentArrow(struct UPrimitiveComponent* Component, struct FVector Location, struct FRotator Rotation, struct FName AttachPointName); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.AttachPersistentArrow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayImpactSound(struct FVector Location, struct UPhysicalMaterial* PhysMat); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.PlayImpactSound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetProperHit(struct FHitResult OriginalHit, struct FHitResult ProperHit); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.GetProperHit // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PickSoundBasedOnCharge(struct FFChargeDependentAudioSet AudioSet, struct USoundBase* SelectedSound); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.PickSoundBasedOnCharge // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void CheckCharge(bool RequirementMet); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.CheckCharge // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void SpawnAdditionalGenericActor(struct AActor* ActorClass, struct FVector Location); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.SpawnAdditionalGenericActor // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Determine Projectile Direction(struct FVector Origin, struct FVector BaseDirection, float MinAngle, float MaxAngle, struct FRotator Direction); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.Determine Projectile Direction // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnAdditionalProjectile(struct FHitResult HitResult, struct AFortProjectileBase* ProjectileClass, struct FFProjectileSpawnProperties ProjectileSpawnProperties); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.SpawnAdditionalProjectile // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnAdditionalBGA(struct ABuildingGameplayActor* BGAClass, struct FVector Location); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.SpawnAdditionalBGA // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnTouched(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FHitResult HitResult, bool bIsOverlap); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.OnTouched // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void QueueAdditionalSpawns(); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.QueueAdditionalSpawns // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleSpawn(struct FFArrowAdditionalSpawnProperties SpawnProperties, bool bOverrideNumToSpawn, int32_t NumToSpawnOverride); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.HandleSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnFullyChargedImpact(struct FHitResult Hit Result); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.OnFullyChargedImpact // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ClientPlaySecondaryEffectImpactCue(struct FVector Location, struct FVector Normal); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.ClientPlaySecondaryEffectImpactCue // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void PlayFullyChargedImpactFX(struct FHitResult Hit Result); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.PlayFullyChargedImpactFX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnPersistentArrow(struct FHitResult Hit Result); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.SpawnPersistentArrow // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ClientPlayImpactSound(struct FHitResult Hit); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.ClientPlayImpactSound // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_Arrow_Generic(int32_t EntryPoint); // Function B_Prj_Athena_Arrow_Generic.B_Prj_Athena_Arrow_Generic_C.ExecuteUbergraph_B_Prj_Athena_Arrow_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

