// AnimBlueprintGeneratedClass CowboyPistol_AnimBP.CowboyPistol_AnimBP_C
// Size: 0xac2 (Inherited: 0x2c0)
struct UCowboyPistol_AnimBP_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x2f8(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7; // 0x340(0x80)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive; // 0x3c0(0xc8)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // 0x488(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // 0x4b0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // 0x4d8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x500(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x528(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x550(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x578(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0x5a0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // 0x620(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0x650(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // 0x6d0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x700(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // 0x780(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x7b0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x830(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x860(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x8e0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x910(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x990(0x30)
	struct FAnimNode_RefPose AnimGraphNode_IdentityPose; // 0x9c0(0x18)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x9d8(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0xa08(0xb0)
	int32_t ChamberRotationCounter; // 0xab8(0x04)
	bool ChamberPosition_2; // 0xabc(0x01)
	bool ChamberPosition_7; // 0xabd(0x01)
	bool ChamberPosition_3; // 0xabe(0x01)
	bool ChamberPosition_4; // 0xabf(0x01)
	bool ChamberPosition_5; // 0xac0(0x01)
	bool ChamberPosition_6; // 0xac1(0x01)

	void AnimGraph(struct FPoseLink AnimGraph); // Function CowboyPistol_AnimBP.CowboyPistol_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AnimNotify_ChamberRotation(); // Function CowboyPistol_AnimBP.CowboyPistol_AnimBP_C.AnimNotify_ChamberRotation // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CowboyPistol_AnimBP(int32_t EntryPoint); // Function CowboyPistol_AnimBP.CowboyPistol_AnimBP_C.ExecuteUbergraph_CowboyPistol_AnimBP // (Final|UbergraphFunction) // @ game+0xbd830c
};

