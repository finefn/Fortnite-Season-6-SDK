// BlueprintGeneratedClass BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C
// Size: 0x4f8 (Inherited: 0x4c8)
struct ABP13_StyleChallenge_Mannequin_C : AFortPlayerMannequin {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c8(0x08)
	struct UCustomCharacterPart* NewPart; // 0x4d0(0x08)
	struct UNiagaraComponent* ProfPupVFXs; // 0x4d8(0x08)
	struct UParticleSystemComponent* RacerZeroBody1VFX; // 0x4e0(0x08)
	struct UParticleSystemComponent* Racer Zero Body2VFX; // 0x4e8(0x08)
	struct UParticleSystemComponent* Racer Zero Head VFX; // 0x4f0(0x08)

	void RacerZeroSetup(); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.RacerZeroSetup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ProfPupSetup(); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.ProfPupSetup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnVariantChanged(struct FGameplayTag VariantChannel, struct FGameplayTag OldVariantTag, struct FGameplayTag NewVariantTag); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.OnVariantChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnPartChanged(struct UCustomCharacterPart* OldPart, struct UCustomCharacterPart* NewPart, enum class EFortCustomPartType PartType); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.OnPartChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP13_StyleChallenge_Mannequin(int32_t EntryPoint); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.ExecuteUbergraph_BP13_StyleChallenge_Mannequin // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

