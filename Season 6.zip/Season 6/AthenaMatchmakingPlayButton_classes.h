// WidgetBlueprintGeneratedClass AthenaMatchmakingPlayButton.AthenaMatchmakingPlayButton_C
// Size: 0xc50 (Inherited: 0xc10)
struct UAthenaMatchmakingPlayButton_C : UAthenaMatchmakingPlayButtonBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc10(0x08)
	struct UWidgetAnimation* Disabled; // 0xc18(0x08)
	struct UWidgetAnimation* PlayShine; // 0xc20(0x08)
	struct UWidgetAnimation* OnHovered; // 0xc28(0x08)
	struct UCommonTextBlock* CenterButtonTextWidget; // 0xc30(0x08)
	struct UImage* Image_ButtonTop; // 0xc38(0x08)
	struct UImage* Image_Shadow; // 0xc40(0x08)
	struct UMatchmakingInputIndicator_C* MatchmakingInputIndicator; // 0xc48(0x08)

	void SetButtonText(struct FText InText); // Function AthenaMatchmakingPlayButton.AthenaMatchmakingPlayButton_C.SetButtonText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function AthenaMatchmakingPlayButton.AthenaMatchmakingPlayButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function AthenaMatchmakingPlayButton.AthenaMatchmakingPlayButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaMatchmakingPlayButton(int32_t EntryPoint); // Function AthenaMatchmakingPlayButton.AthenaMatchmakingPlayButton_C.ExecuteUbergraph_AthenaMatchmakingPlayButton // (Final|UbergraphFunction) // @ game+0xbd830c
};

