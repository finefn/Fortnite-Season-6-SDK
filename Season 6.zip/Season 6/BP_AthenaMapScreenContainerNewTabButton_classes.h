// WidgetBlueprintGeneratedClass BP_AthenaMapScreenContainerNewTabButton.BP_AthenaMapScreenContainerNewTabButton_C
// Size: 0xc28 (Inherited: 0xc08)
struct UBP_AthenaMapScreenContainerNewTabButton_C : UAthenaMapScreenContainerTabButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc08(0x08)
	struct UWidgetAnimation* Unhovered; // 0xc10(0x08)
	struct UWidgetAnimation* Hovered; // 0xc18(0x08)
	struct UWidgetAnimation* Selected; // 0xc20(0x08)

	void BP_OnHovered(); // Function BP_AthenaMapScreenContainerNewTabButton.BP_AthenaMapScreenContainerNewTabButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function BP_AthenaMapScreenContainerNewTabButton.BP_AthenaMapScreenContainerNewTabButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnSelected(); // Function BP_AthenaMapScreenContainerNewTabButton.BP_AthenaMapScreenContainerNewTabButton_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnDeselected(); // Function BP_AthenaMapScreenContainerNewTabButton.BP_AthenaMapScreenContainerNewTabButton_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_AthenaMapScreenContainerNewTabButton(int32_t EntryPoint); // Function BP_AthenaMapScreenContainerNewTabButton.BP_AthenaMapScreenContainerNewTabButton_C.ExecuteUbergraph_BP_AthenaMapScreenContainerNewTabButton // (Final|UbergraphFunction) // @ game+0xbd830c
};

