// BlueprintGeneratedClass B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C
// Size: 0xd6a (Inherited: 0xd49)
struct AB_FloppingRabbit_Weap_Athena_C : AB_UtilityItem_Generic_Athena_C {
	char UnknownData_D49[0x7]; // 0xd49(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd50(0x08)
	struct AActor* Projectile; // 0xd58(0x08)
	struct AActor* Wire; // 0xd60(0x08)
	bool HideBobber; // 0xd68(0x01)
	bool OneHandGrip; // 0xd69(0x01)

	struct FName DetermineFishLootTierNameAndSetLootForSpawner(bool bIsExplosion); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.DetermineFishLootTierNameAndSetLootForSpawner // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_OneHandGrip(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.OnRep_OneHandGrip // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_HideBobber(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.OnRep_HideBobber // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void K2_OnUnEquip(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ForceKillFishing(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.ForceKillFishing // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnTetherDetached(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.OnTetherDetached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BindHolsterEvents(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.BindHolsterEvents // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UnbindHolsterEvents(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.UnbindHolsterEvents // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnHolstered(); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.OnHolstered // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_FloppingRabbit_Weap_Athena(int32_t EntryPoint); // Function B_FloppingRabbit_Weap_Athena.B_FloppingRabbit_Weap_Athena_C.ExecuteUbergraph_B_FloppingRabbit_Weap_Athena // (Final|UbergraphFunction) // @ game+0xbd830c
};

