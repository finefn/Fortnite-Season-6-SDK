// BlueprintGeneratedClass Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C
// Size: 0xc32 (Inherited: 0xbc0)
struct ACreative_Device_Prop_Parent_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc0(0x08)
	struct UCreative_VisibleInGame_Component_C* VisibleInGameComponent; // 0xbc8(0x08)
	struct UCreative_Enabled_Component_C* EnabledComponent; // 0xbd0(0x08)
	struct UFortMinigameProgressComponent* FortMinigameProgress; // 0xbd8(0x08)
	struct UToyOptionsComponent_C* ToyOptionsComponent; // 0xbe0(0x08)
	int32_t ActivateOnGamePhase; // 0xbe8(0x04)
	int32_t EnabledIndex; // 0xbec(0x04)
	struct FMulticastInlineDelegate On Device Activated; // 0xbf0(0x10)
	struct AController* Instigating Controller; // 0xc00(0x08)
	bool bIsVisible; // 0xc08(0x01)
	char UnknownData_C09[0x7]; // 0xc09(0x07)
	struct FMulticastInlineDelegate On Device Initialized; // 0xc10(0x10)
	struct FMulticastInlineDelegate On Play Mode Changed; // 0xc20(0x10)
	bool Update on Minigame State Change; // 0xc30(0x01)
	bool Update on Play Mode Changed; // 0xc31(0x01)

	void GetVisibilityComponentsWithCollisionOverrides(struct TMap<struct USceneComponent*, enum class ECollisionEnabled> VisibilityComponents); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.GetVisibilityComponentsWithCollisionOverrides // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetVisibilityComponents(struct TArray<struct USceneComponent*> VisibilityComponents); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.GetVisibilityComponents // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update Visibility In Game(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.Update Visibility In Game // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Is Visible In Game(bool Visible); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.Is Visible In Game // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void IsInPlayMode(bool bIsInPlayMode); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.IsInPlayMode // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	float BlueprintModifyIncomingDamage(float Damage, struct FGameplayTagContainer InTags, struct FGameplayEffectContextHandle EffectContext, struct AController* EventInstigator, struct AActor* DamageCauser); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BlueprintModifyIncomingDamage // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Activate Device Failed(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.Activate Device Failed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Attempt Activate Device(struct AController* Instigating Controller, bool Additional Requirements); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.Attempt Activate Device // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Initialize Device(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.Initialize Device // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintOnLocalInteract(struct AFortPlayerPawn* InteractingPawn); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BlueprintOnLocalInteract // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void Activate Device(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.Activate Device // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Activate on Phase(enum class EFortMinigameState State); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.Activate on Phase // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayModeChanged(struct AFortMinigame* Minigame, bool bIsInPlayMode); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.PlayModeChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_2_AnyPropertyChangedDelegate__DelegateSignature(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_2_AnyPropertyChangedDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_3_AnyPropertyChangedDelegate__DelegateSignature(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_3_AnyPropertyChangedDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortMinigameProgress_K2Node_ComponentBoundEvent_1_OnMinigameAssignmentChanged__DelegateSignature(struct AFortMinigame* Minigame); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BndEvt__FortMinigameProgress_K2Node_ComponentBoundEvent_1_OnMinigameAssignmentChanged__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortMinigameProgress_K2Node_ComponentBoundEvent_4_OnMinigameAssignmentChanged__DelegateSignature(struct AFortMinigame* Minigame); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BndEvt__FortMinigameProgress_K2Node_ComponentBoundEvent_4_OnMinigameAssignmentChanged__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void On Mingame State Changed(struct AFortMinigame* Minigame, enum class EFortMinigameState MinigameState); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.On Mingame State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnWorldReady(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.OnWorldReady // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortMinigameProgress_K2Node_ComponentBoundEvent_0_SimpleDynamicMulticastDelegate__DelegateSignature(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BndEvt__FortMinigameProgress_K2Node_ComponentBoundEvent_0_SimpleDynamicMulticastDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortMinigameProgress_K2Node_ComponentBoundEvent_5_SimpleDynamicMulticastDelegate__DelegateSignature(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.BndEvt__FortMinigameProgress_K2Node_ComponentBoundEvent_5_SimpleDynamicMulticastDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnMinigameStarted(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.OnMinigameStarted // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnMinigameEnded(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.OnMinigameEnded // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Creative_Device_Prop_Parent(int32_t EntryPoint); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.ExecuteUbergraph_Creative_Device_Prop_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void On Play Mode Changed__DelegateSignature(bool New Play Mode); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.On Play Mode Changed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void On Device Initialized__DelegateSignature(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.On Device Initialized__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void On Device Activated__DelegateSignature(); // Function Creative_Device_Prop_Parent.Creative_Device_Prop_Parent_C.On Device Activated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

