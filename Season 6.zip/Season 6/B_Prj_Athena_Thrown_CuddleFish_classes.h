// BlueprintGeneratedClass B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C
// Size: 0xb00 (Inherited: 0x930)
struct AB_Prj_Athena_Thrown_CuddleFish_C : AFortAttachableProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x930(0x08)
	struct UNiagaraComponent* AttachedVFX; // 0x938(0x08)
	struct UBP_SurfaceTypeSoundComponent_C* BP_SurfaceTypeSoundComponent; // 0x940(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x948(0x08)
	enum class None Team; // 0x950(0x01)
	bool TeamHasBeenSet; // 0x951(0x01)
	bool SpawnOnCollision; // 0x952(0x01)
	bool DontSpawnOnVehicles; // 0x953(0x01)
	char UnknownData_954[0x4]; // 0x954(0x04)
	struct AActor* BGAToSpawn; // 0x958(0x08)
	struct FVector SpawnScale; // 0x960(0x0c)
	char UnknownData_96C[0x4]; // 0x96c(0x04)
	struct USoundBase* SplashSound; // 0x970(0x08)
	float MinDotWithUp; // 0x978(0x04)
	float SpawnPosOffsetAlongNormal; // 0x97c(0x04)
	float SpawnPosZOffsetInWater; // 0x980(0x04)
	bool Spawned; // 0x984(0x01)
	char UnknownData_985[0x3]; // 0x985(0x03)
	struct AActor* SpawnedBGA; // 0x988(0x08)
	float SelfStickDelay; // 0x990(0x04)
	bool IsSelfStickDelayOver?; // 0x994(0x01)
	char UnknownData_995[0x3]; // 0x995(0x03)
	struct FGameplayTagContainer TC_ActorTagsThatShouldExplodeOnOverlap; // 0x998(0x20)
	struct TSet<struct AActor*> Ignore; // 0x9b8(0x50)
	bool StickToAllies; // 0xa08(0x01)
	char UnknownData_A09[0x7]; // 0xa09(0x07)
	struct AFortPawn* StuckToPawn; // 0xa10(0x08)
	float OffsetDistanceFromPhysicsMesh; // 0xa18(0x04)
	float OffsetDistanceFromBone; // 0xa1c(0x04)
	struct FScalableFloat ExplosionPlayRate; // 0xa20(0x28)
	bool bSimulationRunning; // 0xa48(0x01)
	bool HasStopped; // 0xa49(0x01)
	char UnknownData_A4A[0x2]; // 0xa4a(0x02)
	struct FVector HitNormal; // 0xa4c(0x0c)
	struct FVector HitLocation; // 0xa58(0x0c)
	enum class EPhysicalSurface SurfaceType; // 0xa64(0x01)
	char UnknownData_A65[0x3]; // 0xa65(0x03)
	struct USoundBase* AudioStuckToEnvironment; // 0xa68(0x08)
	struct USoundBase* AudioStuckToPlayer; // 0xa70(0x08)
	struct FScalableFloat ExplosionRadius; // 0xa78(0x28)
	struct UFortAbilitySystemComponent* DamageDealingAbilitySystemComponent; // 0xaa0(0x08)
	struct UGameplayEffect* ExplosionGE; // 0xaa8(0x08)
	struct USoundBase* ExplodeSFX; // 0xab0(0x08)
	struct FGameplayTag CameraShakeGC; // 0xab8(0x08)
	struct UParticleSystem* FX_HitWater; // 0xac0(0x08)
	struct UNiagaraSystem* ExplosionVFX; // 0xac8(0x08)
	struct UAnimMontage* ExplosionMontage; // 0xad0(0x08)
	struct FName AttachedToPawn; // 0xad8(0x08)
	struct UAnimMontage* LandingMontage; // 0xae0(0x08)
	struct FName Jumped; // 0xae8(0x08)
	struct FName Thrown; // 0xaf0(0x08)
	struct FName Falling; // 0xaf8(0x08)

	void MakeEffectContext(struct FGameplayEffectContextHandle Context); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.MakeEffectContext // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void FilterByLOS(struct TArray<struct AActor*> Array, struct TArray<struct AActor*> _Result); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.FilterByLOS // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayStickSound(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.PlayStickSound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_bSimulationRunning(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnRep_bSimulationRunning // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleHitSupplyDrop(struct AActor* Actor, struct UPrimitiveComponent* Component); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.HandleHitSupplyDrop // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleHitVehicle(struct AActor* Actor, struct UPrimitiveComponent* Component); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.HandleHitVehicle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleHitBuildingWall(struct AActor* Actor, struct UPrimitiveComponent* Component); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.HandleHitBuildingWall // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleHits(struct AActor* Actor, struct UPrimitiveComponent* Component); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.HandleHits // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckForWater(struct FVector Location, struct UObject* HitActor, struct FVector LocationAboveWater); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.CheckForWater // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void GetClosestPoint(struct UPrimitiveComponent* Component, struct FVector StartingPoint, struct FVector Point); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.GetClosestPoint // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	struct AActor* SpawnBGA(struct FVector Normal, struct AActor* HitActor, struct UPrimitiveComponent* HitComponent, struct FVector Location, bool FromWater, struct FVector TraceDifference); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.SpawnBGA // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnNotifyEnd_40971E314A05680BCF2E6AA4AF19B954(struct FName NotifyName); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnNotifyEnd_40971E314A05680BCF2E6AA4AF19B954 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnNotifyBegin_40971E314A05680BCF2E6AA4AF19B954(struct FName NotifyName); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnNotifyBegin_40971E314A05680BCF2E6AA4AF19B954 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInterrupted_40971E314A05680BCF2E6AA4AF19B954(struct FName NotifyName); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnInterrupted_40971E314A05680BCF2E6AA4AF19B954 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnBlendOut_40971E314A05680BCF2E6AA4AF19B954(struct FName NotifyName); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnBlendOut_40971E314A05680BCF2E6AA4AF19B954 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnCompleted_40971E314A05680BCF2E6AA4AF19B954(struct FName NotifyName); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnCompleted_40971E314A05680BCF2E6AA4AF19B954 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SetTeam(enum class None Team); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.SetTeam // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void HeldWaterInteraction(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.HeldWaterInteraction // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Event_TriggerExplosion(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.Event_TriggerExplosion // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AttachToActor(struct FHitResult Hit); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.AttachToActor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReopenPawnCollision(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.ReopenPawnCollision // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BindToPlayerOrAIDeath(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.BindToPlayerOrAIDeath // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CallExplodeTrigger(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.CallExplodeTrigger // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayerDiedEvent(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.PlayerDiedEvent // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void RestartSimulating(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.RestartSimulating // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ClosePawnCollision(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.ClosePawnCollision // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ProjectileMovementComponent_K2Node_ComponentBoundEvent_2_OnProjectileStopDelegate__DelegateSignature(struct FHitResult ImpactResult); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.BndEvt__ProjectileMovementComponent_K2Node_ComponentBoundEvent_2_OnProjectileStopDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Event_BuildingActorDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.Event_BuildingActorDied // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Event_Building_Actor_Destroyed(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.Event_Building_Actor_Destroyed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnAttachedToDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnAttachedToDied // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Event_OnVehicleDestroyed(struct AActor* DestroyedActor); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.Event_OnVehicleDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStop(struct FHitResult Hit); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void AttachToActorVFX(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.AttachToActorVFX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayExplosionEffects(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.PlayExplosionEffects // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetHasSpawnedFromJump(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.SetHasSpawnedFromJump // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckVelocity(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.CheckVelocity // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Land Sound Replicate(); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.Land Sound Replicate // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_Thrown_CuddleFish(int32_t EntryPoint); // Function B_Prj_Athena_Thrown_CuddleFish.B_Prj_Athena_Thrown_CuddleFish_C.ExecuteUbergraph_B_Prj_Athena_Thrown_CuddleFish // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

