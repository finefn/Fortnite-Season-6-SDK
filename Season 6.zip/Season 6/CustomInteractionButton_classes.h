// WidgetBlueprintGeneratedClass CustomInteractionButton.CustomInteractionButton_C
// Size: 0xc60 (Inherited: 0xc18)
struct UCustomInteractionButton_C : UFortTextButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc18(0x08)
	struct UWidgetAnimation* OnHover; // 0xc20(0x08)
	struct UBorder* Border_InteractionIndicator; // 0xc28(0x08)
	struct UImage* InteractionIcon; // 0xc30(0x08)
	struct UMenuAnchor* MenuAnchor_Actions; // 0xc38(0x08)
	struct FLinearColor EncourageEpicFriend_IdleColor; // 0xc40(0x10)
	struct FLinearColor EncourageEpicFriend_HoveredColor; // 0xc50(0x10)

	void BP_OnHovered(); // Function CustomInteractionButton.CustomInteractionButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function CustomInteractionButton.CustomInteractionButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CustomInteractionButton(int32_t EntryPoint); // Function CustomInteractionButton.CustomInteractionButton_C.ExecuteUbergraph_CustomInteractionButton // (Final|UbergraphFunction) // @ game+0xbd830c
};

