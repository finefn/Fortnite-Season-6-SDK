// BlueprintGeneratedClass B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C
// Size: 0xe58 (Inherited: 0xc38)
struct AB_Prj_Arrow_ClusterBomb_Athena_C : AB_Prj_Athena_Arrow_Generic_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc38(0x08)
	struct USoundCue* BombSpawnSound; // 0xc40(0x08)
	struct AFortProjectileBase* ClusterBombClass; // 0xc48(0x08)
	struct FScalableFloat Row_DelayBetweenSpawns; // 0xc50(0x28)
	struct FScalableFloat Row_LaunchAngle; // 0xc78(0x28)
	int32_t NumBombsSpawned; // 0xca0(0x04)
	struct FVector InitialSpawnDirection; // 0xca4(0x0c)
	bool bDebugSpawnDirections; // 0xcb0(0x01)
	char UnknownData_CB1[0x7]; // 0xcb1(0x07)
	struct FScalableFloat Row_AngleBetweenBombs; // 0xcb8(0x28)
	struct FVector2D BombSpeedRange; // 0xce0(0x08)
	struct FHitResult CachedHit; // 0xce8(0x88)
	struct FScalableFloat Row_NumBombs; // 0xd70(0x28)
	struct FTimerHandle BombSpawnTimerHandle; // 0xd98(0x08)
	bool bHitPlayer; // 0xda0(0x01)
	char UnknownData_DA1[0x3]; // 0xda1(0x03)
	struct FVector2D PlayerHitBombSpeedScalar; // 0xda4(0x08)
	char UnknownData_DAC[0x4]; // 0xdac(0x04)
	struct FScalableFloat Row_BombSpeedMin; // 0xdb0(0x28)
	struct FScalableFloat Row_BombSpeedMax; // 0xdd8(0x28)
	struct FScalableFloat Row_PlayerHitSpeedScalarMin; // 0xe00(0x28)
	struct FScalableFloat Row_PlayerHitSpeedScalarMax; // 0xe28(0x28)
	struct AB_Prj_Bow_ClusterBomb_Secondary_Athena_C* PrevBombSpawned; // 0xe50(0x08)

	void CheckAllBombsSpawned(bool AllBombsSpawned); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.CheckAllBombsSpawned // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void GetBombSpeedFromRange(float Speed); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.GetBombSpeedFromRange // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void GetAuxiliarySpawnDirectionFromIndex(int32_t Index, struct FVector Direction); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.GetAuxiliarySpawnDirectionFromIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnClusterBomb(struct FHitResult Hit); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.SpawnClusterBomb // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetInitialSpawnDirection(struct FVector Normal, struct FVector Direction); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.GetInitialSpawnDirection // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetSpawnDirectionAsRotation(struct FVector Origin, struct FVector Direction, struct FRotator DirectionAsRotation); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.GetSpawnDirectionAsRotation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void DelayedClusterBombSpawn(); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.DelayedClusterBombSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnFullyChargedImpact(struct FHitResult Hit Result); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.OnFullyChargedImpact // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Arrow_ClusterBomb_Athena(int32_t EntryPoint); // Function B_Prj_Arrow_ClusterBomb_Athena.B_Prj_Arrow_ClusterBomb_Athena_C.ExecuteUbergraph_B_Prj_Arrow_ClusterBomb_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

