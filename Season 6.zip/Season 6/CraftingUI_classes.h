// Class CraftingUI.FortCookingScreen
// Size: 0x370 (Inherited: 0x320)
struct UFortCookingScreen : UCommonActivatableWidget {
	char UnknownData_320[0x8]; // 0x320(0x08)
	struct FDataTableRowHandle CloseInputAction; // 0x328(0x10)
	char UnknownData_338[0x8]; // 0x338(0x08)
	struct UCommonButton* Button_EjectAll; // 0x340(0x08)
	struct UCommonButton* Button_Cancel; // 0x348(0x08)
	struct UCommonTextBlock* Text_RecipeName; // 0x350(0x08)
	struct UCommonTextBlock* Text_RecipeDescription; // 0x358(0x08)
	struct UImage* Image_Recipe; // 0x360(0x08)
	struct UFortSlottedRadialMenu* RadialMenu_Recipes; // 0x368(0x08)
};

// Class CraftingUI.FortCraftingFormulaIngredientsWidget
// Size: 0x290 (Inherited: 0x288)
struct UFortCraftingFormulaIngredientsWidget : UCommonUserWidget {
	struct UDynamicEntryBox* EntryBox_Ingredients; // 0x288(0x08)
};

// Class CraftingUI.FortCraftingIngredientWidget
// Size: 0x2b0 (Inherited: 0x288)
struct UFortCraftingIngredientWidget : UCommonUserWidget {
	char UnknownData_288[0x8]; // 0x288(0x08)
	struct UCommonTextBlock* Text_NumAvailable; // 0x290(0x08)
	struct UCommonTextBlock* Text_NumRequired; // 0x298(0x08)
	struct UAthenaItemIcon* ItemIcon; // 0x2a0(0x08)
	struct UCommonLazyImage* LazyImage_Icon; // 0x2a8(0x08)

	void OnIngredientWidgetUpdated(int32_t NumAvailable, int32_t NumRequired, bool bIsPrimaryIngredient, bool bIsLastIngredient); // Function CraftingUI.FortCraftingIngredientWidget.OnIngredientWidgetUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
};

// Class CraftingUI.FortCraftingItemInfoWidget
// Size: 0x390 (Inherited: 0x320)
struct UFortCraftingItemInfoWidget : UCommonActivatableWidget {
	char UnknownData_320[0x8]; // 0x320(0x08)
	struct FText RarityTextFormat; // 0x328(0x18)
	struct UFortCosmeticItemCard* ItemCard_CraftingResult; // 0x340(0x08)
	struct UCommonTextBlock* Text_ItemName; // 0x348(0x08)
	struct UCommonTextBlock* Text_ItemRarity; // 0x350(0x08)
	struct UCommonTextBlock* Text_ItemCategory; // 0x358(0x08)
	struct UFortItemCategoryIndicator* ItemCategoryIndicator; // 0x360(0x08)
	struct UCommonTextBlock* Text_ItemDescription; // 0x368(0x08)
	struct UAthenaInventoryItemStatsWidget* ItemStatsWidget; // 0x370(0x08)
	struct UFortCraftingFormulaIngredientsWidget* IngredientsWidget; // 0x378(0x08)
	struct UCommonButton* Button_StartCrafting; // 0x380(0x08)
	char UnknownData_388[0x8]; // 0x388(0x08)

	void OnItemRaritySet(enum class EFortRarity Rarity, struct FFortRarityItemData RarityItemData); // Function CraftingUI.FortCraftingItemInfoWidget.OnItemRaritySet // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
};

// Class CraftingUI.FortCraftingListEntry
// Size: 0xc10 (Inherited: 0xbf0)
struct UFortCraftingListEntry : UCommonButton {
	char UnknownData_BF0[0x8]; // 0xbf0(0x08)
	struct UAthenaItemIcon* ItemIcon; // 0xbf8(0x08)
	bool bCanCraftItem; // 0xc00(0x01)
	char UnknownData_C01[0xf]; // 0xc01(0x0f)

	void OnCraftingListItemSet(); // Function CraftingUI.FortCraftingListEntry.OnCraftingListItemSet // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
};

// Class CraftingUI.FortCraftingListItem
// Size: 0xe8 (Inherited: 0x28)
struct UFortCraftingListItem : UObject {
	char UnknownData_28[0xc0]; // 0x28(0xc0)
};

// Class CraftingUI.FortCraftingTab
// Size: 0x408 (Inherited: 0x320)
struct UFortCraftingTab : UCommonActivatableWidget {
	char UnknownData_320[0x8]; // 0x320(0x08)
	struct FName TabNameID; // 0x328(0x08)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x330(0xa0)
	struct FGameplayTagContainer PrimaryIngredientTags; // 0x3d0(0x20)
	struct UFortCraftingItemInfoWidget* CraftingItemInfo; // 0x3f0(0x08)
	struct UCommonListView* ListView_Recipes; // 0x3f8(0x08)
	struct UAthenaQuickbarEditorBase* QuickbarEditor; // 0x400(0x08)

	void OnQuickBarCraftableStatusUpdated(struct TArray<bool> QuickBarSlotCraftableStatus); // Function CraftingUI.FortCraftingTab.OnQuickBarCraftableStatusUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnFormulaListUpdated(int32_t NumFormulas); // Function CraftingUI.FortCraftingTab.OnFormulaListUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void HandleInventoryItemSelected(struct UFortItem* Item); // Function CraftingUI.FortCraftingTab.HandleInventoryItemSelected // (Final|Native|Private) // @ game+0x34edadc
};

// Class CraftingUI.FortPotContentsPopup
// Size: 0x288 (Inherited: 0x260)
struct UFortPotContentsPopup : UUserWidget {
	int32_t MaxItemsToShow; // 0x260(0x04)
	char UnknownData_264[0xc]; // 0x264(0x0c)
	struct UCommonTileView* TileView_PotContents; // 0x270(0x08)
	struct UCommonTextBlock* Text_MoreItems; // 0x278(0x08)
	struct UWidget* Overlay_Popup; // 0x280(0x08)

	void SetOwningCraftingObject(struct ACraftingObjectBGA* InCraftingObject); // Function CraftingUI.FortPotContentsPopup.SetOwningCraftingObject // (Final|Native|Public|BlueprintCallable) // @ game+0x34edb78
};

// Class CraftingUI.FortPotContentsTile
// Size: 0xc00 (Inherited: 0xbf0)
struct UFortPotContentsTile : UCommonButton {
	char UnknownData_BF0[0x8]; // 0xbf0(0x08)
	struct UCommonLazyImage* Image_Item; // 0xbf8(0x08)
};

