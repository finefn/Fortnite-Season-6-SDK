// WidgetBlueprintGeneratedClass AthenaBoundActionButton.AthenaBoundActionButton_C
// Size: 0xbe8 (Inherited: 0xbd0)
struct UAthenaBoundActionButton_C : UFortBoundActionButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd0(0x08)
	struct UBorder* ContentBorder; // 0xbd8(0x08)
	struct UScaleBox* InputActionIconScale; // 0xbe0(0x08)

	void UpdateInputActionIconSize(); // Function AthenaBoundActionButton.AthenaBoundActionButton_C.UpdateInputActionIconSize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function AthenaBoundActionButton.AthenaBoundActionButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaBoundActionButton(int32_t EntryPoint); // Function AthenaBoundActionButton.AthenaBoundActionButton_C.ExecuteUbergraph_AthenaBoundActionButton // (Final|UbergraphFunction) // @ game+0xbd830c
};

