// BlueprintGeneratedClass BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C
// Size: 0xaa8 (Inherited: 0x998)
struct ABP_Athena_Environmental_ZipLine_C : AFortAthenaZipline {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x998(0x08)
	struct UCapsuleComponent* InteractCapsule; // 0x9a0(0x08)
	struct UStaticMeshComponent* SM_Line; // 0x9a8(0x08)
	struct UCapsuleComponent* OverlapCapsule; // 0x9b0(0x08)
	struct USceneComponent* Zipline; // 0x9b8(0x08)
	struct USceneComponent* Scene; // 0x9c0(0x08)
	struct FVector StartLocation; // 0x9c8(0x0c)
	struct FVector TargetLocation; // 0x9d4(0x0c)
	struct FVector MotorOffset; // 0x9e0(0x0c)
	float LineThickness; // 0x9ec(0x04)
	float LineCollisionThickness; // 0x9f0(0x04)
	char UnknownData_9F4[0x4]; // 0x9f4(0x04)
	struct AActor* PoleA; // 0x9f8(0x08)
	struct AActor* PoleB; // 0xa00(0x08)
	struct FCurveTableRowHandle SpeedCTHandle; // 0xa08(0x10)
	struct FCurveTableRowHandle ZipLineEnabledCTHandle; // 0xa18(0x10)
	struct FCurveTableRowHandle LineCollisionRadiusCTHandle; // 0xa28(0x10)
	struct FCurveTableRowHandle BuildingCheckBoxExtentsCTHandle; // 0xa38(0x10)
	struct FName BackendName; // 0xa48(0x08)
	struct UFortQuestItemDefinition* QuestItem; // 0xa50(0x08)
	float LineExtendBeyondPoleLength; // 0xa58(0x04)
	struct FVector PoleASocketLocation; // 0xa5c(0x0c)
	struct FVector PoleBSocketLocation; // 0xa68(0x0c)
	char UnknownData_A74[0x4]; // 0xa74(0x04)
	struct AFortPlayerPawn* PlayerPawn; // 0xa78(0x08)
	struct TArray<struct AFortPlayerPawn*> PlayersPendingMovementModeChange; // 0xa80(0x10)
	float CollisionHeightAboveLine; // 0xa90(0x04)
	struct FVector PlayerOffsetToLine_Hoverboard; // 0xa94(0x0c)
	struct FTimerHandle EndOverlapReleaseTimer; // 0xaa0(0x08)

	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void CalculatePositionsOfPoles(); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.CalculatePositionsOfPoles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Setup Overlap Bindings(); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.Setup Overlap Bindings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleEnterZipline(struct AFortPlayerPawn* InPlayerPawn); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.HandleEnterZipline // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckForBuildings(struct AFortPlayerPawn* Player, bool BuildingNearby?); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.CheckForBuildings // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void QuestCheckForUse(struct AFortPlayerController* FortPlayerController); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.QuestCheckForUse // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetCharacterCustomMovementMode(struct APawn* Character, enum class EFortCustomMovement CustomMovementMode, enum class EMovementMode MovementMode); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.GetCharacterCustomMovementMode // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void StartZipLining(struct AFortPlayerPawn* FortPlayerPawn); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.StartZipLining // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void HandleOnMapInfoInitialized(); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.HandleOnMapInfoInitialized // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleOnMovementModeChanged(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, enum class None PreviousCustomMode); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.HandleOnMovementModeChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleOnBeginOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.HandleOnBeginOverlap // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleOnEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.HandleOnEndOverlap // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReleaseZipline(); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.ReleaseZipline // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_Athena_Environmental_ZipLine(int32_t EntryPoint); // Function BP_Athena_Environmental_ZipLine.BP_Athena_Environmental_ZipLine_C.ExecuteUbergraph_BP_Athena_Environmental_ZipLine // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

