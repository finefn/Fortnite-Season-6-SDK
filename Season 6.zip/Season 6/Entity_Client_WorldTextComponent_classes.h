// SolarisGeneratedClass Entity_Client_WorldTextComponent.WorldTextComponent
// Size: 0x88 (Inherited: 0x88)
struct UWorldTextComponent : UEntityActorTextDisplayComponent {

	void setWorldText(struct FString __verse_0x4069CADB_Text); // Function Entity_Client_WorldTextComponent.WorldTextComponent.setWorldText // (Native|Public|BlueprintCallable) // @ game+0x3ed71c4
	void SetVerticalAlignment(enum class WorldTextVerticalAlignment __verse_0x3AF80D16_value); // Function Entity_Client_WorldTextComponent.WorldTextComponent.SetVerticalAlignment // (Native|Public|BlueprintCallable) // @ game+0x3ed71b4
	void SetTextRenderColor(struct UColor* __verse_0x3AF80D16_value); // Function Entity_Client_WorldTextComponent.WorldTextComponent.SetTextRenderColor // (Native|Public|BlueprintCallable) // @ game+0x3ed719c
	void SetSize(float __verse_0x31A8F10C_Value); // Function Entity_Client_WorldTextComponent.WorldTextComponent.SetSize // (Native|Public|BlueprintCallable) // @ game+0x3ed7184
	void SetRelativeScale(struct UVector3* __verse_0x5FA07D28_relativeScale); // Function Entity_Client_WorldTextComponent.WorldTextComponent.SetRelativeScale // (Native|Public|BlueprintCallable) // @ game+0x3ed716c
	void SetRelativeRotation(struct UVector3* __verse_0xA6C7E40A_relativeRotation); // Function Entity_Client_WorldTextComponent.WorldTextComponent.SetRelativeRotation // (Native|Public|BlueprintCallable) // @ game+0x3ed7164
	void SetRelativeLocation(struct UVector3* __verse_0x6EC295F3_relativeLocation); // Function Entity_Client_WorldTextComponent.WorldTextComponent.SetRelativeLocation // (Native|Public|BlueprintCallable) // @ game+0x3ed715c
	void SetHorizontalAlignment(enum class WorldTextHorizontalAlignment __verse_0x3AF80D16_value); // Function Entity_Client_WorldTextComponent.WorldTextComponent.SetHorizontalAlignment // (Native|Public|BlueprintCallable) // @ game+0x3ed7134
	struct FString getWorldText(); // Function Entity_Client_WorldTextComponent.WorldTextComponent.getWorldText // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6e44
	enum class WorldTextVerticalAlignment GetVerticalAlignment(); // Function Entity_Client_WorldTextComponent.WorldTextComponent.GetVerticalAlignment // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6e20
	struct UColor* GetTextRenderColor(); // Function Entity_Client_WorldTextComponent.WorldTextComponent.GetTextRenderColor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6d60
	float GetSize(); // Function Entity_Client_WorldTextComponent.WorldTextComponent.GetSize // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3e2e424
	struct UVector3* GetRelativeLocation(); // Function Entity_Client_WorldTextComponent.WorldTextComponent.GetRelativeLocation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6c18
	enum class WorldTextHorizontalAlignment GetHorizontalAlignment(); // Function Entity_Client_WorldTextComponent.WorldTextComponent.GetHorizontalAlignment // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6b30
	void $InitInstance(); // Function Entity_Client_WorldTextComponent.WorldTextComponent.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Entity_Client_WorldTextComponent.WorldTextComponent.$InitCDO // () // @ game+0xbd830c
};

