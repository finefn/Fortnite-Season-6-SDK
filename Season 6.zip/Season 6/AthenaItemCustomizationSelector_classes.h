// WidgetBlueprintGeneratedClass AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C
// Size: 0x884 (Inherited: 0x7a8)
struct UAthenaItemCustomizationSelector_C : UAthenaItemSelectorScreenBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7a8(0x08)
	struct UWidgetAnimation* PulseAnim; // 0x7b0(0x08)
	struct UWidgetAnimation* CannotSlide; // 0x7b8(0x08)
	struct UWidgetAnimation* NormalState; // 0x7c0(0x08)
	struct UWidgetAnimation* SlideRight; // 0x7c8(0x08)
	struct UWidgetAnimation* SlideLeft; // 0x7d0(0x08)
	struct UWidgetAnimation* HideTextSearch; // 0x7d8(0x08)
	struct UWidgetAnimation* ShowTextSearch; // 0x7e0(0x08)
	struct UWidgetAnimation* ItemInfoIntroOutro; // 0x7e8(0x08)
	struct UWidgetAnimation* Intro; // 0x7f0(0x08)
	struct UOverlay* CameraFrameContainer; // 0x7f8(0x08)
	struct UCloseButton_C* CloseButton; // 0x800(0x08)
	struct UHorizontalBox* ExclusiveCalloutBox; // 0x808(0x08)
	struct UCommonRichTextBlock* ExclusiveCalloutText; // 0x810(0x08)
	struct USafeZone* MainSafeZone; // 0x818(0x08)
	struct USizeBox* SB_MainContent; // 0x820(0x08)
	struct USizeBox* SB_SaveAndExit; // 0x828(0x08)
	struct UCommonTextBlock* ShortDescriptionText; // 0x830(0x08)
	struct UImage* SlotImage; // 0x838(0x08)
	struct UCommonTextBlock* TextBox_LockerRoomMode; // 0x840(0x08)
	struct UCommonWidgetSwitcher* WidgetSwitcher_InteractionMethod; // 0x848(0x08)
	struct UCommonWidgetSwitcher* WidgetSwitcher_ItemEditor; // 0x850(0x08)
	struct UProgressModalWidget_C* ProgressModal; // 0x858(0x08)
	bool bPickingStyle; // 0x860(0x01)
	bool bHandledBackRequest; // 0x861(0x01)
	char UnknownData_862[0x6]; // 0x862(0x06)
	struct FTimerHandle AutoHideInfoPanelEventTimer; // 0x868(0x08)
	struct FTimerHandle TextEntryTimer; // 0x870(0x08)
	int32_t SeasonFilter; // 0x878(0x04)
	int32_t MaxSeason; // 0x87c(0x04)
	float ItemInfoHideDelayTime; // 0x880(0x04)

	void UpdateSeasonButtonEnabledState(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.UpdateSeasonButtonEnabledState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct UMaterialInstance* GetCategoryImage(enum class EAthenaCustomizationCategory Index, struct UMaterialInstance* OverrideImage); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.GetCategoryImage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void HandleItemSetupFinished(struct FText InText, enum class EAthenaCustomizationCategory Category, struct UMaterialInstance* OverrideImage); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.HandleItemSetupFinished // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetCurrentItemCosmeticDefinition(struct UAthenaCosmeticItemDefinition* Cosmetic Item Definition); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.GetCurrentItemCosmeticDefinition // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShowSavingModal(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.ShowSavingModal // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleBack(bool PassThrough); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.HandleBack // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__HorizontalTabList_K2Node_ComponentBoundEvent_44_OnTabButtonCreated__DelegateSignature(struct FName TabId, struct UCommonButton* TabButton); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.BndEvt__HorizontalTabList_K2Node_ComponentBoundEvent_44_OnTabButtonCreated__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnFinsihedItemSave(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.OnFinsihedItemSave // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnSavingItemStarted(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.OnSavingItemStarted // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BP_OnActivated(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnTabSelectionChanged(bool bShowingVariants); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.OnTabSelectionChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnCurrentItemChanged(struct UFortItem* SelectedItem); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.OnCurrentItemChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Picker_ItemSelector_K2Node_ComponentBoundEvent_1_OnUpdateSaveButtonVisuals__DelegateSignature(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.BndEvt__Picker_ItemSelector_K2Node_ComponentBoundEvent_1_OnUpdateSaveButtonVisuals__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Picker_ItemSelector_K2Node_ComponentBoundEvent_2_OnUpdateSaveButtonVisuals__DelegateSignature(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.BndEvt__Picker_ItemSelector_K2Node_ComponentBoundEvent_2_OnUpdateSaveButtonVisuals__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnFinishedItemSetup(struct FText CategoryDisplayName, struct FText ItemDisplayTypeName, enum class EAthenaCustomizationCategory SelectedCategory, struct UMaterialInstance* OverrideSlotImage); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.OnFinishedItemSetup // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void HandleTextSearchSelectedChanged(bool bIsSelected); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.HandleTextSearchSelectedChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleTextChanged(struct FText NewText); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.HandleTextChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CloseButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.BndEvt__CloseButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnHideItemInfoHeader(bool bShouldHide); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.OnHideItemInfoHeader // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnUpdateExclusiveItemCallout(bool bShouldShow, struct FText CalloutText); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.OnUpdateExclusiveItemCallout // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnVariantSelectionChangedBP(struct FMcpVariantChannelInfo InVariant); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.OnVariantSelectionChangedBP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void HandleShowInfoPanel(struct UFortItem* SelectedItem); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.HandleShowInfoPanel // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleHideInfoPanel(); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.HandleHideInfoPanel // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaItemCustomizationSelector(int32_t EntryPoint); // Function AthenaItemCustomizationSelector.AthenaItemCustomizationSelector_C.ExecuteUbergraph_AthenaItemCustomizationSelector // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

