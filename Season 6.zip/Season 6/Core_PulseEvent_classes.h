// SolarisGeneratedClass Core_PulseEvent.Context_PulseEvent_wait
// Size: 0xa0 (Inherited: 0xa0)
struct UContext_PulseEvent_wait : UContext__wait {

	int32_t Update(); // Function Core_PulseEvent.Context_PulseEvent_wait.Update // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea02c0
};

// SolarisGeneratedClass Core_PulseEvent.PulseEvent
// Size: 0x50 (Inherited: 0x50)
struct UPulseEvent : UEvent {

	void signal(); // Function Core_PulseEvent.PulseEvent.signal // (Native|Public|BlueprintCallable) // @ game+0x3ea0e28
	struct UPulseEvent* Create(); // Function Core_PulseEvent.PulseEvent.Create // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea06f8
	void $InitInstance(); // Function Core_PulseEvent.PulseEvent.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Core_PulseEvent.PulseEvent.$InitCDO // () // @ game+0xbd830c
};

