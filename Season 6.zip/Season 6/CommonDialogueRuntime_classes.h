// Class CommonDialogueRuntime.ConversationParticipantComponent
// Size: 0x188 (Inherited: 0xb0)
struct UConversationParticipantComponent : UActorComponent {
	char UnknownData_B0[0xb4]; // 0xb0(0xb4)
	int32_t ConversationsActive; // 0x164(0x04)
	struct UConversationInstance* Auth_CurrentConversation; // 0x168(0x08)
	struct TArray<struct UConversationInstance*> Auth_Conversations; // 0x170(0x10)
	char UnknownData_180[0x8]; // 0x180(0x08)

	void ServerAdvanceConversation(struct FAdvanceConversationRequest InChoicePicked); // Function CommonDialogueRuntime.ConversationParticipantComponent.ServerAdvanceConversation // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x34be860
	void RequestServerAdvanceConversation(struct FAdvanceConversationRequest InChoicePicked); // Function CommonDialogueRuntime.ConversationParticipantComponent.RequestServerAdvanceConversation // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x34be79c
	void OnRep_ConversationsActive(int32_t OldConversationsActive); // Function CommonDialogueRuntime.ConversationParticipantComponent.OnRep_ConversationsActive // (Final|Native|Protected) // @ game+0x34be528
	struct FText GetParticipantDisplayName(); // Function CommonDialogueRuntime.ConversationParticipantComponent.GetParticipantDisplayName // (Native|Public|BlueprintCallable) // @ game+0x34be1c0
	void ClientUpdateParticipants(struct FConversationParticipants InParticipants); // Function CommonDialogueRuntime.ConversationParticipantComponent.ClientUpdateParticipants // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x34bd834
	void ClientUpdateConversations(int32_t InConversationsActive); // Function CommonDialogueRuntime.ConversationParticipantComponent.ClientUpdateConversations // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x34bd798
	void ClientUpdateConversation(struct FClientConversationMessagePayload Message); // Function CommonDialogueRuntime.ConversationParticipantComponent.ClientUpdateConversation // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x34bd6e4
	void ClientStartConversation(struct UConversationInstance* Conversation, struct FGameplayTag AsParticipant); // Function CommonDialogueRuntime.ConversationParticipantComponent.ClientStartConversation // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x34bd5f8
	void ClientExecuteTaskAndSideEffects(struct FConversationNodeHandle Handle); // Function CommonDialogueRuntime.ConversationParticipantComponent.ClientExecuteTaskAndSideEffects // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x34bd54c
};

// Class CommonDialogueRuntime.ConversationNode
// Size: 0x58 (Inherited: 0x28)
struct UConversationNode : UObject {
	struct UObject* EvalWorldContextObj; // 0x28(0x08)
	struct FString NodeName; // 0x30(0x10)
	struct FGuid Compiled_NodeGUID; // 0x40(0x10)
	struct UConversationNode* ParentNode; // 0x50(0x08)

	struct FLinearColor GetDebugParticipantColor(struct FGameplayTag ParticipantID); // Function CommonDialogueRuntime.ConversationNode.GetDebugParticipantColor // (Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x34be030
};

// Class CommonDialogueRuntime.ConversationSubNode
// Size: 0x58 (Inherited: 0x58)
struct UConversationSubNode : UConversationNode {
};

// Class CommonDialogueRuntime.ConversationChoiceNode
// Size: 0x90 (Inherited: 0x58)
struct UConversationChoiceNode : UConversationSubNode {
	struct FText DefaultChoiceDisplayText; // 0x58(0x18)
	struct FGameplayTagContainer ChoiceTags; // 0x70(0x20)

	void FillChoice(struct FConversationContext Context, struct FClientConversationOptionEntry ChoiceEntry); // Function CommonDialogueRuntime.ConversationChoiceNode.FillChoice // (Native|Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x34bda2c
};

// Class CommonDialogueRuntime.ConversationContextHelpers
// Size: 0x28 (Inherited: 0x28)
struct UConversationContextHelpers : UBlueprintFunctionLibrary {

	struct FConversationTaskResult ReturnToLastClientChoice(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationContextHelpers.ReturnToLastClientChoice // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34bd198
	struct FConversationTaskResult ReturnToCurrentClientChoice(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationContextHelpers.ReturnToCurrentClientChoice // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34bd198
	struct FConversationTaskResult ReturnToConversationStart(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationContextHelpers.ReturnToConversationStart // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34bd198
	struct FConversationTaskResult PauseConversationAndSendClientChoices(struct FConversationContext Context, struct FClientConversationMessage Message); // Function CommonDialogueRuntime.ConversationContextHelpers.PauseConversationAndSendClientChoices // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34be5c0
	void MakeConversationParticipant(struct FConversationContext Context, struct AActor* ParticipantActor, struct FGameplayTag ParticipantTag); // Function CommonDialogueRuntime.ConversationContextHelpers.MakeConversationParticipant // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34be3dc
	struct FConversationNodeHandle GetCurrentConversationNodeHandle(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationContextHelpers.GetCurrentConversationNodeHandle // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x34bdf44
	struct AActor* GetConversationParticipantActor(struct FConversationContext Context, struct FGameplayTag ParticipantTag); // Function CommonDialogueRuntime.ConversationContextHelpers.GetConversationParticipantActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34bde0c
	struct UConversationParticipantComponent* GetConversationParticipant(struct FConversationContext Context, struct FGameplayTag ParticipantTag); // Function CommonDialogueRuntime.ConversationContextHelpers.GetConversationParticipant // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34bdce4
	struct UConversationInstance* GetConversationInstance(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationContextHelpers.GetConversationInstance // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x34bdc24
	struct UConversationParticipantComponent* FindConversationComponent(struct AActor* Actor); // Function CommonDialogueRuntime.ConversationContextHelpers.FindConversationComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x34bdb80
	struct FConversationTaskResult AdvanceConversationWithChoice(struct FConversationContext Context, struct FAdvanceConversationRequest Choice); // Function CommonDialogueRuntime.ConversationContextHelpers.AdvanceConversationWithChoice // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34bd2d0
	struct FConversationTaskResult AdvanceConversation(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationContextHelpers.AdvanceConversation // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x34bd198
};

// Class CommonDialogueRuntime.ConversationDatabase
// Size: 0xe8 (Inherited: 0x30)
struct UConversationDatabase : UPrimaryDataAsset {
	int32_t CompilerVersion; // 0x30(0x04)
	char UnknownData_34[0x4]; // 0x34(0x04)
	struct TMap<struct FGuid, struct UConversationNode*> ReachableNodeMap; // 0x38(0x50)
	struct TArray<struct FConversationEntryList> EntryTags; // 0x88(0x10)
	struct FGameplayTagContainer ExitTags; // 0x98(0x20)
	struct TArray<struct FGuid> InternalNodeIds; // 0xb8(0x10)
	struct TArray<struct FGuid> LinkedToNodeIds; // 0xc8(0x10)
	struct TArray<struct FCommonDialogueBankParticipant> Speakers; // 0xd8(0x10)
};

// Class CommonDialogueRuntime.ConversationNodeWithLinks
// Size: 0x68 (Inherited: 0x58)
struct UConversationNodeWithLinks : UConversationNode {
	struct TArray<struct FGuid> OutputConnections; // 0x58(0x10)
};

// Class CommonDialogueRuntime.ConversationEntryPointNode
// Size: 0x70 (Inherited: 0x68)
struct UConversationEntryPointNode : UConversationNodeWithLinks {
	struct FGameplayTag EntryTag; // 0x68(0x08)
};

// Class CommonDialogueRuntime.ConversationInstance
// Size: 0x190 (Inherited: 0x28)
struct UConversationInstance : UObject {
	struct FConversationParticipants Participants; // 0x28(0x10)
	char UnknownData_38[0x158]; // 0x38(0x158)
};

// Class CommonDialogueRuntime.ConversationLibrary
// Size: 0x28 (Inherited: 0x28)
struct UConversationLibrary : UBlueprintFunctionLibrary {

	struct UConversationInstance* StartConversation(struct FGameplayTag ConversationEntryTag, struct AActor* Instigator, struct FGameplayTag InstigatorTag, struct AActor* Target, struct FGameplayTag TargetTag); // Function CommonDialogueRuntime.ConversationLibrary.StartConversation // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x34be9f0
};

// Class CommonDialogueRuntime.ConversationTaskNode
// Size: 0x78 (Inherited: 0x68)
struct UConversationTaskNode : UConversationNodeWithLinks {
	struct TArray<struct UConversationSubNode*> SubNodes; // 0x68(0x10)

	enum class EConversationRequirementResult IsRequirementSatisfied(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationTaskNode.IsRequirementSatisfied // (BlueprintAuthorityOnly|Native|Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x34be308
	bool GetNodeBodyColor(struct FLinearColor BodyColor); // Function CommonDialogueRuntime.ConversationTaskNode.GetNodeBodyColor // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const) // @ game+0x34be110
	struct FConversationTaskResult ExecuteTaskNode(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationTaskNode.ExecuteTaskNode // (BlueprintAuthorityOnly|Native|Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x34bd8e0
	void ExecuteClientEffects(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationTaskNode.ExecuteClientEffects // (BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x34bd488
};

// Class CommonDialogueRuntime.ConversationLinkNode
// Size: 0x80 (Inherited: 0x78)
struct UConversationLinkNode : UConversationTaskNode {
	struct FGameplayTag RemoteEntryTag; // 0x78(0x08)
};

// Class CommonDialogueRuntime.ConversationRegistry
// Size: 0x1d8 (Inherited: 0x30)
struct UConversationRegistry : UWorldSubsystem {
	struct FNetSerializeScriptStructCache_ConvVersion ConversationChoiceDataStructCache; // 0x30(0x60)
	char UnknownData_90[0x148]; // 0x90(0x148)
};

// Class CommonDialogueRuntime.ConversationRequirementNode
// Size: 0x58 (Inherited: 0x58)
struct UConversationRequirementNode : UConversationSubNode {

	enum class EConversationRequirementResult IsRequirementSatisfied(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationRequirementNode.IsRequirementSatisfied // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x34be234
};

// Class CommonDialogueRuntime.ConversationSettings
// Size: 0x60 (Inherited: 0x38)
struct UConversationSettings : UDeveloperSettings {
	SoftClassProperty ConversationInstanceClass; // 0x38(0x28)
};

// Class CommonDialogueRuntime.ConversationSideEffectNode
// Size: 0x58 (Inherited: 0x58)
struct UConversationSideEffectNode : UConversationSubNode {

	void ServerCauseSideEffect(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationSideEffectNode.ServerCauseSideEffect // (BlueprintAuthorityOnly|Native|Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x34be92c
	void ClientCauseSideEffect(struct FConversationContext Context); // Function CommonDialogueRuntime.ConversationSideEffectNode.ClientCauseSideEffect // (BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x34bd488
};

