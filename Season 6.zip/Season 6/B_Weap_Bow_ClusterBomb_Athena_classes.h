// BlueprintGeneratedClass B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C
// Size: 0x1459 (Inherited: 0x13e8)
struct AB_Weap_Bow_ClusterBomb_Athena_C : AB_Weap_Bow_Athena_Generic_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x13e8(0x08)
	float TL_LightBlink_Interpolation_F333F38B4214A9701E9113BE6454B071; // 0x13f0(0x04)
	enum class ETimelineDirection TL_LightBlink__Direction_F333F38B4214A9701E9113BE6454B071; // 0x13f4(0x01)
	char UnknownData_13F5[0x3]; // 0x13f5(0x03)
	struct UTimelineComponent* TL_LightBlink; // 0x13f8(0x08)
	struct UMaterialInstanceDynamic* MeshMaterial; // 0x1400(0x08)
	struct FLinearColor VectorParam_LightOn; // 0x1408(0x10)
	struct FLinearColor VectorParam_LightOff; // 0x1418(0x10)
	bool bLightsOn; // 0x1428(0x01)
	char UnknownData_1429[0x3]; // 0x1429(0x03)
	float LightBlinkFrequency; // 0x142c(0x04)
	struct FTimerHandle BlinkTimerHandle; // 0x1430(0x08)
	bool bBlinkOnFullyCharged; // 0x1438(0x01)
	char UnknownData_1439[0x7]; // 0x1439(0x07)
	struct USoundBase* BlinkSound_1P; // 0x1440(0x08)
	float BlinkEmissiveLerpTime; // 0x1448(0x04)
	char UnknownData_144C[0x4]; // 0x144c(0x04)
	struct USoundBase* BlinkSound_3P; // 0x1450(0x08)
	bool bIsLocalClient; // 0x1458(0x01)

	void ForceEmissiveOff(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.ForceEmissiveOff // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TL_LightBlink__FinishedFunc(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.TL_LightBlink__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void TL_LightBlink__UpdateFunc(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.TL_LightBlink__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void DeactivateFullyChargedFX(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.DeactivateFullyChargedFX // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlinkLights(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.BlinkLights // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayBlinkSound(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.PlayBlinkSound // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SpawnFullyChargedFX(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.SpawnFullyChargedFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnReachedMaxCharge(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.OnReachedMaxCharge // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnRemoteClientReachedMaxCharge(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.OnRemoteClientReachedMaxCharge // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Weap_Bow_ClusterBomb_Athena(int32_t EntryPoint); // Function B_Weap_Bow_ClusterBomb_Athena.B_Weap_Bow_ClusterBomb_Athena_C.ExecuteUbergraph_B_Weap_Bow_ClusterBomb_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

