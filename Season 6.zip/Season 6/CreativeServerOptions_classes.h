// WidgetBlueprintGeneratedClass CreativeServerOptions.CreativeServerOptions_C
// Size: 0x320 (Inherited: 0x2c8)
struct UCreativeServerOptions_C : UFortCreativeServersView {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct UWidgetAnimation* Intro; // 0x2d0(0x08)
	struct UCircleArrowButton_C* CircleArrowButton_Left; // 0x2d8(0x08)
	struct UCircleArrowButton_C* CircleArrowButton_Right; // 0x2e0(0x08)
	struct UCreativeServerOptionsTile_C* CreativeServerOptionsTile; // 0x2e8(0x08)
	struct UCreativeServerOptionsTile_C* CreativeServerOptionsTile_1; // 0x2f0(0x08)
	struct UCommonWidgetCarousel* ServerCarousel; // 0x2f8(0x08)
	struct UCommonWidgetCarouselNavBar* ServerCarouselNavBar; // 0x300(0x08)
	struct UFortSwipePanel* SwipePanel; // 0x308(0x08)
	struct FMulticastInlineDelegate OnSelectedServerChanged; // 0x310(0x10)

	void OnCreativeServerListRefreshed(); // Function CreativeServerOptions.CreativeServerOptions_C.OnCreativeServerListRefreshed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__SwipePanel_K2Node_ComponentBoundEvent_2_OnFortSwipeEvent__DelegateSignature(); // Function CreativeServerOptions.CreativeServerOptions_C.BndEvt__SwipePanel_K2Node_ComponentBoundEvent_2_OnFortSwipeEvent__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__SwipePanel_K2Node_ComponentBoundEvent_3_OnFortSwipeEvent__DelegateSignature(); // Function CreativeServerOptions.CreativeServerOptions_C.BndEvt__SwipePanel_K2Node_ComponentBoundEvent_3_OnFortSwipeEvent__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function CreativeServerOptions.CreativeServerOptions_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CircleArrowButton_Left_K2Node_ComponentBoundEvent_4_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeServerOptions.CreativeServerOptions_C.BndEvt__CircleArrowButton_Left_K2Node_ComponentBoundEvent_4_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CircleArrowButton_Right_K2Node_ComponentBoundEvent_5_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeServerOptions.CreativeServerOptions_C.BndEvt__CircleArrowButton_Right_K2Node_ComponentBoundEvent_5_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void EventIntro(); // Function CreativeServerOptions.CreativeServerOptions_C.EventIntro // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function CreativeServerOptions.CreativeServerOptions_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CreativeServerOptions(int32_t EntryPoint); // Function CreativeServerOptions.CreativeServerOptions_C.ExecuteUbergraph_CreativeServerOptions // (Final|UbergraphFunction) // @ game+0xbd830c
	void OnSelectedServerChanged__DelegateSignature(struct UFortCreativeServerInfo* ServerInfo); // Function CreativeServerOptions.CreativeServerOptions_C.OnSelectedServerChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

