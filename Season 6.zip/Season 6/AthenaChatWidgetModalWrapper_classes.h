// WidgetBlueprintGeneratedClass AthenaChatWidgetModalWrapper.AthenaChatWidgetModalWrapper_C
// Size: 0x330 (Inherited: 0x328)
struct UAthenaChatWidgetModalWrapper_C : UAthenaChatModalWrapper {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x328(0x08)

	void FocusChat(); // Function AthenaChatWidgetModalWrapper.AthenaChatWidgetModalWrapper_C.FocusChat // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function AthenaChatWidgetModalWrapper.AthenaChatWidgetModalWrapper_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnInitialized(); // Function AthenaChatWidgetModalWrapper.AthenaChatWidgetModalWrapper_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaChatWidgetModalWrapper(int32_t EntryPoint); // Function AthenaChatWidgetModalWrapper.AthenaChatWidgetModalWrapper_C.ExecuteUbergraph_AthenaChatWidgetModalWrapper // (Final|UbergraphFunction) // @ game+0xbd830c
};

