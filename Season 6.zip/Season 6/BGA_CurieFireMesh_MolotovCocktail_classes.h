// BlueprintGeneratedClass BGA_CurieFireMesh_MolotovCocktail.BGA_CurieFireMesh_MolotovCocktail_C
// Size: 0x890 (Inherited: 0x868)
struct ABGA_CurieFireMesh_MolotovCocktail_C : ABGA_GenericCurieFuel_Parent_C {
	struct FScalableFloat SelfPropagationFuelRowValue; // 0x868(0x28)

	void UserConstructionScript(); // Function BGA_CurieFireMesh_MolotovCocktail.BGA_CurieFireMesh_MolotovCocktail_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

