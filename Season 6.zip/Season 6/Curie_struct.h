// Enum Curie.ECurieEntityType
enum class ECurieEntityType : uint8 {
	Invalid,
	Material,
	Element,
	ECurieEntityType_MAX,
};

// ScriptStruct Curie.CurieContainerHandle
// Size: 0x04 (Inherited: 0x00)
struct FCurieContainerHandle {
	char UnknownData_0[0x4]; // 0x00(0x04)
};

// ScriptStruct Curie.CurieInteractParamsHandle
// Size: 0x10 (Inherited: 0x00)
struct FCurieInteractParamsHandle {
	char UnknownData_0[0x10]; // 0x00(0x10)
};

// ScriptStruct Curie.CurieInteractHandle
// Size: 0x04 (Inherited: 0x00)
struct FCurieInteractHandle {
	char UnknownData_0[0x4]; // 0x00(0x04)
};

// ScriptStruct Curie.CurieElementHandle
// Size: 0x04 (Inherited: 0x00)
struct FCurieElementHandle {
	char UnknownData_0[0x4]; // 0x00(0x04)
};

// ScriptStruct Curie.CurieStateHandle
// Size: 0x04 (Inherited: 0x00)
struct FCurieStateHandle {
	char UnknownData_0[0x4]; // 0x00(0x04)
};

// ScriptStruct Curie.CurieEffectContainer
// Size: 0x50 (Inherited: 0x00)
struct FCurieEffectContainer {
	struct FGameplayTagQuery TargetFilter; // 0x00(0x48)
	struct UGameplayEffect* GameplayEffect; // 0x48(0x08)
};

// ScriptStruct Curie.CurieEntityStateDefinitionBase
// Size: 0x18 (Inherited: 0x08)
struct FCurieEntityStateDefinitionBase : FTableRowBase {
	struct UCurieEntityStateBehavior* StateBehaviorClass; // 0x08(0x08)
	char bIsEnabled : 1; // 0x10(0x01)
	char UnknownData_10_1 : 7; // 0x10(0x01)
	char UnknownData_11[0x7]; // 0x11(0x07)
};

// ScriptStruct Curie.CurieElementDefinitionBase
// Size: 0x38 (Inherited: 0x08)
struct FCurieElementDefinitionBase : FTableRowBase {
	struct UCurieElementBehavior* BehaviorClass; // 0x08(0x08)
	struct FGameplayTagContainer ElementalImmunities; // 0x10(0x20)
	char bIsEnabled : 1; // 0x30(0x01)
	char UnknownData_30_1 : 7; // 0x30(0x01)
	char UnknownData_31[0x7]; // 0x31(0x07)
};

// ScriptStruct Curie.CurieMaterialDefinitionBase
// Size: 0x68 (Inherited: 0x08)
struct FCurieMaterialDefinitionBase : FTableRowBase {
	struct FGameplayTagContainer ElementalImmunities; // 0x08(0x20)
	struct FGameplayTagContainer ElementAttachmentImmunities; // 0x28(0x20)
	struct FGameplayTagContainer ElementsAllowedWhenCannotBeDamaged; // 0x48(0x20)
};

