// BlueprintGeneratedClass B_TargetTrack.B_TargetTrack_C
// Size: 0xcd3 (Inherited: 0xbc0)
struct AB_TargetTrack_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc0(0x08)
	struct USphereComponent* ProximityTrigger; // 0xbc8(0x08)
	struct UAudioComponent* Target_Move_Loop_Cue; // 0xbd0(0x08)
	struct UAudioComponent* Target_Move_Stop_Cue; // 0xbd8(0x08)
	struct UAudioComponent* Target_Move_Start_Cue; // 0xbe0(0x08)
	struct UToyOptionsComponent_C* ToyOptionsComponent; // 0xbe8(0x08)
	struct USceneComponent* TargetAttachPoint; // 0xbf0(0x08)
	struct UStaticMeshComponent* SM_Target_Track; // 0xbf8(0x08)
	float TargetMovement_NewTrack_0_9F61BF394D22B10B7DAB4683CA4746AC; // 0xc00(0x04)
	enum class ETimelineDirection TargetMovement__Direction_9F61BF394D22B10B7DAB4683CA4746AC; // 0xc04(0x01)
	char UnknownData_C05[0x3]; // 0xc05(0x03)
	struct UTimelineComponent* TargetMovement; // 0xc08(0x08)
	struct FTransform BaseTransformForTarget; // 0xc10(0x30)
	float LengthScaleSetting; // 0xc40(0x04)
	float DelayAtEndSetting; // 0xc44(0x04)
	float ProximityTriggerSizeSetting; // 0xc48(0x04)
	float InitialMovementDelaySetting; // 0xc4c(0x04)
	float TrackSpeedSetting; // 0xc50(0x04)
	bool IsCurrentlyMoving; // 0xc54(0x01)
	bool AtStartPoint; // 0xc55(0x01)
	bool LoopingSetting; // 0xc56(0x01)
	char UnknownData_C57[0x1]; // 0xc57(0x01)
	int32_t RotationSetting; // 0xc58(0x04)
	char UnknownData_C5C[0x4]; // 0xc5c(0x04)
	struct AB_ShootingTarget_Master_C* AttachedTarget; // 0xc60(0x08)
	struct TSoftObjectPtr<struct UStaticMesh> LeftRightTargetBaseMesh; // 0xc68(0x28)
	struct TSoftObjectPtr<struct UStaticMesh> ForwardBackwardTargetBaseMesh; // 0xc90(0x28)
	struct TArray<struct UPrimitiveComponent*> NewVar_1; // 0xcb8(0x10)
	bool IsTargetUp; // 0xcc8(0x01)
	enum class None CurrentMovementState; // 0xcc9(0x01)
	char UnknownData_CCA[0x2]; // 0xcca(0x02)
	int32_t Audio Speed Parameter; // 0xccc(0x04)
	enum class None LeftToRightmovementState; // 0xcd0(0x01)
	enum class None RightToLeftMovementState; // 0xcd1(0x01)
	enum class None StopMovementState; // 0xcd2(0x01)

	struct TArray<struct UMeshComponent*> GetMeshComponents(); // Function B_TargetTrack.B_TargetTrack_C.GetMeshComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	struct UStaticMesh* GetCollisionStaticMesh(); // Function B_TargetTrack.B_TargetTrack_C.GetCollisionStaticMesh // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void Set Audio Speed Sound(float Target Speed); // Function B_TargetTrack.B_TargetTrack_C.Set Audio Speed Sound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_CurrentMovementState(); // Function B_TargetTrack.B_TargetTrack_C.OnRep_CurrentMovementState // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetMovementState(enum class None State); // Function B_TargetTrack.B_TargetTrack_C.SetMovementState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateLerpedPosition(float Alpha); // Function B_TargetTrack.B_TargetTrack_C.UpdateLerpedPosition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_CurrentLerpValue(); // Function B_TargetTrack.B_TargetTrack_C.OnRep_CurrentLerpValue // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateForRepNotify(); // Function B_TargetTrack.B_TargetTrack_C.UpdateForRepNotify // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_IsCurrentlyMoving(); // Function B_TargetTrack.B_TargetTrack_C.OnRep_IsCurrentlyMoving // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_CurrentDirection(); // Function B_TargetTrack.B_TargetTrack_C.OnRep_CurrentDirection // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_IsTargetUp(); // Function B_TargetTrack.B_TargetTrack_C.OnRep_IsTargetUp // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_ServerMoveStartTime(); // Function B_TargetTrack.B_TargetTrack_C.OnRep_ServerMoveStartTime // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetTrackLength(); // Function B_TargetTrack.B_TargetTrack_C.SetTrackLength // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetTargetRotationAndBaseMesh(); // Function B_TargetTrack.B_TargetTrack_C.SetTargetRotationAndBaseMesh // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	float CalculatePlayRate(); // Function B_TargetTrack.B_TargetTrack_C.CalculatePlayRate // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetFinalDestinationOfTarget(struct FVector Destination); // Function B_TargetTrack.B_TargetTrack_C.GetFinalDestinationOfTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TargetMovement__FinishedFunc(); // Function B_TargetTrack.B_TargetTrack_C.TargetMovement__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void TargetMovement__UpdateFunc(); // Function B_TargetTrack.B_TargetTrack_C.TargetMovement__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_27B7684A423E01CDEC2BFC9631F88BF8(struct UObject* Loaded); // Function B_TargetTrack.B_TargetTrack_C.OnLoaded_27B7684A423E01CDEC2BFC9631F88BF8 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_3C01053C48BCC07B689033B6DB9706E0(struct UObject* Loaded); // Function B_TargetTrack.B_TargetTrack_C.OnLoaded_3C01053C48BCC07B689033B6DB9706E0 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_TargetTrack.B_TargetTrack_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void MoveTarget(); // Function B_TargetTrack.B_TargetTrack_C.MoveTarget // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_1_AnyPropertyChangedDelegate__DelegateSignature(); // Function B_TargetTrack.B_TargetTrack_C.BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_1_AnyPropertyChangedDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_2_AnyPropertyChangedDelegate__DelegateSignature(); // Function B_TargetTrack.B_TargetTrack_C.BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_2_AnyPropertyChangedDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void AttachedTargetKnockedDown(); // Function B_TargetTrack.B_TargetTrack_C.AttachedTargetKnockedDown // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StopTargetMovement(); // Function B_TargetTrack.B_TargetTrack_C.StopTargetMovement // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AttachedTargetPoppedUp(); // Function B_TargetTrack.B_TargetTrack_C.AttachedTargetPoppedUp // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReverseTargetMovement(); // Function B_TargetTrack.B_TargetTrack_C.ReverseTargetMovement // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AsyncLoadTargetBase(); // Function B_TargetTrack.B_TargetTrack_C.AsyncLoadTargetBase // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Sphere_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function B_TargetTrack.B_TargetTrack_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void InitializeSettings(); // Function B_TargetTrack.B_TargetTrack_C.InitializeSettings // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function B_TargetTrack.B_TargetTrack_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Move Target Audio(); // Function B_TargetTrack.B_TargetTrack_C.Move Target Audio // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Stop Move Target Audio(); // Function B_TargetTrack.B_TargetTrack_C.Stop Move Target Audio // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function B_TargetTrack.B_TargetTrack_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_TargetTrack(int32_t EntryPoint); // Function B_TargetTrack.B_TargetTrack_C.ExecuteUbergraph_B_TargetTrack // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

