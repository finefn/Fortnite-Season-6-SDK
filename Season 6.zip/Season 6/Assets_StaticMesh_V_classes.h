// SolarisGeneratedClass Assets_StaticMesh_V.StaticMesh_V
// Size: 0x80 (Inherited: 0x80)
struct UStaticMesh_V : UAsset {

	struct UStaticMesh_V* createAndLoad(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_StaticMesh_V.StaticMesh_V.createAndLoad // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	struct UStaticMesh_V* Create(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_StaticMesh_V.StaticMesh_V.Create // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	void $InitInstance(); // Function Assets_StaticMesh_V.StaticMesh_V.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Assets_StaticMesh_V.StaticMesh_V.$InitCDO // () // @ game+0xbd830c
};

