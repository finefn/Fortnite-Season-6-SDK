// AnimBlueprintGeneratedClass DBNO_Carried.DBNO_Carried_C
// Size: 0x27d1 (Inherited: 0x1bf0)
struct UDBNO_Carried_C : UFortPlayerAnimInstance_DBNOCarried {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1bf0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x1bf8(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x1c28(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x1c48(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x1d50(0x108)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x1e58(0x80)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive; // 0x1ed8(0xc8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK; // 0x1fa0(0x1e0)
	struct FAnimNode_LinkedAnimGraph AnimGraphNode_SubInstance; // 0x2180(0xa0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x2220(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x2240(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x2268(0x28)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2; // 0x2290(0x50)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x22e0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x2310(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x2390(0x30)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator; // 0x23c0(0x50)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x2410(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x2440(0xb0)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend; // 0x24f0(0xc8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x25b8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x2710(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x2738(0x28)
	enum class EFortPlayerAnimBodyType __CustomProperty_my_animbodytype_BC9172D64300E6A13C48509FE2988A40; // 0x2760(0x01)
	enum class EFortCustomGender __CustomProperty_my_gender_BC9172D64300E6A13C48509FE2988A40; // 0x2761(0x01)
	bool Carried; // 0x2762(0x01)
	char UnknownData_2763[0x5]; // 0x2763(0x05)
	struct APlayerPawn_Athena_C* CarrierPawn; // 0x2768(0x08)
	struct UFortPlayerAnimInstance* CarrierAnimBP; // 0x2770(0x08)
	struct FVector LHandIKLocation; // 0x2778(0x0c)
	struct FRotator LHandIKRotation; // 0x2784(0x0c)
	struct FVector TempAttachLocation; // 0x2790(0x0c)
	struct FRotator TempAttachRotation; // 0x279c(0x0c)
	float SubAnimPhysicsWeight; // 0x27a8(0x04)
	bool IsBeingDropped; // 0x27ac(0x01)
	char UnknownData_27AD[0x3]; // 0x27ad(0x03)
	float DropMontagePosition; // 0x27b0(0x04)
	char UnknownData_27B4[0x4]; // 0x27b4(0x04)
	struct UAnimMontage* CarrierDropMontage; // 0x27b8(0x08)
	struct UAnimMontage* CarrierPickupMontage; // 0x27c0(0x08)
	bool IsBeingPickedUp; // 0x27c8(0x01)
	char UnknownData_27C9[0x3]; // 0x27c9(0x03)
	float PickupMontagePosition; // 0x27cc(0x04)
	bool TransitionFromPickupToIdle; // 0x27d0(0x01)

	void AnimGraph(struct FPoseLink AnimGraph); // Function DBNO_Carried.DBNO_Carried_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_DBNO_Carried_AnimGraphNode_ApplyAdditive_56B19EE040BEEBC25D674F8DC99831B9(); // Function DBNO_Carried.DBNO_Carried_C.EvaluateGraphExposedInputs_ExecuteUbergraph_DBNO_Carried_AnimGraphNode_ApplyAdditive_56B19EE040BEEBC25D674F8DC99831B9 // (BlueprintEvent) // @ game+0xbd830c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_DBNO_Carried_AnimGraphNode_ModifyBone_59E069244645BEF22808AB9196186F3F(); // Function DBNO_Carried.DBNO_Carried_C.EvaluateGraphExposedInputs_ExecuteUbergraph_DBNO_Carried_AnimGraphNode_ModifyBone_59E069244645BEF22808AB9196186F3F // (BlueprintEvent) // @ game+0xbd830c
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function DBNO_Carried.DBNO_Carried_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BlueprintInitializeAnimation(); // Function DBNO_Carried.DBNO_Carried_C.BlueprintInitializeAnimation // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_DBNO_Carried(int32_t EntryPoint); // Function DBNO_Carried.DBNO_Carried_C.ExecuteUbergraph_DBNO_Carried // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

