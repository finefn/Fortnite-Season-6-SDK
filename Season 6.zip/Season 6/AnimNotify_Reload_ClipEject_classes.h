// BlueprintGeneratedClass AnimNotify_Reload_ClipEject.AnimNotify_Reload_ClipEject_C
// Size: 0x40 (Inherited: 0x38)
struct UAnimNotify_Reload_ClipEject_C : UAnimNotify {
	struct UParticleSystem* Shell_Eject_Particle; // 0x38(0x08)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_Reload_ClipEject.AnimNotify_Reload_ClipEject_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
};

