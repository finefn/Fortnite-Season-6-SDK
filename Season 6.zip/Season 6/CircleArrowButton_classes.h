// WidgetBlueprintGeneratedClass CircleArrowButton.CircleArrowButton_C
// Size: 0xc62 (Inherited: 0xbf0)
struct UCircleArrowButton_C : UCommonButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbf0(0x08)
	struct UWidgetAnimation* Click; // 0xbf8(0x08)
	struct UWidgetAnimation* Hover; // 0xc00(0x08)
	struct UImage* Image_Arrow; // 0xc08(0x08)
	struct UImage* Image_Shadow; // 0xc10(0x08)
	struct UOverlay* Overlay_ButtonContainer; // 0xc18(0x08)
	struct USizeBox* Sizebox_InputAction; // 0xc20(0x08)
	bool Flip; // 0xc28(0x01)
	char UnknownData_C29[0x3]; // 0xc29(0x03)
	struct FLinearColor ArrowColor; // 0xc2c(0x10)
	struct FLinearColor ShadowColor; // 0xc3c(0x10)
	float EdgeSoftness; // 0xc4c(0x04)
	struct FLinearColor HoverColor; // 0xc50(0x10)
	bool UseShadow; // 0xc60(0x01)
	bool InputActionOnSide; // 0xc61(0x01)

	void UpdateArrowColor(struct FLinearColor Color, struct FLinearColor HoverColor); // Function CircleArrowButton.CircleArrowButton_C.UpdateArrowColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function CircleArrowButton.CircleArrowButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function CircleArrowButton.CircleArrowButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function CircleArrowButton.CircleArrowButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnClicked(); // Function CircleArrowButton.CircleArrowButton_C.BP_OnClicked // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CircleArrowButton(int32_t EntryPoint); // Function CircleArrowButton.CircleArrowButton_C.ExecuteUbergraph_CircleArrowButton // (Final|UbergraphFunction) // @ game+0xbd830c
};

