// WidgetBlueprintGeneratedClass AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C
// Size: 0x7b8 (Inherited: 0x528)
struct UAthenaLobbyPlayerPanel_C : UAthenaLobbyPlayerPanel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x528(0x08)
	struct UHorizontalBox* BattlePassRow; // 0x530(0x08)
	struct UBorder* Border_1; // 0x538(0x08)
	struct UImage* SeasonPassIcon; // 0x540(0x08)
	struct FFortTeamMemberInfo TeamMemberInfo; // 0x548(0x200)
	struct FMulticastInlineDelegate OnGadgetsClicked; // 0x748(0x10)
	struct FText AddFriendText; // 0x758(0x18)
	struct FText AcceptInviteText; // 0x770(0x18)
	struct FText SentInviteText; // 0x788(0x18)
	struct FText AcceptedInviteText; // 0x7a0(0x18)

	struct FEventReply OnMouseButtonDown_1(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnMouseButtonDown_1 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnHasBattlePassUpdated(bool bHasBattlePass); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnHasBattlePassUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnFriendStatusUpdated(enum class EFortFriendRequestStatus FriendRequestStatus); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnFriendStatusUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnIsMutedUpdated(bool bIsMuted); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnIsMutedUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaLobbyPlayerPanel(int32_t EntryPoint); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.ExecuteUbergraph_AthenaLobbyPlayerPanel // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void OnGadgetsClicked__DelegateSignature(); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnGadgetsClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

