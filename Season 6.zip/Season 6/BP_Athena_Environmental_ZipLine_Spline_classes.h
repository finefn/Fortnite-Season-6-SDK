// BlueprintGeneratedClass BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C
// Size: 0xa54 (Inherited: 0x9a0)
struct ABP_Athena_Environmental_ZipLine_Spline_C : AFortAthenaSplineZipline {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9a0(0x08)
	struct UStaticMesh* SplineStaticMesh; // 0x9a8(0x08)
	float TangentSmoothStrength; // 0x9b0(0x04)
	bool AutoSmoothTangents; // 0x9b4(0x01)
	enum class ESplineMeshAxis ForwardMeshAxis; // 0x9b5(0x01)
	char UnknownData_9B6[0x2]; // 0x9b6(0x02)
	struct FVector MotorOffset; // 0x9b8(0x0c)
	char UnknownData_9C4[0x4]; // 0x9c4(0x04)
	struct AActor* PoleA; // 0x9c8(0x08)
	struct AActor* PoleB; // 0x9d0(0x08)
	struct FVector PoleASocketLocation; // 0x9d8(0x0c)
	struct FVector PoleBSocketLocation; // 0x9e4(0x0c)
	int32_t LowerPointID; // 0x9f0(0x04)
	int32_t HigherPointID; // 0x9f4(0x04)
	struct FVector HigherEndLocation; // 0x9f8(0x0c)
	struct FVector LowerEndLocation; // 0xa04(0x0c)
	float AutoLinearFactorLow; // 0xa10(0x04)
	float AutoLinearFactorHigh; // 0xa14(0x04)
	float AutoSplineTangentLengthCoef; // 0xa18(0x04)
	float AutoSplineTangentHorizCoef; // 0xa1c(0x04)
	float AutoSplineTangentVertCoef; // 0xa20(0x04)
	bool Auto Set Spline Ends; // 0xa24(0x01)
	bool Auto Set Spline Mids; // 0xa25(0x01)
	char UnknownData_A26[0x2]; // 0xa26(0x02)
	struct TArray<struct UMaterialInstanceDynamic*> SplineMaterials; // 0xa28(0x10)
	struct TArray<int32_t> MyArray; // 0xa38(0x10)
	int32_t SomeReasonableSizeLimitForMyArray; // 0xa48(0x04)
	int32_t ArrayElement; // 0xa4c(0x04)
	int32_t MyReplicatedVar; // 0xa50(0x04)

	void OnRep_MyReplicatedVar(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.OnRep_MyReplicatedVar // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void NewFunction_1(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.NewFunction_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetAutoHorizAndVertVectors(struct FVector highVector, struct FVector LowVector, struct FVector VertVec, struct FVector HorizVec); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.GetAutoHorizAndVertVectors // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Calc Auto Location At Alpha(float InAlpha, bool DrawDebug, struct FVector PointLocation); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.Calc Auto Location At Alpha // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetSplinePositionAndTangent(bool SetPosition, bool SetTangent, int32_t ID); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.SetSplinePositionAndTangent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CalculatePositionOfPoles(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.CalculatePositionOfPoles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AutoSmoothTanget(struct FVector Tangent, struct FVector PointA, struct FVector PointB, struct FVector SmoothedTangent); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.AutoSmoothTanget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void AddSplineMeshSegment(struct USplineMeshComponent* SplineMeshSegment); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.AddSplineMeshSegment // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void PlayerAttachedToZipline(struct AFortPlayerPawn* PlayerPawn); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.PlayerAttachedToZipline // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayerDetachedFromZipline(struct AFortPlayerPawn* PlayerPawn); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.PlayerDetachedFromZipline // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Replicated Custom Event(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.Replicated Custom Event // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_Athena_Environmental_ZipLine_Spline(int32_t EntryPoint); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.ExecuteUbergraph_BP_Athena_Environmental_ZipLine_Spline // (Final|UbergraphFunction) // @ game+0xbd830c
};

