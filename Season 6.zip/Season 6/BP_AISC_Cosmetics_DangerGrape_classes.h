// BlueprintGeneratedClass BP_AISC_Cosmetics_DangerGrape.BP_AISC_Cosmetics_DangerGrape_C
// Size: 0x240 (Inherited: 0x140)
struct UBP_AISC_Cosmetics_DangerGrape_C : UFortAthenaAISpawnerDataComponent_CosmeticLoadout {
	struct FFortAthenaLoadout PlayerPawnLoadout; // 0x140(0xf0)
	struct TArray<struct UCustomCharacterPart*> PlayerCustomCharacterParts; // 0x230(0x10)

	void GetCustomCharacterParts(struct TArray<struct UCustomCharacterPart*> OutCustomCharacterParts); // Function BP_AISC_Cosmetics_DangerGrape.BP_AISC_Cosmetics_DangerGrape_C.GetCustomCharacterParts // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetLoadout(struct FFortAthenaLoadout OutLoadout); // Function BP_AISC_Cosmetics_DangerGrape.BP_AISC_Cosmetics_DangerGrape_C.GetLoadout // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

