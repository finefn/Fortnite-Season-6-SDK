// BlueprintGeneratedClass Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C
// Size: 0x830 (Inherited: 0x7f9)
struct AAthena_Fake_CoolCarpet_C : AAthena_Fake_SneakySnowmanV2_C {
	char UnknownData_7F9[0x7]; // 0x7f9(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x800(0x08)
	struct UStaticMeshComponent* SM_ShadowInsert; // 0x808(0x08)
	struct UStaticMeshComponent* SM_CoolCarpet_Flap2; // 0x810(0x08)
	struct UStaticMeshComponent* SM_CoolCarpet_Flap1; // 0x818(0x08)
	float Flaps_Rotation_F5AB76D74BCF44B635766F92F043E4C1; // 0x820(0x04)
	enum class ETimelineDirection Flaps__Direction_F5AB76D74BCF44B635766F92F043E4C1; // 0x824(0x01)
	char UnknownData_825[0x3]; // 0x825(0x03)
	struct UTimelineComponent* Flaps; // 0x828(0x08)

	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Flaps__FinishedFunc(); // Function Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C.Flaps__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Flaps__UpdateFunc(); // Function Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C.Flaps__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OpenFlaps(); // Function Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C.OpenFlaps // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CloseFlaps(); // Function Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C.CloseFlaps // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnDamaged_(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C.OnDamaged_ // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Fake_CoolCarpet(int32_t EntryPoint); // Function Athena_Fake_CoolCarpet.Athena_Fake_CoolCarpet_C.ExecuteUbergraph_Athena_Fake_CoolCarpet // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

