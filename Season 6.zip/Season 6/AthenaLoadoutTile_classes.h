// WidgetBlueprintGeneratedClass AthenaLoadoutTile.AthenaLoadoutTile_C
// Size: 0xc10 (Inherited: 0xc08)
struct UAthenaLoadoutTile_C : UFortCosmeticLoadoutListEntry {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc08(0x08)

	void BP_OnHovered(); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnItemSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnEntryReleased(); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnEntryReleased // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaLoadoutTile(int32_t EntryPoint); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.ExecuteUbergraph_AthenaLoadoutTile // (Final|UbergraphFunction) // @ game+0xbd830c
};

