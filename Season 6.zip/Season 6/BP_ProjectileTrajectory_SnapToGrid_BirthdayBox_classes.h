// BlueprintGeneratedClass BP_ProjectileTrajectory_SnapToGrid_BirthdayBox.BP_ProjectileTrajectory_SnapToGrid_BirthdayBox_C
// Size: 0x430 (Inherited: 0x360)
struct ABP_ProjectileTrajectory_SnapToGrid_BirthdayBox_C : ABP_ProjectileTrajectory_Athena_SnapToGridArrow_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x360(0x08)
	struct UAudioComponent* Looping_Sound; // 0x368(0x08)
	struct TMap<enum class ECardinalDirection, float> OrientationYawOffsets; // 0x370(0x50)
	struct TMap<enum class ECardinalDirection, struct FVector> OrientationLocationOffsets; // 0x3c0(0x50)
	struct TArray<struct FVector> BGALocations_Traced; // 0x410(0x10)
	struct TArray<struct FRotator> BGARotations_Traced; // 0x420(0x10)

	void ReceiveBeginPlay(); // Function BP_ProjectileTrajectory_SnapToGrid_BirthdayBox.BP_ProjectileTrajectory_SnapToGrid_BirthdayBox_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void HandleGridSnapUpdates(struct FVector NewLocation); // Function BP_ProjectileTrajectory_SnapToGrid_BirthdayBox.BP_ProjectileTrajectory_SnapToGrid_BirthdayBox_C.HandleGridSnapUpdates // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function BP_ProjectileTrajectory_SnapToGrid_BirthdayBox.BP_ProjectileTrajectory_SnapToGrid_BirthdayBox_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_ProjectileTrajectory_SnapToGrid_BirthdayBox(int32_t EntryPoint); // Function BP_ProjectileTrajectory_SnapToGrid_BirthdayBox.BP_ProjectileTrajectory_SnapToGrid_BirthdayBox_C.ExecuteUbergraph_BP_ProjectileTrajectory_SnapToGrid_BirthdayBox // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

