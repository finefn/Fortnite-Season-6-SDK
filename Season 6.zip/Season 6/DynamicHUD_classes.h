// Class DynamicHUD.DynamicHUDDirectorBase
// Size: 0x230 (Inherited: 0x220)
struct ADynamicHUDDirectorBase : AActor {
	struct TArray<struct UDynamicHUDScene*> DefaultScenes; // 0x220(0x10)
};

// Class DynamicHUD.DynamicHUDConstraintBase
// Size: 0x58 (Inherited: 0x28)
struct UDynamicHUDConstraintBase : UObject {
	char UnknownData_28[0x30]; // 0x28(0x30)
};

// Class DynamicHUD.DynamicHUDConstraintPosition
// Size: 0x68 (Inherited: 0x58)
struct UDynamicHUDConstraintPosition : UDynamicHUDConstraintBase {
	struct FVector2D Position; // 0x58(0x08)
	enum class EDynamicHUDAnchor Anchor; // 0x60(0x04)
	char UnknownData_64[0x4]; // 0x64(0x04)
};

// Class DynamicHUD.DynamicHUDConstraintAlignment
// Size: 0x60 (Inherited: 0x58)
struct UDynamicHUDConstraintAlignment : UDynamicHUDConstraintBase {
	enum class EHorizontalAlignment HorizontalAlignment; // 0x58(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x59(0x01)
	char UnknownData_5A[0x2]; // 0x5a(0x02)
	enum class EDynamicHUDAnchor Anchor; // 0x5c(0x04)
};

// Class DynamicHUD.DynamicHUDConstraintWidget
// Size: 0x98 (Inherited: 0x58)
struct UDynamicHUDConstraintWidget : UDynamicHUDConstraintBase {
	enum class EDynamicHUDAnchor Anchor; // 0x58(0x04)
	char UnknownData_5C[0x4]; // 0x5c(0x04)
	SoftClassProperty TargetWidget; // 0x60(0x28)
	struct FName TargetUniqueID; // 0x88(0x08)
	enum class EDynamicHUDAnchor TargetAnchor; // 0x90(0x04)
	enum class EDynamicHUDStrength Strength; // 0x94(0x04)
};

// Class DynamicHUD.DynamicHUDConstraintComparison
// Size: 0xa8 (Inherited: 0x58)
struct UDynamicHUDConstraintComparison : UDynamicHUDConstraintBase {
	enum class EDynamicHUDSide Side; // 0x58(0x04)
	float Offset; // 0x5c(0x04)
	enum class EDynamicHUDComparison Comparison; // 0x60(0x04)
	char UnknownData_64[0x4]; // 0x64(0x04)
	SoftClassProperty TargetWidget; // 0x68(0x28)
	struct FName TargetUniqueID; // 0x90(0x08)
	enum class EDynamicHUDSide TargetSide; // 0x98(0x04)
	float TargetOffset; // 0x9c(0x04)
	enum class EDynamicHUDStrength Strength; // 0xa0(0x04)
	char UnknownData_A4[0x4]; // 0xa4(0x04)
};

// Class DynamicHUD.DynamicHUDConstraintEquation
// Size: 0xa0 (Inherited: 0x58)
struct UDynamicHUDConstraintEquation : UDynamicHUDConstraintBase {
	enum class EDynamicHUDSide Side; // 0x58(0x04)
	enum class EDynamicHUDOperator Operator; // 0x5c(0x04)
	SoftClassProperty TargetWidget; // 0x60(0x28)
	struct FName TargetUniqueID; // 0x88(0x08)
	enum class EDynamicHUDSide TargetSide; // 0x90(0x04)
	enum class EDynamicHUDComparison Comparison; // 0x94(0x04)
	float Result; // 0x98(0x04)
	enum class EDynamicHUDStrength Strength; // 0x9c(0x04)
};

// Class DynamicHUD.DynamicHUDManager
// Size: 0xf0 (Inherited: 0x30)
struct UDynamicHUDManager : UWorldSubsystem {
	char UnknownData_30[0x20]; // 0x30(0x20)
	struct TMap<struct UDynamicHUDScene*, enum class None> ActiveScenes; // 0x50(0x50)
	struct TMap<struct FString, struct FDirectorData> ActiveDirectors; // 0xa0(0x50)

	void RemoveScenes(struct TArray<struct UDynamicHUDScene*> Scenes); // Function DynamicHUD.DynamicHUDManager.RemoveScenes // (Final|Native|Protected|BlueprintCallable) // @ game+0x627133c
	void RemoveScene(struct UDynamicHUDScene* Scene); // Function DynamicHUD.DynamicHUDManager.RemoveScene // (Final|Native|Protected|BlueprintCallable) // @ game+0x6271154
	void AddScenes(struct TArray<struct UDynamicHUDScene*> Scenes); // Function DynamicHUD.DynamicHUDManager.AddScenes // (Final|Native|Protected|BlueprintCallable) // @ game+0x6271024
	void AddScene(struct UDynamicHUDScene* Scene); // Function DynamicHUD.DynamicHUDManager.AddScene // (Final|Native|Protected|BlueprintCallable) // @ game+0x6270e6c
};

// Class DynamicHUD.DynamicHUDScene
// Size: 0x50 (Inherited: 0x30)
struct UDynamicHUDScene : UDataAsset {
	struct TArray<struct FDynamicHUDAllowed> Allowed; // 0x30(0x10)
	struct TArray<struct FDynamicHUDUnallowed> Unallowed; // 0x40(0x10)
};

// Class DynamicHUD.DynamicHUDVisualizerWidget
// Size: 0x288 (Inherited: 0x260)
struct UDynamicHUDVisualizerWidget : UUserWidget {
	struct TArray<struct UDynamicHUDScene*> Scenes; // 0x260(0x10)
	bool bRefresh; // 0x270(0x01)
	char UnknownData_271[0x17]; // 0x271(0x17)
};

