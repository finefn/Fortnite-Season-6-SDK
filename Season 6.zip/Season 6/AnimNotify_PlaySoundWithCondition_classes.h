// BlueprintGeneratedClass AnimNotify_PlaySoundWithCondition.AnimNotify_PlaySoundWithCondition_C
// Size: 0x58 (Inherited: 0x58)
struct UAnimNotify_PlaySoundWithCondition_C : UFortAnimNotify_PlaySoundConditional {

	bool ShouldTriggerAnimNotify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_PlaySoundWithCondition.AnimNotify_PlaySoundWithCondition_C.ShouldTriggerAnimNotify // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
};

