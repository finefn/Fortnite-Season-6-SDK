// BlueprintGeneratedClass B_ActorSpawner_Parent.B_ActorSpawner_Parent_C
// Size: 0x2c4 (Inherited: 0x220)
struct AB_ActorSpawner_Parent_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UStaticMeshComponent* PreVisMesh; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	struct AActor* ClassToSpawn; // 0x238(0x08)
	struct FScalableFloat Row_Enabled; // 0x240(0x28)
	float SpawnDelayMin; // 0x268(0x04)
	float SpawnDelayMax; // 0x26c(0x04)
	bool DestroyAfterSpawn; // 0x270(0x01)
	char UnknownData_271[0x3]; // 0x271(0x03)
	float DestroySelfLifeMin; // 0x274(0x04)
	float DestroySelfLifeMax; // 0x278(0x04)
	bool DestroyOnFailSpawnChance; // 0x27c(0x01)
	char UnknownData_27D[0x3]; // 0x27d(0x03)
	struct FVector SpawnLocationOffset; // 0x280(0x0c)
	bool UsePrevisMeshScale; // 0x28c(0x01)
	char UnknownData_28D[0x3]; // 0x28d(0x03)
	struct FScalableFloat Row_SpawnChance; // 0x290(0x28)
	struct FVector SpawnScale; // 0x2b8(0x0c)

	void OnReady_3020151C426C42F77FE60292E2524DFC(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function B_ActorSpawner_Parent.B_ActorSpawner_Parent_C.OnReady_3020151C426C42F77FE60292E2524DFC // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnActor(); // Function B_ActorSpawner_Parent.B_ActorSpawner_Parent_C.SpawnActor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_ActorSpawner_Parent.B_ActorSpawner_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ServerActorSpawned(struct AActor* Actor); // Function B_ActorSpawner_Parent.B_ActorSpawner_Parent_C.ServerActorSpawned // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_ActorSpawner_Parent(int32_t EntryPoint); // Function B_ActorSpawner_Parent.B_ActorSpawner_Parent_C.ExecuteUbergraph_B_ActorSpawner_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

