// SolarisGeneratedClass Diagnostics_Diagnostics.Diagnostics
// Size: 0x28 (Inherited: 0x28)
struct UDiagnostics : UObject {

	void logToScreen(enum class DiagnosticsLogLevel __verse_0x5B36F6B3_vLogLevel, struct FString __verse_0x5A4551A8_channel, struct FString __verse_0xD212B012_message, struct UColor* __verse_0x6E3776DD_color, float __verse_0x2EF20D38_duration); // Function Diagnostics_Diagnostics.Diagnostics.logToScreen // (Native|Static|Public|BlueprintCallable) // @ game+0x3ed6fc4
	void logMsg(struct FString __verse_0xD212B012_message); // Function Diagnostics_Diagnostics.Diagnostics.logMsg // (Static|Public|BlueprintCallable) // @ game+0xbd830c
	void logCallstackToScreen(struct UColor* __verse_0x6E3776DD_color, float __verse_0x2EF20D38_duration); // Function Diagnostics_Diagnostics.Diagnostics.logCallstackToScreen // (Native|Static|Public|BlueprintCallable) // @ game+0x3ed6fbc
	void logCallstack(); // Function Diagnostics_Diagnostics.Diagnostics.logCallstack // (Native|Static|Public|BlueprintCallable) // @ game+0x1c50790
	void Log(enum class DiagnosticsLogLevel __verse_0x5B36F6B3_vLogLevel, struct FString __verse_0x5A4551A8_channel, struct FString __verse_0xD212B012_message); // Function Diagnostics_Diagnostics.Diagnostics.Log // (Native|Static|Public|BlueprintCallable) // @ game+0x3ed6fcc
	void $InitInstance(); // Function Diagnostics_Diagnostics.Diagnostics.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Diagnostics_Diagnostics.Diagnostics.$InitCDO // () // @ game+0xbd830c
};

