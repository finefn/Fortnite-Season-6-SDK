// WidgetBlueprintGeneratedClass CreativeServerFriend.CreativeServerFriend_C
// Size: 0x290 (Inherited: 0x288)
struct UCreativeServerFriend_C : UCommonUserWidget {
	struct UCommonTextBlock* Text_FriendName; // 0x288(0x08)

	void InitData(struct FString FriendName); // Function CreativeServerFriend.CreativeServerFriend_C.InitData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

