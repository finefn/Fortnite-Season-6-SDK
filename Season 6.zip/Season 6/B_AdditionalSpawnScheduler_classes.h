// BlueprintGeneratedClass B_AdditionalSpawnScheduler.B_AdditionalSpawnScheduler_C
// Size: 0x110 (Inherited: 0x28)
struct UB_AdditionalSpawnScheduler_C : UObject {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x28(0x08)
	struct FMulticastInlineDelegate NotifySpawn; // 0x30(0x10)
	struct FFArrowAdditionalSpawnProperties SpawnProperties; // 0x40(0xc0)
	int32_t CurrentNumSpawns; // 0x100(0x04)
	char UnknownData_104[0x4]; // 0x104(0x04)
	struct FTimerHandle CachedTimerHandle; // 0x108(0x08)

	void StartSchedule(); // Function B_AdditionalSpawnScheduler.B_AdditionalSpawnScheduler_C.StartSchedule // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StartSpawning(); // Function B_AdditionalSpawnScheduler.B_AdditionalSpawnScheduler_C.StartSpawning // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DelayedSpawn(); // Function B_AdditionalSpawnScheduler.B_AdditionalSpawnScheduler_C.DelayedSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_AdditionalSpawnScheduler(int32_t EntryPoint); // Function B_AdditionalSpawnScheduler.B_AdditionalSpawnScheduler_C.ExecuteUbergraph_B_AdditionalSpawnScheduler // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void NotifySpawn__DelegateSignature(struct FFArrowAdditionalSpawnProperties SpawnProperties, bool bOverrideNumToSpawn, int32_t NumToSpawnOverride); // Function B_AdditionalSpawnScheduler.B_AdditionalSpawnScheduler_C.NotifySpawn__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

