// WidgetBlueprintGeneratedClass ControllerActionsMenu.ControllerActionsMenu_C
// Size: 0x488 (Inherited: 0x480)
struct UControllerActionsMenu_C : UFortControllerActionsMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)

	void BP_OnActivated(); // Function ControllerActionsMenu.ControllerActionsMenu_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_ControllerActionsMenu(int32_t EntryPoint); // Function ControllerActionsMenu.ControllerActionsMenu_C.ExecuteUbergraph_ControllerActionsMenu // (Final|UbergraphFunction) // @ game+0xbd830c
};

