// BlueprintGeneratedClass B_Prj_Athena_PurpleMouse.B_Prj_Athena_PurpleMouse_C
// Size: 0x90a (Inherited: 0x8f8)
struct AB_Prj_Athena_PurpleMouse_C : AB_Prj_Athena_BGASpawner_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8f8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x900(0x08)
	enum class None Team; // 0x908(0x01)
	bool TeamHasBeenSet; // 0x909(0x01)

	struct AActor* SpawnBGA_(struct FVector Normal, struct AActor* HitActor, struct UPrimitiveComponent* HitComp, struct FVector Pos, bool FromWater); // Function B_Prj_Athena_PurpleMouse.B_Prj_Athena_PurpleMouse_C.SpawnBGA_ // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_PurpleMouse.B_Prj_Athena_PurpleMouse_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SetTeam(enum class None Team); // Function B_Prj_Athena_PurpleMouse.B_Prj_Athena_PurpleMouse_C.SetTeam // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_PurpleMouse(int32_t EntryPoint); // Function B_Prj_Athena_PurpleMouse.B_Prj_Athena_PurpleMouse_C.ExecuteUbergraph_B_Prj_Athena_PurpleMouse // (Final|UbergraphFunction) // @ game+0xbd830c
};

