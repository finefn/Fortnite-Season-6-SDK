// WidgetBlueprintGeneratedClass AthenaMainStatTile.AthenaMainStatTile_C
// Size: 0x2a8 (Inherited: 0x2a0)
struct UAthenaMainStatTile_C : UFortProfileStatsMainTile {
	struct UImage* Glow; // 0x2a0(0x08)

	void SetStatValue(struct FText StatValueAsText); // Function AthenaMainStatTile.AthenaMainStatTile_C.SetStatValue // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

