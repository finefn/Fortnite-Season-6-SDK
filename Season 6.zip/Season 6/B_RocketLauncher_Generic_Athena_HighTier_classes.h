// BlueprintGeneratedClass B_RocketLauncher_Generic_Athena_HighTier.B_RocketLauncher_Generic_Athena_HighTier_C
// Size: 0x1304 (Inherited: 0x12dc)
struct AB_RocketLauncher_Generic_Athena_HighTier_C : AB_Ranged_Generic_C {
	char UnknownData_12DC[0x4]; // 0x12dc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x12e0(0x08)
	struct UArrowComponent* RearMuzzleLoc; // 0x12e8(0x08)
	struct UFXSystemAsset* RearMuzzleFXSystem; // 0x12f0(0x08)
	struct FVector RearMuzzleOffsetMultiplier; // 0x12f8(0x0c)

	void UserConstructionScript(); // Function B_RocketLauncher_Generic_Athena_HighTier.B_RocketLauncher_Generic_Athena_HighTier_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Muzzle Flash FX(bool Persistent Fire); // Function B_RocketLauncher_Generic_Athena_HighTier.B_RocketLauncher_Generic_Athena_HighTier_C.Muzzle Flash FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_RocketLauncher_Generic_Athena_HighTier(int32_t EntryPoint); // Function B_RocketLauncher_Generic_Athena_HighTier.B_RocketLauncher_Generic_Athena_HighTier_C.ExecuteUbergraph_B_RocketLauncher_Generic_Athena_HighTier // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

