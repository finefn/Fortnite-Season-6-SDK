// SolarisGeneratedClass Assets_Animation_V.Animation_V
// Size: 0x80 (Inherited: 0x80)
struct UAnimation_V : UAsset {

	struct UAnimation_V* createAndLoad(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_Animation_V.Animation_V.createAndLoad // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	struct UAnimation_V* Create(struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_Animation_V.Animation_V.Create // (Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbd830c
	void $InitInstance(); // Function Assets_Animation_V.Animation_V.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Assets_Animation_V.Animation_V.$InitCDO // () // @ game+0xbd830c
};

