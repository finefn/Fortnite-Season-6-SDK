// SolarisGeneratedClass Core_ObjectArrayHelper.ObjectArrayHelper
// Size: 0x28 (Inherited: 0x28)
struct UObjectArrayHelper : UObject {

	struct TArray<struct UObject*> RemoveAt(struct TArray<struct UObject*> __verse_0xCB49F730_source, int32_t __verse_0x9229249B_indexToRemove); // Function Core_ObjectArrayHelper.ObjectArrayHelper.RemoveAt // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed706c
	struct TArray<struct UObject*> Remove(struct TArray<struct UObject*> __verse_0xCB49F730_source, struct UObject* __verse_0x1617F2B7_objectToRemove); // Function Core_ObjectArrayHelper.ObjectArrayHelper.Remove // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed707c
	struct TArray<struct UObject*> randomize(struct TArray<struct UObject*> __verse_0xCB49F730_source); // Function Core_ObjectArrayHelper.ObjectArrayHelper.randomize // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed705c
	struct TArray<struct UObject*> pushFront(struct TArray<struct UObject*> __verse_0xCB49F730_source, struct UObject* __verse_0x27AD917C_objectToPush); // Function Core_ObjectArrayHelper.ObjectArrayHelper.pushFront // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed7044
	struct TArray<struct UObject*> Pushback(struct TArray<struct UObject*> __verse_0xCB49F730_source, struct UObject* __verse_0x27AD917C_objectToPush); // Function Core_ObjectArrayHelper.ObjectArrayHelper.Pushback // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed63fc
	struct TArray<struct UObject*> popFront(struct TArray<struct UObject*> __verse_0xCB49F730_source); // Function Core_ObjectArrayHelper.ObjectArrayHelper.popFront // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed703c
	struct TArray<struct UObject*> popBack(struct TArray<struct UObject*> __verse_0xCB49F730_source); // Function Core_ObjectArrayHelper.ObjectArrayHelper.popBack // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed7034
	struct TArray<struct UObject*> Insert(struct TArray<struct UObject*> __verse_0xCB49F730_source, struct UObject* __verse_0x91788530_objectToInsert, int32_t __verse_0x22C695FC_insertionIndex); // Function Core_ObjectArrayHelper.ObjectArrayHelper.Insert // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6ec0
	struct TArray<struct UObject*> append(struct TArray<struct UObject*> __verse_0xCB49F730_source, struct UObject* __verse_0x6D138456_objectToAdd); // Function Core_ObjectArrayHelper.ObjectArrayHelper.append // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed63fc
	void $InitInstance(); // Function Core_ObjectArrayHelper.ObjectArrayHelper.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Core_ObjectArrayHelper.ObjectArrayHelper.$InitCDO // () // @ game+0xbd830c
};

