// WidgetBlueprintGeneratedClass AlterationWidgetButton.AlterationWidgetButton_C
// Size: 0xcc0 (Inherited: 0xbf8)
struct UAlterationWidgetButton_C : UFortAlterationButtonWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbf8(0x08)
	struct UWidgetAnimation* PanelLoad; // 0xc00(0x08)
	struct UWidgetAnimation* TriangelUpgrade; // 0xc08(0x08)
	struct UAlterationWidget_C* AlterationWidget; // 0xc10(0x08)
	struct UImage* Flash; // 0xc18(0x08)
	struct UImage* Shine; // 0xc20(0x08)
	struct UImage* TriangleUpgrade; // 0xc28(0x08)
	bool bIncludeName; // 0xc30(0x01)
	bool bIncludeShortDescription; // 0xc31(0x01)
	bool bIncludeDescription; // 0xc32(0x01)
	enum class EFortBrushSize IconSize; // 0xc33(0x01)
	bool bUseLargeFormatName; // 0xc34(0x01)
	bool ShouldShowRarity; // 0xc35(0x01)
	char UnknownData_C36[0x2]; // 0xc36(0x02)
	struct UMaterialInstanceDynamic* Triangles Upgrade; // 0xc38(0x08)
	struct FFortRarityItemData RarityData; // 0xc40(0x80)

	void Setup Triangles(); // Function AlterationWidgetButton.AlterationWidgetButton_C.Setup Triangles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update Colors(); // Function AlterationWidgetButton.AlterationWidgetButton_C.Update Colors // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void IntroStart(); // Function AlterationWidgetButton.AlterationWidgetButton_C.IntroStart // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void IntroReset(); // Function AlterationWidgetButton.AlterationWidgetButton_C.IntroReset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TriggerModificationAnimation(); // Function AlterationWidgetButton.AlterationWidgetButton_C.TriggerModificationAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnSetup(); // Function AlterationWidgetButton.AlterationWidgetButton_C.OnSetup // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function AlterationWidgetButton.AlterationWidgetButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AlterationWidgetButton(int32_t EntryPoint); // Function AlterationWidgetButton.AlterationWidgetButton_C.ExecuteUbergraph_AlterationWidgetButton // (Final|UbergraphFunction) // @ game+0xbd830c
};

