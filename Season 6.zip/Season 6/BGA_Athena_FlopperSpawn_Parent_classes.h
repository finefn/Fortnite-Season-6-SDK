// BlueprintGeneratedClass BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C
// Size: 0xc58 (Inherited: 0x7d8)
struct ABGA_Athena_FlopperSpawn_Parent_C : ABuildingGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7d8(0x08)
	struct UBoxComponent* OverlapVolume; // 0x7e0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x7e8(0x08)
	struct FScalableFloat Row_MaxUses; // 0x7f0(0x28)
	struct FScalableFloat Row_MinUses; // 0x818(0x28)
	int32_t Uses; // 0x840(0x04)
	float AfterHideLifeSpan; // 0x844(0x04)
	struct FName ItemsToDrop; // 0x848(0x08)
	struct FGameplayTag GC_Spawn; // 0x850(0x08)
	struct FScalableFloat Row_SpawnChanceMax; // 0x858(0x28)
	bool IsWorldSpawner; // 0x880(0x01)
	char UnknownData_881[0x7]; // 0x881(0x07)
	struct FScalableFloat Row_SpawnChanceMin; // 0x888(0x28)
	struct TMap<struct FGameplayTag, struct FName> TagToLoot_FishingSpotTier; // 0x8b0(0x50)
	bool AlreadySpawnChecked; // 0x900(0x01)
	char UnknownData_901[0x7]; // 0x901(0x07)
	struct TMap<struct FGameplayTag, struct FName> TagToLoot_DefaultTier; // 0x908(0x50)
	struct TMap<struct FGameplayTag, struct FName> TagToLoot_ToUse; // 0x958(0x50)
	struct TMap<struct FGameplayTag, struct FName> TagToLoot_HighTier_FishingRod; // 0x9a8(0x50)
	bool HasTypeTag; // 0x9f8(0x01)
	char UnknownData_9F9[0x7]; // 0x9f9(0x07)
	struct TArray<enum class EObjectTypeQuery> ObjectTypes; // 0xa00(0x10)
	struct FGameplayTagContainer LootTags; // 0xa10(0x20)
	bool MaxUses; // 0xa30(0x01)
	bool Debug; // 0xa31(0x01)
	char UnknownData_A32[0x6]; // 0xa32(0x06)
	struct FScalableFloat Row_AddedBobChanceOnOverlapMin; // 0xa38(0x28)
	struct FScalableFloat Row_AddedBobChanceOnOverlapMax; // 0xa60(0x28)
	struct AFortPickup* SpawnedItem; // 0xa88(0x08)
	struct USoundBase* Sound_HighTierPoolSpawn; // 0xa90(0x08)
	struct FGameplayTagContainer QuestTag_DefaultSpawn; // 0xa98(0x20)
	struct FGameplayTagContainer QuestTag_WorldSpawn; // 0xab8(0x20)
	struct APrj_Athena_FloppingRabbit_C* Projectile; // 0xad8(0x08)
	struct UCurveFloat* FishSizeCurve; // 0xae0(0x08)
	struct TMap<struct UFortItemDefinition*, struct FScalableFloat> FishSizeMap; // 0xae8(0x50)
	float MiniGameFishSizeThreshold; // 0xb38(0x04)
	char UnknownData_B3C[0x4]; // 0xb3c(0x04)
	struct FScalableFloat MiniGameFishSizePercentileThreshold; // 0xb40(0x28)
	bool AlwaysStartMiniGame; // 0xb68(0x01)
	char UnknownData_B69[0x3]; // 0xb69(0x03)
	struct FGameplayTag HighTierFishingRod; // 0xb6c(0x08)
	struct FName HighTierLootData; // 0xb74(0x08)
	struct FGameplayTag DefaultLootTag; // 0xb7c(0x08)
	char UnknownData_B84[0x4]; // 0xb84(0x04)
	struct FString Fish Variant String; // 0xb88(0x10)
	bool New Best Fish; // 0xb98(0x01)
	char UnknownData_B99[0x3]; // 0xb99(0x03)
	float Fish Length; // 0xb9c(0x04)
	float RespawnDelay; // 0xba0(0x04)
	char UnknownData_BA4[0x4]; // 0xba4(0x04)
	struct FScalableFloat Row_RespawnDelayMin; // 0xba8(0x28)
	struct FScalableFloat Row_RespawnDelayMax; // 0xbd0(0x28)
	float ForcedRespawnDelay; // 0xbf8(0x04)
	char UnknownData_BFC[0x4]; // 0xbfc(0x04)
	struct TMap<struct FGameplayTag, struct FScalableFloat> FishSizeMap_ItemTags; // 0xc00(0x50)
	struct UFortItemDefinition* NewVar_1; // 0xc50(0x08)

	void FindFishSize(struct TMap<struct FGameplayTag, struct FScalableFloat> FishSizeMap, struct UFortItemDefinition* ItemDef, struct FScalableFloat FishSize, bool Found); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.FindFishSize // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	bool Can Respawn(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.Can Respawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void SetRespawnDelay(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.SetRespawnDelay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetLootTier(bool IsExplosion, bool IsProFishingRod, struct FName Output_Get); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.GetLootTier // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShouldKill(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.ShouldKill // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleUseTracking(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.HandleUseTracking // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetBalanceValues(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.SetBalanceValues // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void UserConstructionScript(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnReady_5804F209455A50B3EE64E3AED087DE64(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.OnReady_5804F209455A50B3EE64E3AED087DE64 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HideAndKill(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.HideAndKill // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__OverlapVolume_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.BndEvt__OverlapVolume_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void PlaySpawnItemHightier(struct FVector Location); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.PlaySpawnItemHightier // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FishingComplete(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.FishingComplete // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SpawnItem(struct AActor* Target, bool Hooked, struct USceneComponent* HookComponent, struct FVector SpawnLoc, struct AActor* Player, float ItemSpawnDelay, bool CaughtWithFishingRod, bool CaughtWithHappyGhost, struct AActor* ItemUsedToFish, struct APrj_Athena_FloppingRabbit_C* Projectile, struct FGameplayTagContainer Required Tags); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.SpawnItem // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateCollectionsComponent(bool bCaughtFish, struct AActor* Player, struct UFortItemDefinition* ItemDefinition, struct AFortPickup* Pickup, float Length); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.UpdateCollectionsComponent // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Clear Saved Collection Data(); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.Clear Saved Collection Data // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HideAndDelayForRespawn(float TimeToDelay); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.HideAndDelayForRespawn // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_FlopperSpawn_Parent(int32_t EntryPoint); // Function BGA_Athena_FlopperSpawn_Parent.BGA_Athena_FlopperSpawn_Parent_C.ExecuteUbergraph_BGA_Athena_FlopperSpawn_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

