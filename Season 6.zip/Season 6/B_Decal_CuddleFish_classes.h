// BlueprintGeneratedClass B_Decal_CuddleFish.B_Decal_CuddleFish_C
// Size: 0x240 (Inherited: 0x228)
struct AB_Decal_CuddleFish_C : ADecalActor {
	struct TArray<struct UMaterialInterface*> MaterialOptions; // 0x228(0x10)
	struct UMaterialInstanceDynamic* DecalMID; // 0x238(0x08)

	void UserConstructionScript(); // Function B_Decal_CuddleFish.B_Decal_CuddleFish_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

