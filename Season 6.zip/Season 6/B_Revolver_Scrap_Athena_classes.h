// BlueprintGeneratedClass B_Revolver_Scrap_Athena.B_Revolver_Scrap_Athena_C
// Size: 0x12f8 (Inherited: 0x12dc)
struct AB_Revolver_Scrap_Athena_C : AB_Ranged_Generic_C {
	char UnknownData_12DC[0x4]; // 0x12dc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x12e0(0x08)
	struct UStaticMeshComponent* Reload_QuickReload; // 0x12e8(0x08)
	struct UStaticMeshComponent* Reload_Ammo; // 0x12f0(0x08)

	void ReceiveBeginPlay(); // Function B_Revolver_Scrap_Athena.B_Revolver_Scrap_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Revolver_Scrap_Athena(int32_t EntryPoint); // Function B_Revolver_Scrap_Athena.B_Revolver_Scrap_Athena_C.ExecuteUbergraph_B_Revolver_Scrap_Athena // (Final|UbergraphFunction) // @ game+0xbd830c
};

