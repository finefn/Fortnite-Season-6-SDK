// BlueprintGeneratedClass B_PlayerHealthDamage_CameraLensEffect.B_PlayerHealthDamage_CameraLensEffect_C
// Size: 0x2e8 (Inherited: 0x2e0)
struct AB_PlayerHealthDamage_CameraLensEffect_C : AEmitterCameraLensEffectBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e0(0x08)

	void PassParticle_Parameter(float NewParam, bool First_Hit); // Function B_PlayerHealthDamage_CameraLensEffect.B_PlayerHealthDamage_CameraLensEffect_C.PassParticle_Parameter // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_PlayerHealthDamage_CameraLensEffect(int32_t EntryPoint); // Function B_PlayerHealthDamage_CameraLensEffect.B_PlayerHealthDamage_CameraLensEffect_C.ExecuteUbergraph_B_PlayerHealthDamage_CameraLensEffect // (Final|UbergraphFunction) // @ game+0xbd830c
};

