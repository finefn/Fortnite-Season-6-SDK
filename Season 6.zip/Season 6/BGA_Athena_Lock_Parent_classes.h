// BlueprintGeneratedClass BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C
// Size: 0x930 (Inherited: 0x7d8)
struct ABGA_Athena_Lock_Parent_C : ABuildingGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7d8(0x08)
	struct UStaticMeshComponent* Lock; // 0x7e0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x7e8(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0x7f0(0x08)
	struct UBoxComponent* InteractionCollision; // 0x7f8(0x08)
	struct ABuildingActor* AttachedLockActor; // 0x800(0x08)
	bool CanFirstInteract; // 0x808(0x01)
	bool CanSecondInteract; // 0x809(0x01)
	bool CanInteractWhileUnlocked; // 0x80a(0x01)
	char UnknownData_80B[0x5]; // 0x80b(0x05)
	struct FText FirstInteractText; // 0x810(0x18)
	struct FText SecondInteractText; // 0x828(0x18)
	float FirstInteractTime; // 0x840(0x04)
	float SecondInteractTime; // 0x844(0x04)
	bool SetLockOnFirstInteract; // 0x848(0x01)
	bool SetLockOnSecondInteract; // 0x849(0x01)
	char UnknownData_84A[0x6]; // 0x84a(0x06)
	struct AFortPawn* LastInteractingPawn; // 0x850(0x08)
	bool CanMultipleInteract; // 0x858(0x01)
	enum class Enum_Athena_Lock LockState; // 0x859(0x01)
	bool EverInteractSetLock; // 0x85a(0x01)
	char UnknownData_85B[0x1]; // 0x85b(0x01)
	struct FGameplayTag Event_Locked; // 0x85c(0x08)
	struct FGameplayTag Event_Unlocked; // 0x864(0x08)
	bool DoLockCheckFirstInteract; // 0x86c(0x01)
	bool DoLockCheckSecondInteract; // 0x86d(0x01)
	bool ApplyEffectOnFailCheck; // 0x86e(0x01)
	char UnknownData_86F[0x1]; // 0x86f(0x01)
	struct UGameplayEffect* GE_FailedCheck; // 0x870(0x08)
	float MaxInteractAngle; // 0x878(0x04)
	char UnknownData_87C[0x4]; // 0x87c(0x04)
	struct FScalableFloat Row_RelockDelay; // 0x880(0x28)
	bool AutoRelock; // 0x8a8(0x01)
	char UnknownData_8A9[0x7]; // 0x8a9(0x07)
	struct FScalableFloat Row_SelfInteractEnabled; // 0x8b0(0x28)
	struct FScalableFloat Row_DoNotLockActor; // 0x8d8(0x28)
	struct FMulticastInlineDelegate OnUnlockedDispatcher; // 0x900(0x10)
	struct FMulticastInlineDelegate OnLockedDispatcher; // 0x910(0x10)
	bool AutoAttachToParentActors; // 0x920(0x01)
	bool AutoCloseDoorOnLock; // 0x921(0x01)
	bool AutoDoorOnUnlock; // 0x922(0x01)
	bool AutoOpenContainersOnUnlock; // 0x923(0x01)
	bool SetsAllowInteractOnUnlock; // 0x924(0x01)
	enum class Enum_MANG_Security_ID Lock ID; // 0x925(0x01)
	char UnknownData_926[0x2]; // 0x926(0x02)
	struct AActor* BlankLinkedActor; // 0x928(0x08)

	void Lock Set Interact Collision(bool On); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.Lock Set Interact Collision // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void LockCheck(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, bool CheckPassed); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.LockCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_EverInteractSetLock(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnRep_EverInteractSetLock // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_LockState(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnRep_LockState // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void OnReady_19560710434050E125B3ADA0163CD609(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnReady_19560710434050E125B3ADA0163CD609 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnSecondInteract(struct AFortPawn* InteractingPawn); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnSecondInteract // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnFirstInteract(struct AFortPawn* InteractingPawn); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnFirstInteract // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLocked(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnLocked // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnUnLocked(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnUnLocked // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_0_OnLinkedActorDestroyed__DelegateSignature(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_0_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void HideAndKill(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.HideAndKill // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ApplyFailCheckEffect(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.ApplyFailCheckEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetLock(enum class Enum_Athena_Lock LockState); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.SetLock // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TimedRelock(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.TimedRelock // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OpenContainers(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OpenContainers // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void LockCloseDoor(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.LockCloseDoor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UnlockOpenDoor(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.UnlockOpenDoor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void NotEnabled(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.NotEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ParentActorDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.ParentActorDied // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_Lock_Parent(int32_t EntryPoint); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.ExecuteUbergraph_BGA_Athena_Lock_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void OnLockedDispatcher__DelegateSignature(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnLockedDispatcher__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnUnlockedDispatcher__DelegateSignature(); // Function BGA_Athena_Lock_Parent.BGA_Athena_Lock_Parent_C.OnUnlockedDispatcher__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

