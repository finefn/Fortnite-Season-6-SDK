// BlueprintGeneratedClass DA_AshtonPack.DA_AshtonPack_C
// Size: 0xe48 (Inherited: 0xdc8)
struct ADA_AshtonPack_C : AFortCustomizableAbilityDecoTool {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xdc8(0x08)
	float PunchPicker; // 0xdd0(0x04)
	bool HasLanded; // 0xdd4(0x01)
	char UnknownData_DD5[0x3]; // 0xdd5(0x03)
	struct FGameplayTagContainer AshtonAbilityTags; // 0xdd8(0x20)
	struct FGameplayTagContainer GC_JumpTrails; // 0xdf8(0x20)
	struct FGameplayTagContainer GC_SkydiveTrails; // 0xe18(0x20)
	struct FGameplayTag PrimaryFireEventTag; // 0xe38(0x08)
	struct FGameplayTag SecondaryFireEventTag; // 0xe40(0x08)

	void BPPressTrigger(struct AFortDecoHelper* FortDecoHelper); // Function DA_AshtonPack.DA_AshtonPack_C.BPPressTrigger // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BPPressSecondaryFire(struct AFortDecoHelper* FortDecoHelper); // Function DA_AshtonPack.DA_AshtonPack_C.BPPressSecondaryFire // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function DA_AshtonPack.DA_AshtonPack_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Landed(struct FHitResult Hit); // Function DA_AshtonPack.DA_AshtonPack_C.Landed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_DA_AshtonPack(int32_t EntryPoint); // Function DA_AshtonPack.DA_AshtonPack_C.ExecuteUbergraph_DA_AshtonPack // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

