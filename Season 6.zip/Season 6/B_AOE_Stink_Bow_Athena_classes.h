// BlueprintGeneratedClass B_AOE_Stink_Bow_Athena.B_AOE_Stink_Bow_Athena_C
// Size: 0x61c (Inherited: 0x5a0)
struct AB_AOE_Stink_Bow_Athena_C : AFortAreaOfEffectCloud {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5a0(0x08)
	struct UNiagaraComponent* NS_Bow_Stink_Bomb_AoE; // 0x5a8(0x08)
	struct UAudioComponent* LoopingAudio; // 0x5b0(0x08)
	struct UParticleSystemComponent* StinkCloudParticleSystem; // 0x5b8(0x08)
	struct USphereComponent* EffectOverlapArea; // 0x5c0(0x08)
	struct FScalableFloat Row_CloudDuration; // 0x5c8(0x28)
	struct FScalableFloat Row_DamageDelay; // 0x5f0(0x28)
	float CloudFadeOutTime; // 0x618(0x04)

	void ReceiveBeginPlay(); // Function B_AOE_Stink_Bow_Athena.B_AOE_Stink_Bow_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void KillCloud(); // Function B_AOE_Stink_Bow_Athena.B_AOE_Stink_Bow_Athena_C.KillCloud // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FadeIn(); // Function B_AOE_Stink_Bow_Athena.B_AOE_Stink_Bow_Athena_C.FadeIn // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FadeOut(); // Function B_AOE_Stink_Bow_Athena.B_AOE_Stink_Bow_Athena_C.FadeOut // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TurnOnCollision(); // Function B_AOE_Stink_Bow_Athena.B_AOE_Stink_Bow_Athena_C.TurnOnCollision // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_AOE_Stink_Bow_Athena(int32_t EntryPoint); // Function B_AOE_Stink_Bow_Athena.B_AOE_Stink_Bow_Athena_C.ExecuteUbergraph_B_AOE_Stink_Bow_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

