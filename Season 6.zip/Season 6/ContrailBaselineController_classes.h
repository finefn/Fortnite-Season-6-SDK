// BlueprintGeneratedClass ContrailBaselineController.ContrailBaselineController_C
// Size: 0xc0 (Inherited: 0x68)
struct UContrailBaselineController_C : UNiagaraBaselineController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x68(0x08)
	struct TSoftObjectPtr<struct USkeletalMesh> MeshAssetRef; // 0x70(0x28)
	struct TSoftObjectPtr<struct UAnimMontage> AnimAssetRef; // 0x98(0x28)

	bool OnTickTest(); // Function ContrailBaselineController.ContrailBaselineController_C.OnTickTest // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnOwnerTick(float DeltaTime); // Function ContrailBaselineController.ContrailBaselineController_C.OnOwnerTick // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnEndTest(struct FNiagaraPerfBaselineStats Stats); // Function ContrailBaselineController.ContrailBaselineController_C.OnEndTest // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnBeginTest(); // Function ContrailBaselineController.ContrailBaselineController_C.OnBeginTest // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_ContrailBaselineController(int32_t EntryPoint); // Function ContrailBaselineController.ContrailBaselineController_C.ExecuteUbergraph_ContrailBaselineController // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

