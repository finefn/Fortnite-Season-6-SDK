// SolarisGeneratedClass Core_ComponentArrayHelper.ComponentArrayHelper
// Size: 0x28 (Inherited: 0x28)
struct UComponentArrayHelper : UObject {

	struct TArray<struct UEntityComponent*> RemoveAt(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source, int32_t __verse_0x9229249B_indexToRemove); // Function Core_ComponentArrayHelper.ComponentArrayHelper.RemoveAt // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed706c
	struct TArray<struct UEntityComponent*> Remove(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source, struct UEntityComponent* __verse_0xB66418FF_ComponentToRemove); // Function Core_ComponentArrayHelper.ComponentArrayHelper.Remove // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed707c
	struct TArray<struct UEntityComponent*> randomize(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source); // Function Core_ComponentArrayHelper.ComponentArrayHelper.randomize // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed705c
	struct TArray<struct UEntityComponent*> pushFront(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source, struct UEntityComponent* __verse_0x16497D92_ComponentToPush); // Function Core_ComponentArrayHelper.ComponentArrayHelper.pushFront // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed7044
	struct TArray<struct UEntityComponent*> Pushback(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source, struct UEntityComponent* __verse_0x16497D92_ComponentToPush); // Function Core_ComponentArrayHelper.ComponentArrayHelper.Pushback // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed63fc
	struct TArray<struct UEntityComponent*> popFront(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source); // Function Core_ComponentArrayHelper.ComponentArrayHelper.popFront // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed703c
	struct TArray<struct UEntityComponent*> popBack(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source); // Function Core_ComponentArrayHelper.ComponentArrayHelper.popBack // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed7034
	struct TArray<struct UEntityComponent*> Insert(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source, struct UEntityComponent* __verse_0x310B6F78_ComponentToInsert, int32_t __verse_0x22C695FC_insertionIndex); // Function Core_ComponentArrayHelper.ComponentArrayHelper.Insert // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed6ec0
	struct TArray<struct UEntityComponent*> append(struct TArray<struct UEntityComponent*> __verse_0xCB49F730_source, struct UEntityComponent* __verse_0x5E60FB05_ComponentToAdd); // Function Core_ComponentArrayHelper.ComponentArrayHelper.append // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed63fc
	void $InitInstance(); // Function Core_ComponentArrayHelper.ComponentArrayHelper.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Core_ComponentArrayHelper.ComponentArrayHelper.$InitCDO // () // @ game+0xbd830c
};

