// SolarisGeneratedClass Core_Event.Context__wait
// Size: 0xa0 (Inherited: 0x98)
struct UContext__wait : UCoroutineContext {
	struct UEvent* _Self; // 0x98(0x08)
};

// SolarisGeneratedClass Core_Event.Context_Event_wait
// Size: 0xa0 (Inherited: 0xa0)
struct UContext_Event_wait : UContext__wait {

	int32_t Update(); // Function Core_Event.Context_Event_wait.Update // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea02c0
};

// SolarisGeneratedClass Core_Event.Event
// Size: 0x50 (Inherited: 0x28)
struct UEvent : UObject {
	char UnknownData_28[0x28]; // 0x28(0x28)

	void signal(); // Function Core_Event.Event.signal // (Native|Public|BlueprintCallable) // @ game+0x3ea0e28
	int32_t getWaitCount(); // Function Core_Event.Event.getWaitCount // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea09b4
	void $InitInstance(); // Function Core_Event.Event.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Core_Event.Event.$InitCDO // () // @ game+0xbd830c
};

