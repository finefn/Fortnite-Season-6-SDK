// WidgetBlueprintGeneratedClass ActivatableMovieWidget_Monolithic_Native.ActivatableMovieWidget_Monolithic_Native_C
// Size: 0x690 (Inherited: 0x670)
struct UActivatableMovieWidget_Monolithic_Native_C : UFortActivatableMovieWidget_Monolithic {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x670(0x08)
	struct UWidgetAnimation* WhiteFade; // 0x678(0x08)
	struct USafeZone* MainSafeZone; // 0x680(0x08)
	struct UBorder* SafeZonePadding; // 0x688(0x08)

	void Construct(); // Function ActivatableMovieWidget_Monolithic_Native.ActivatableMovieWidget_Monolithic_Native_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void StartFadeFromWhite(); // Function ActivatableMovieWidget_Monolithic_Native.ActivatableMovieWidget_Monolithic_Native_C.StartFadeFromWhite // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_ActivatableMovieWidget_Monolithic_Native(int32_t EntryPoint); // Function ActivatableMovieWidget_Monolithic_Native.ActivatableMovieWidget_Monolithic_Native_C.ExecuteUbergraph_ActivatableMovieWidget_Monolithic_Native // (Final|UbergraphFunction) // @ game+0xbd830c
};

