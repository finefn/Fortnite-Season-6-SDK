// BlueprintGeneratedClass BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C
// Size: 0x88c (Inherited: 0x7d8)
struct ABGA_Bow_Stink_Cloud_Athena_C : ABuildingGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7d8(0x08)
	struct USphereComponent* DangerSphere; // 0x7e0(0x08)
	struct UAudioComponent* LoopingAudio; // 0x7e8(0x08)
	struct UNiagaraComponent* NS_StinkCloud; // 0x7f0(0x08)
	struct UPostProcessComponent* PostProcessComponent; // 0x7f8(0x08)
	struct USphereComponent* PostProcessParentShape; // 0x800(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x808(0x08)
	float FadeSmokeTL_Float_91201D8449245B37E55F8C8A4A5AC2E2; // 0x810(0x04)
	enum class ETimelineDirection FadeSmokeTL__Direction_91201D8449245B37E55F8C8A4A5AC2E2; // 0x814(0x01)
	char UnknownData_815[0x3]; // 0x815(0x03)
	struct UTimelineComponent* FadeSmokeTL; // 0x818(0x08)
	float StinkDuration; // 0x820(0x04)
	float LifeAfterKill; // 0x824(0x04)
	float GasFadeInTime; // 0x828(0x04)
	float GasFadeOutTime; // 0x82c(0x04)
	struct UMaterialInstanceDynamic* SmokeVolumeMeshMID; // 0x830(0x08)
	struct FScalableFloat Row_CloudDuration; // 0x838(0x28)
	struct FScalableFloat Row_InitialDelay; // 0x860(0x28)
	float Fade Out Duration; // 0x888(0x04)

	void UserConstructionScript(); // Function BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FadeSmokeTL__FinishedFunc(); // Function BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C.FadeSmokeTL__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void FadeSmokeTL__UpdateFunc(); // Function BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C.FadeSmokeTL__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void HideAndKill(); // Function BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C.HideAndKill // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void FadeIn(); // Function BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C.FadeIn // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FadeOut(); // Function BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C.FadeOut // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Bow_Stink_Cloud_Athena(int32_t EntryPoint); // Function BGA_Bow_Stink_Cloud_Athena.BGA_Bow_Stink_Cloud_Athena_C.ExecuteUbergraph_BGA_Bow_Stink_Cloud_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

