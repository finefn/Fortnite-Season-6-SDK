// BlueprintGeneratedClass BP_Creative_Billboard.BP_Creative_Billboard_C
// Size: 0xc98 (Inherited: 0xbc0)
struct ABP_Creative_Billboard_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc0(0x08)
	struct USceneComponent* WidgetAnchor; // 0xbc8(0x08)
	struct UCreative_Enabled_Component_C* Creative_Enabled_Component; // 0xbd0(0x08)
	struct UFortMinigameLogicComponent* FortMinigameLogic; // 0xbd8(0x08)
	struct UFortGameplayReceiverMessageComponent* HideTextReceiverComponent; // 0xbe0(0x08)
	struct UFortGameplayReceiverMessageComponent* ShowTextReceiverComponent; // 0xbe8(0x08)
	struct UBoxComponent* ToolPickingBox; // 0xbf0(0x08)
	struct UToyOptionsComponent_C* ToyOptionsComponent; // 0xbf8(0x08)
	struct FString UserDefinedText; // 0xc00(0x10)
	bool bShowBorder; // 0xc10(0x01)
	char UnknownData_C11[0x3]; // 0xc11(0x03)
	struct FLinearColor BackgroundColor; // 0xc14(0x10)
	enum class ETextJustify HorizontalTextAlignment; // 0xc24(0x01)
	char UnknownData_C25[0x3]; // 0xc25(0x03)
	int32_t TextSize; // 0xc28(0x04)
	float ViewDistance; // 0xc2c(0x04)
	struct FLinearColor TextColor; // 0xc30(0x10)
	int32_t EnabledIndex; // 0xc40(0x04)
	int32_t TextFont; // 0xc44(0x04)
	bool Show Debug Text; // 0xc48(0x01)
	char UnknownData_C49[0x3]; // 0xc49(0x03)
	struct FRotator BackgroundRelativeRotationWithBorder; // 0xc4c(0x0c)
	struct FRotator BackgroundRelativeRotationWithoutBorder; // 0xc58(0x0c)
	int32_t OutlineStrength; // 0xc64(0x04)
	enum class EBillboardshadowDirection DropShadow; // 0xc68(0x01)
	char UnknownData_C69[0x3]; // 0xc69(0x03)
	float Shadow Divisor; // 0xc6c(0x04)
	struct UWidgetComponent* WidgetComponent; // 0xc70(0x08)
	struct UCreative_Background_Widget_C* Widget; // 0xc78(0x08)
	float MinTextSize; // 0xc80(0x04)
	enum class EFortMinigameState Last State Updated; // 0xc84(0x01)
	char UnknownData_C85[0x3]; // 0xc85(0x03)
	struct UMaterialInterface* DefaultMaterial; // 0xc88(0x08)
	struct UMaterialInterface* ClearMaterial; // 0xc90(0x08)

	void GetCreativeActorOrigin(bool Override, struct FVector Center); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.GetCreativeActorOrigin // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetCreativeActorBounds(bool Override Bounds, struct FVector Bounds); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.GetCreativeActorBounds // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct UStaticMesh* GetCollisionStaticMesh(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.GetCollisionStaticMesh // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	struct TArray<struct UMeshComponent*> GetMeshComponents(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.GetMeshComponents // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	struct UMaterialInterface* GetOverrideMeshMaterial(struct UStaticMeshComponent* MeshComp, int32_t MatIdx); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.GetOverrideMeshMaterial // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void Update Last Game State Enable Changed(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.Update Last Game State Enable Changed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Text Visibility On Game State(enum class EFortMinigameState New State); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.Text Visibility On Game State // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Create Widget(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.Create Widget // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetShadow(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.SetShadow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetTextFont(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.SetTextFont // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetViewDistance(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.SetViewDistance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetTextColor(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.SetTextColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateProperties(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.UpdateProperties // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetDisplayText(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.SetDisplayText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetTextAlignment(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.SetTextAlignment // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetTextSize(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.SetTextSize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetBackgroundColor(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.SetBackgroundColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PostUpdateProperties(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.PostUpdateProperties // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_0_AnyPropertyChangedDelegate__DelegateSignature(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_0_AnyPropertyChangedDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_1_AnyPropertyChangedDelegate__DelegateSignature(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.BndEvt__ToyOptionsComponent_K2Node_ComponentBoundEvent_1_AnyPropertyChangedDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ShowTextReceiverComponent_K2Node_ComponentBoundEvent_2_OnGameplayMessageReceived__DelegateSignature(struct AController* TriggerInstigator); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.BndEvt__ShowTextReceiverComponent_K2Node_ComponentBoundEvent_2_OnGameplayMessageReceived__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__HideTextReceiverComponent_K2Node_ComponentBoundEvent_3_OnGameplayMessageReceived__DelegateSignature(struct AController* TriggerInstigator); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.BndEvt__HideTextReceiverComponent_K2Node_ComponentBoundEvent_3_OnGameplayMessageReceived__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortMinigameLogic_K2Node_ComponentBoundEvent_5_OnMinigameAssignmentChanged__DelegateSignature(struct AFortMinigame* Minigame); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.BndEvt__FortMinigameLogic_K2Node_ComponentBoundEvent_5_OnMinigameAssignmentChanged__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void Play Mode Changed(struct AFortMinigame* Minigame, bool bIsInPlayMode); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.Play Mode Changed // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update Static Mesh Component Visibility Options(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.Update Static Mesh Component Visibility Options // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Initialize Device(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.Initialize Device // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Creative_Enabled_Component_K2Node_ComponentBoundEvent_7_On Enabled State Changed__DelegateSignature(bool Enabled); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.BndEvt__Creative_Enabled_Component_K2Node_ComponentBoundEvent_7_On Enabled State Changed__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortMinigameLogic_K2Node_ComponentBoundEvent_4_OnMinigameStateChanged__DelegateSignature(struct AFortMinigame* Minigame, enum class EFortMinigameState NewMinigameState); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.BndEvt__FortMinigameLogic_K2Node_ComponentBoundEvent_4_OnMinigameStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void Initialize Minigame Options(struct AFortMinigame* Minigame); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.Initialize Minigame Options // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnWorldReady(); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.OnWorldReady // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_Creative_Billboard(int32_t EntryPoint); // Function BP_Creative_Billboard.BP_Creative_Billboard_C.ExecuteUbergraph_BP_Creative_Billboard // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

