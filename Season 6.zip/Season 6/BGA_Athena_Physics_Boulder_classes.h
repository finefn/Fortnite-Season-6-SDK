// BlueprintGeneratedClass BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C
// Size: 0xcf8 (Inherited: 0x80c)
struct ABGA_Athena_Physics_Boulder_C : ABGA_Athena_Physics_Parent_C {
	char UnknownData_80C[0x4]; // 0x80c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x810(0x08)
	struct UNiagaraComponent* NS_Boulder_Speedlines; // 0x818(0x08)
	struct UFortWeakPointComponent* FortWeakPoint; // 0x820(0x08)
	struct UNiagaraComponent* NS_Boulder_Wake; // 0x828(0x08)
	struct UFortActorComponent_Affiliation* FortActorComponent_Affiliation; // 0x830(0x08)
	struct UAthenaPhysicsAIPerceptionStimuliSourceComponent* AthenaPhysicsAIPerceptionStimuliSource; // 0x838(0x08)
	struct UFortPhysicsObjectNavigationComponent* FortPhysicsObjectNavigation; // 0x840(0x08)
	struct FGameplayTagContainer QuestTargetTags; // 0x848(0x20)
	float DelayBetweenDamageFX; // 0x868(0x04)
	char UnknownData_86C[0x4]; // 0x86c(0x04)
	struct USoundBase* DamageSound; // 0x870(0x08)
	struct TArray<struct AActor*> AlreadyDamagedAndSelf; // 0x878(0x10)
	bool DamageEnabled; // 0x888(0x01)
	char UnknownData_889[0x3]; // 0x889(0x03)
	struct FGameplayTag ImpactCueLarge; // 0x88c(0x08)
	struct FGameplayTag ImpactCueSmall; // 0x894(0x08)
	char UnknownData_89C[0x4]; // 0x89c(0x04)
	struct FTimerHandle EnvironmentDestructionUpdateTimer; // 0x8a0(0x08)
	struct FGameplayTag ImpactCuePlayer; // 0x8a8(0x08)
	struct FGameplayTag ImpactCueBuilds; // 0x8b0(0x08)
	struct FScalableFloat MinSpeedForLowDamage; // 0x8b8(0x28)
	struct FScalableFloat MinSpeedForHighDamage; // 0x8e0(0x28)
	int32_t DamageState; // 0x908(0x04)
	int32_t MaterialState; // 0x90c(0x04)
	struct FScalableFloat MinPlayerLaunchSpeed; // 0x910(0x28)
	struct FScalableFloat MaxPlayerLaunchSpeed; // 0x938(0x28)
	struct FScalableFloat SmashEffectRadius; // 0x960(0x28)
	struct FScalableFloat SmashLaunchSpeed; // 0x988(0x28)
	struct TMap<struct AFortPawn*, float> PlayersRecentlyDamaged; // 0x9b0(0x50)
	struct FScalableFloat PlayerImmunityTimeAfterHit; // 0xa00(0x28)
	struct APawn* LastInstigator; // 0xa28(0x08)
	struct FHitResult LastHitInfo; // 0xa30(0x88)
	struct AController* LastServerInstigator; // 0xab8(0x08)
	struct FScalableFloat PickaxeImpulse; // 0xac0(0x28)
	struct FScalableFloat LaunchSpeedFromWeakpoint; // 0xae8(0x28)
	struct FScalableFloat DamageImpulseMultiplier; // 0xb10(0x28)
	float ImpactMagnitude; // 0xb38(0x04)
	float LastInstigationTime; // 0xb3c(0x04)
	struct FScalableFloat SelfDamageImmunityTime; // 0xb40(0x28)
	struct TArray<struct APawn*> AllInstigatorsSinceSleep; // 0xb68(0x10)
	float PlayerLaunchSpeedMultiplier; // 0xb78(0x04)
	char UnknownData_B7C[0x4]; // 0xb7c(0x04)
	struct FScalableFloat MaxDistanceFromWeakspot; // 0xb80(0x28)
	struct FScalableFloat PlayerLaunchSpeedMultiplier_; // 0xba8(0x28)
	struct FVector Effect Location; // 0xbd0(0x0c)
	float Min Large Impulse Magnitude; // 0xbdc(0x04)
	bool KillWeakpoint; // 0xbe0(0x01)
	char UnknownData_BE1[0x7]; // 0xbe1(0x07)
	struct FScalableFloat LowVehicleDamage; // 0xbe8(0x28)
	struct FScalableFloat HighVehicleDamage; // 0xc10(0x28)
	struct FVector NormalImpulseDir; // 0xc38(0x0c)
	struct FHitResult HitInfo; // 0xc44(0x88)
	char UnknownData_CCC[0x4]; // 0xccc(0x04)
	struct FScalableFloat IsSelfDamageAllowed?; // 0xcd0(0x28)

	bool IsPlayerImmune(struct AActor* HitActor); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.IsPlayerImmune // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool IsWeakpointTooFarAway(struct UFortWeakPointComponent* WeakPointComponent, struct FBuildingWeakSpotData WeakSpotData); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.IsWeakpointTooFarAway // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void DamageFX(struct FVector Location, struct UPrimitiveComponent* HitComponent); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.DamageFX // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnDamagePlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.OnDamagePlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnDamage(struct FHitResult Hit, struct APawn* Instigator, float Damage, struct AActor* DamageCauser, struct FGameplayTagContainer DamageTags); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.OnDamage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPickedUp(); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.OnPickedUp // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPutDown(); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.OnPutDown // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BreakCollisionLoop(); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.BreakCollisionLoop // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ParentMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.BndEvt__ParentMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Update(); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.Update // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortWeakPoint_K2Node_ComponentBoundEvent_2_FortWeakPointHit__DelegateSignature(struct FVector HitLocation, struct FVector HitNormal); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.BndEvt__FortWeakPoint_K2Node_ComponentBoundEvent_2_FortWeakPointHit__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ForceDamageCheck(); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.ForceDamageCheck // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReEnableWeakpoints(); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.ReEnableWeakpoints // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_Physics_Boulder(int32_t EntryPoint); // Function BGA_Athena_Physics_Boulder.BGA_Athena_Physics_Boulder_C.ExecuteUbergraph_BGA_Athena_Physics_Boulder // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

