// WidgetBlueprintGeneratedClass AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C
// Size: 0xce4 (Inherited: 0xbf0)
struct UAthenaLeaderboardTabButton_C : UCommonButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbf0(0x08)
	struct UCommonTextBlock* CenterButtonTextWidget; // 0xbf8(0x08)
	struct UHorizontalBox* ContentHB; // 0xc00(0x08)
	struct UImage* LeftSideImage; // 0xc08(0x08)
	struct FText ButtonText; // 0xc10(0x18)
	struct FSlateBrush IconBrush; // 0xc28(0x88)
	bool UseText; // 0xcb0(0x01)
	char UnknownData_CB1[0x3]; // 0xcb1(0x03)
	struct FLinearColor SelectedIconTint; // 0xcb4(0x10)
	struct FLinearColor DeselectedIconTint; // 0xcc4(0x10)
	struct FLinearColor HoveredIconTint; // 0xcd4(0x10)

	void ShowText(); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.ShowText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Set Icon(struct FSlateBrush IconBrush); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.Set Icon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Set Text(struct FText ButtonText); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.Set Text // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnCurrentTextStyleChanged(); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.OnCurrentTextStyleChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SetTabLabelInfo(struct FFortTabButtonLabelInfo TabLabelInfo); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.SetTabLabelInfo // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BP_OnSelected(); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnDeselected(); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaLeaderboardTabButton(int32_t EntryPoint); // Function AthenaLeaderboardTabButton.AthenaLeaderboardTabButton_C.ExecuteUbergraph_AthenaLeaderboardTabButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

