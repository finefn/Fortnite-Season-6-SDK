// WidgetBlueprintGeneratedClass BacchusBoundActionButton.BacchusBoundActionButton_C
// Size: 0xc18 (Inherited: 0xbf8)
struct UBacchusBoundActionButton_C : UBacchusBoundActionButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbf8(0x08)
	struct UBorder* ContentBorder; // 0xc00(0x08)
	struct UFortMobileImage* FortMobileImageInputAction; // 0xc08(0x08)
	struct UScaleBox* InputActionIconScale; // 0xc10(0x08)

	void UpdateInputActionIconSize(); // Function BacchusBoundActionButton.BacchusBoundActionButton_C.UpdateInputActionIconSize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnUpdateInputAction(); // Function BacchusBoundActionButton.BacchusBoundActionButton_C.OnUpdateInputAction // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function BacchusBoundActionButton.BacchusBoundActionButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BacchusBoundActionButton(int32_t EntryPoint); // Function BacchusBoundActionButton.BacchusBoundActionButton_C.ExecuteUbergraph_BacchusBoundActionButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

