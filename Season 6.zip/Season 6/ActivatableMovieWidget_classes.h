// WidgetBlueprintGeneratedClass ActivatableMovieWidget.ActivatableMovieWidget_C
// Size: 0x588 (Inherited: 0x578)
struct UActivatableMovieWidget_C : UFortActivatableVideoPanel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct USafeZone* MainSafeZone; // 0x580(0x08)

	void Construct(); // Function ActivatableMovieWidget.ActivatableMovieWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_ActivatableMovieWidget(int32_t EntryPoint); // Function ActivatableMovieWidget.ActivatableMovieWidget_C.ExecuteUbergraph_ActivatableMovieWidget // (Final|UbergraphFunction) // @ game+0xbd830c
};

