// BlueprintGeneratedClass DA_CarminePack.DA_CarminePack_C
// Size: 0xe60 (Inherited: 0xdc8)
struct ADA_CarminePack_C : AFortCustomizableAbilityDecoTool {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xdc8(0x08)
	float PunchPicker; // 0xdd0(0x04)
	bool hasLandedAfterBeam; // 0xdd4(0x01)
	char UnknownData_DD5[0x3]; // 0xdd5(0x03)
	struct FGameplayTagContainer Carmine_Ability_Tags; // 0xdd8(0x20)
	struct TArray<struct FGameplayTag> StoneTags; // 0xdf8(0x10)
	struct TArray<struct FGameplayTag> GemTags; // 0xe08(0x10)
	int32_t Int; // 0xe18(0x04)
	char UnknownData_E1C[0x4]; // 0xe1c(0x04)
	struct FGameplayTagContainer SkydiveCue; // 0xe20(0x20)
	struct FGameplayTagContainer TrailsCue; // 0xe40(0x20)

	void OnRep_StoneTags(); // Function DA_CarminePack.DA_CarminePack_C.OnRep_StoneTags // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BPPressTrigger(struct AFortDecoHelper* FortDecoHelper); // Function DA_CarminePack.DA_CarminePack_C.BPPressTrigger // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BPPressSecondaryFire(struct AFortDecoHelper* FortDecoHelper); // Function DA_CarminePack.DA_CarminePack_C.BPPressSecondaryFire // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function DA_CarminePack.DA_CarminePack_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Landed(struct FHitResult Hit); // Function DA_CarminePack.DA_CarminePack_C.Landed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BindPartchanged(); // Function DA_CarminePack.DA_CarminePack_C.BindPartchanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_DA_CarminePack(int32_t EntryPoint); // Function DA_CarminePack.DA_CarminePack_C.ExecuteUbergraph_DA_CarminePack // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

