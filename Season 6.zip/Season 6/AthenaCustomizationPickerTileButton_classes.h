// WidgetBlueprintGeneratedClass AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C
// Size: 0xc88 (Inherited: 0xc30)
struct UAthenaCustomizationPickerTileButton_C : UAthenaCustomizationPickerTileButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc30(0x08)
	struct UWidgetAnimation* OnHover; // 0xc38(0x08)
	struct UImage* ExclusiveFill; // 0xc40(0x08)
	struct UOverlay* ExclusiveWarningOvr; // 0xc48(0x08)
	struct UFortLazyImage* Image_Equipped; // 0xc50(0x08)
	struct UOverlay* NullItemOverlay; // 0xc58(0x08)
	struct UWidgetSwitcher* RootWidgetSwitcher; // 0xc60(0x08)
	struct UImage* UnownedDampen; // 0xc68(0x08)
	bool IsSlottedSomewhere; // 0xc70(0x01)
	char UnknownData_C71[0x7]; // 0xc71(0x07)
	struct FMulticastInlineDelegate PickedButtonHovered; // 0xc78(0x10)

	void HandleEquippedStateChanged(bool bEquipped, bool bOnDifferentSlot); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.HandleEquippedStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnListItemObjectSet(struct UObject* ListItemObject); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnChangeOwnedState(bool bOwned); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.OnChangeOwnedState // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnEquippedStateChanged(bool bEquipped, bool bOnDifferentSlot); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.OnEquippedStateChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnUpdateExclusiveWarning(bool bShouldWarn); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.OnUpdateExclusiveWarning // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaCustomizationPickerTileButton(int32_t EntryPoint); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.ExecuteUbergraph_AthenaCustomizationPickerTileButton // (Final|UbergraphFunction) // @ game+0xbd830c
	void PickedButtonHovered__DelegateSignature(struct UWidgetSwitcher* WidgetSwitcher); // Function AthenaCustomizationPickerTileButton.AthenaCustomizationPickerTileButton_C.PickedButtonHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

