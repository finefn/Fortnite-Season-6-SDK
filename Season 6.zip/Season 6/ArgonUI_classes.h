// Class ArgonUI.ArgonWidgetBase
// Size: 0x320 (Inherited: 0x318)
struct UArgonWidgetBase : ULTMWidgetBase {
	struct AFortAthenaMutator_Argon* ArgonMutator; // 0x318(0x08)

	void UnbindFromMutator_BP(); // Function ArgonUI.ArgonWidgetBase.UnbindFromMutator_BP // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	struct TArray<struct AFortPlayerStateAthena*> GetTeamPlayerStates(enum class None Team); // Function ArgonUI.ArgonWidgetBase.GetTeamPlayerStates // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x398e9e8
	void BindToMutator_BP(); // Function ArgonUI.ArgonWidgetBase.BindToMutator_BP // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
};

// Class ArgonUI.ArgonHUDAlertWidget
// Size: 0x340 (Inherited: 0x320)
struct UArgonHUDAlertWidget : UArgonWidgetBase {
	float DisplayPlayerFinishedMessageTime; // 0x320(0x04)
	char UnknownData_324[0x4]; // 0x324(0x04)
	struct TArray<struct FArgonFinishedPlayerInfo> PlayerFinishedMessageQueue; // 0x328(0x10)
	char UnknownData_338[0x8]; // 0x338(0x08)

	void OnPlayerFinished(struct FArgonFinishedPlayerInfo FinishedPlayerInfo); // Function ArgonUI.ArgonHUDAlertWidget.OnPlayerFinished // (Final|Native|Private|HasOutParms) // @ game+0x398eb54
	void ForceHidePlayerFinishedMessage(); // Function ArgonUI.ArgonHUDAlertWidget.ForceHidePlayerFinishedMessage // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void DisplayPlayerFinishedMessage(struct FArgonFinishedPlayerInfo FinishedInfo); // Function ArgonUI.ArgonHUDAlertWidget.DisplayPlayerFinishedMessage // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
};

// Class ArgonUI.ArgonLeaderboardWidget
// Size: 0x330 (Inherited: 0x320)
struct UArgonLeaderboardWidget : UArgonWidgetBase {
	struct TArray<struct FArgonLeaderboardData> LeaderboardEntries; // 0x320(0x10)

	void UpdateLeaderboardUI(); // Function ArgonUI.ArgonLeaderboardWidget.UpdateLeaderboardUI // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnRacingPlayersByPlaceChanged(); // Function ArgonUI.ArgonLeaderboardWidget.OnRacingPlayersByPlaceChanged // (Final|Native|Private) // @ game+0x398ec14
	void OnAnyTeamTicketCountChanged(); // Function ArgonUI.ArgonLeaderboardWidget.OnAnyTeamTicketCountChanged // (Final|Native|Private) // @ game+0x398eacc
};

