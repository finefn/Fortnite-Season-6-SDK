// BlueprintGeneratedClass B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C
// Size: 0x9b4 (Inherited: 0x878)
struct AB_Prj_Ranged_FlareGun_C : AFortProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x878(0x08)
	struct UPostProcessComponent* PP_Explode; // 0x880(0x08)
	struct UAudioComponent* Rocket_AudioComponent; // 0x888(0x08)
	struct UStaticMeshComponent* Mesh; // 0x890(0x08)
	float PPFader_PPFade_83D6A8E24D28C000703E6EB526FEAD3C; // 0x898(0x04)
	enum class ETimelineDirection PPFader__Direction_83D6A8E24D28C000703E6EB526FEAD3C; // 0x89c(0x01)
	char UnknownData_89D[0x3]; // 0x89d(0x03)
	struct UTimelineComponent* PPFader; // 0x8a0(0x08)
	struct UParticleSystemComponent* Ribbon_Trail_PSC; // 0x8a8(0x08)
	struct UParticleSystemComponent* Water_Explosion_PSC; // 0x8b0(0x08)
	struct UParticleSystem* Ribbon_Trail_PS; // 0x8b8(0x08)
	struct UParticleSystem* Water_Explosion_PS; // 0x8c0(0x08)
	struct UParticleSystem* Explosion_Generic_PS; // 0x8c8(0x08)
	struct UParticleSystemComponent* Explosion_Generic_PSC; // 0x8d0(0x08)
	struct USoundBase* Rocket_Projectile_Explosion_Sound; // 0x8d8(0x08)
	struct FVector StopLocation; // 0x8e0(0x0c)
	char UnknownData_8EC[0x4]; // 0x8ec(0x04)
	struct UParticleSystem* Explosion_Flesh_Damage_PS; // 0x8f0(0x08)
	struct FRotator StopRotZ; // 0x8f8(0x0c)
	char UnknownData_904[0x4]; // 0x904(0x04)
	struct UParticleSystemComponent* Explosion_Flesh_Damage_PSC; // 0x908(0x08)
	struct USoundBase* Rocket_Projectile_Explosion_Water_Sound; // 0x910(0x08)
	struct UParticleSystemComponent* RocketTrailPS; // 0x918(0x08)
	float Tick Delta; // 0x920(0x04)
	float RocketSpinRate; // 0x924(0x04)
	float Explosion Impact Offset; // 0x928(0x04)
	struct FRotator RocketSpin; // 0x92c(0x0c)
	struct FVector RocketScale; // 0x938(0x0c)
	bool TimerMaxReached?; // 0x944(0x01)
	char UnknownData_945[0x3]; // 0x945(0x03)
	float Decal Size Max; // 0x948(0x04)
	float Decal Size Min; // 0x94c(0x04)
	struct FVector DecalLocation; // 0x950(0x0c)
	char UnknownData_95C[0x4]; // 0x95c(0x04)
	struct UParticleSystem* Rocket Trail Template; // 0x960(0x08)
	enum class EPhysicalSurface SurfaceType; // 0x968(0x01)
	char UnknownData_969[0x7]; // 0x969(0x07)
	struct UForceFeedbackEffect* ExplosionForceFeedbackNear; // 0x970(0x08)
	struct UForceFeedbackEffect* ExplosionForceFeedbackFar; // 0x978(0x08)
	struct FLinearColor BannerPrimaryColor; // 0x980(0x10)
	struct FLinearColor BannerSecondaryColor; // 0x990(0x10)
	struct UTexture2D* BannerIconLarge; // 0x9a0(0x08)
	struct UMaterialInterface* BannerSmokeMaterial; // 0x9a8(0x08)
	float FlareFuseInSecs; // 0x9b0(0x04)

	void UserConstructionScript(); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PPFader__FinishedFunc(); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.PPFader__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void PPFader__UpdateFunc(); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.PPFader__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_615134E044495378BCF0229743AFAF07(struct UObject* Loaded); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.OnLoaded_615134E044495378BCF0229743AFAF07 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnBounce(struct FHitResult Hit); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.OnBounce // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnStop(struct FHitResult Hit); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void FuseTimerMax(); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.FuseTimerMax // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveTick(float DeltaSeconds); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Ranged_FlareGun(int32_t EntryPoint); // Function B_Prj_Ranged_FlareGun.B_Prj_Ranged_FlareGun_C.ExecuteUbergraph_B_Prj_Ranged_FlareGun // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

