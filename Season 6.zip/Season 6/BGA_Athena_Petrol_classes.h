// BlueprintGeneratedClass BGA_Athena_Petrol.BGA_Athena_Petrol_C
// Size: 0x934 (Inherited: 0x878)
struct ABGA_Athena_Petrol_C : ABuildingGameplayActorPetrol {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x878(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x880(0x08)
	struct UFortCurieComponent* FortCurie; // 0x888(0x08)
	struct FVector ImpactNormal; // 0x890(0x0c)
	char UnknownData_89C[0x4]; // 0x89c(0x04)
	struct TMap<struct AActor*, struct FCurieInteractHandle> InteractHandleMap; // 0x8a0(0x50)
	bool Lit; // 0x8f0(0x01)
	char UnknownData_8F1[0x3]; // 0x8f1(0x03)
	float ActorLifespanAfterIgnition; // 0x8f4(0x04)
	float SelfFireMagnitude; // 0x8f8(0x04)
	int32_t SelfPropagationFuel; // 0x8fc(0x04)
	float SelfCurieLandscapeIgnitionRadius; // 0x900(0x04)
	bool IgniteSelf; // 0x904(0x01)
	char UnknownData_905[0x3]; // 0x905(0x03)
	float IgniteNearbyMaterialsRadius; // 0x908(0x04)
	char UnknownData_90C[0x4]; // 0x90c(0x04)
	struct TArray<enum class EObjectTypeQuery> IgniteMaterialsObjectTypes; // 0x910(0x10)
	struct UObject* IgniteMaterialsClassFilter; // 0x920(0x08)
	float IgniteNearbyMaterialsFireMagnitude; // 0x928(0x04)
	int32_t IgniteNearbyMaterialsPropogationFuel; // 0x92c(0x04)
	float IgniteNearbyMaterialsLandscapeIgnitionRadius; // 0x930(0x04)

	void IgniteNearbyMaterials(); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.IgniteNearbyMaterials // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Ignite Self(); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.Ignite Self // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_Lit(); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.OnRep_Lit // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ClientOnIgnite(); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.ClientOnIgnite // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__SphereCollisionComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.BndEvt__SphereCollisionComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__SphereCollisionComponent_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.BndEvt__SphereCollisionComponent_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void InteractingWithFire(struct AActor* OverlappingActor, struct FHitResult HitResult); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.InteractingWithFire // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementInteract_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag, struct FCurieInteractParamsHandle InteractParamsHandle); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.OnCurieElementInteract_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieStateDetached_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag StateTag); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.OnCurieStateDetached_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_Petrol(int32_t EntryPoint); // Function BGA_Athena_Petrol.BGA_Athena_Petrol_C.ExecuteUbergraph_BGA_Athena_Petrol // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

