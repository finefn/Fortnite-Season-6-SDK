// Enum ConcertSyncCore.EConcertDataStoreResultCode
enum class EConcertDataStoreResultCode : uint8 {
	Added,
	Fetched,
	Exchanged,
	NotFound,
	TypeMismatch,
	UnexpectedError,
	EConcertDataStoreResultCode_MAX,
};

// Enum ConcertSyncCore.EConcertMovieScenePlayerStatus
enum class EConcertMovieScenePlayerStatus : uint8 {
	Stopped,
	Playing,
	Recording,
	Scrubbing,
	Jumping,
	Stepping,
	Paused,
	MAX,
};

// Enum ConcertSyncCore.EConcertSyncTransactionActivitySummaryType
enum class EConcertSyncTransactionActivitySummaryType : uint8 {
	Added,
	Updated,
	Renamed,
	Deleted,
	EConcertSyncTransactionActivitySummaryType_MAX,
};

// Enum ConcertSyncCore.EConcertSyncActivityEventType
enum class EConcertSyncActivityEventType : uint8 {
	None,
	Connection,
	Lock,
	Transaction,
	Package,
	EConcertSyncActivityEventType_MAX,
};

// Enum ConcertSyncCore.EConcertSyncLockEventType
enum class EConcertSyncLockEventType : uint8 {
	Locked,
	Unlocked,
	EConcertSyncLockEventType_MAX,
};

// Enum ConcertSyncCore.EConcertSyncConnectionEventType
enum class EConcertSyncConnectionEventType : uint8 {
	Connected,
	Disconnected,
	EConcertSyncConnectionEventType_MAX,
};

// Enum ConcertSyncCore.EConcertPackageUpdateType
enum class EConcertPackageUpdateType : uint8 {
	Dummy,
	Added,
	Saved,
	Renamed,
	Deleted,
	EConcertPackageUpdateType_MAX,
};

// Enum ConcertSyncCore.EConcertPlaySessionEventType
enum class EConcertPlaySessionEventType : uint8 {
	None,
	BeginPlay,
	SwitchPlay,
	EndPlay,
	EConcertPlaySessionEventType_MAX,
};

// Enum ConcertSyncCore.EConcertResourceLockType
enum class EConcertResourceLockType : uint8 {
	None,
	Lock,
	Unlock,
	EConcertResourceLockType_MAX,
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_Response
// Size: 0x38 (Inherited: 0x00)
struct FConcertDataStore_Response {
	enum class EConcertDataStoreResultCode ResultCode; // 0x00(0x01)
	char UnknownData_1[0x7]; // 0x01(0x07)
	struct FConcertDataStore_StoreValue Value; // 0x08(0x30)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_StoreValue
// Size: 0x30 (Inherited: 0x00)
struct FConcertDataStore_StoreValue {
	struct FName TypeName; // 0x00(0x08)
	uint32_t Version; // 0x08(0x04)
	char UnknownData_C[0x4]; // 0x0c(0x04)
	struct FConcertSessionSerializedPayload SerializedValue; // 0x10(0x20)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_Request
// Size: 0x10 (Inherited: 0x00)
struct FConcertDataStore_Request {
	struct FName Key; // 0x00(0x08)
	struct FName TypeName; // 0x08(0x08)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_CompareExchangeRequest
// Size: 0x58 (Inherited: 0x10)
struct FConcertDataStore_CompareExchangeRequest : FConcertDataStore_Request {
	uint32_t ExpectedVersion; // 0x10(0x04)
	char UnknownData_14[0x4]; // 0x14(0x04)
	struct FConcertSessionSerializedPayload Expected; // 0x18(0x20)
	struct FConcertSessionSerializedPayload Desired; // 0x38(0x20)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_FetchOrAddRequest
// Size: 0x30 (Inherited: 0x10)
struct FConcertDataStore_FetchOrAddRequest : FConcertDataStore_Request {
	struct FConcertSessionSerializedPayload SerializedValue; // 0x10(0x20)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_ReplicateEvent
// Size: 0x10 (Inherited: 0x00)
struct FConcertDataStore_ReplicateEvent {
	struct TArray<struct FConcertDataStore_KeyValuePair> Values; // 0x00(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_KeyValuePair
// Size: 0x38 (Inherited: 0x00)
struct FConcertDataStore_KeyValuePair {
	struct FName Key; // 0x00(0x08)
	struct FConcertDataStore_StoreValue Value; // 0x08(0x30)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_Text
// Size: 0x18 (Inherited: 0x00)
struct FConcertDataStore_Text {
	struct FText Value; // 0x00(0x18)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_String
// Size: 0x10 (Inherited: 0x00)
struct FConcertDataStore_String {
	struct FString Value; // 0x00(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_Double
// Size: 0x08 (Inherited: 0x00)
struct FConcertDataStore_Double {
	double Value; // 0x00(0x08)
};

// ScriptStruct ConcertSyncCore.ConcertDataStore_Integer
// Size: 0x08 (Inherited: 0x00)
struct FConcertDataStore_Integer {
	uint64_t Value; // 0x00(0x08)
};

// ScriptStruct ConcertSyncCore.ConcertClientPresenceEventBase
// Size: 0x04 (Inherited: 0x00)
struct FConcertClientPresenceEventBase {
	uint32_t TransactionUpdateIndex; // 0x00(0x04)
};

// ScriptStruct ConcertSyncCore.ConcertClientVRPresenceUpdateEvent
// Size: 0x70 (Inherited: 0x04)
struct FConcertClientVRPresenceUpdateEvent : FConcertClientPresenceEventBase {
	struct FVector LeftMotionControllerPosition; // 0x04(0x0c)
	struct FQuat LeftMotionControllerOrientation; // 0x10(0x10)
	struct FVector RightMotionControllerPosition; // 0x20(0x0c)
	char UnknownData_2C[0x4]; // 0x2c(0x04)
	struct FQuat RightMotionControllerOrientation; // 0x30(0x10)
	struct FConcertLaserData Lasers[0x2]; // 0x40(0x30)
};

// ScriptStruct ConcertSyncCore.ConcertLaserData
// Size: 0x18 (Inherited: 0x00)
struct FConcertLaserData {
	struct FVector LaserStart; // 0x00(0x0c)
	struct FVector LaserEnd; // 0x0c(0x0c)
};

// ScriptStruct ConcertSyncCore.ConcertClientDesktopPresenceUpdateEvent
// Size: 0x20 (Inherited: 0x04)
struct FConcertClientDesktopPresenceUpdateEvent : FConcertClientPresenceEventBase {
	struct FVector TraceStart; // 0x04(0x0c)
	struct FVector TraceEnd; // 0x10(0x0c)
	bool bMovingCamera; // 0x1c(0x01)
	char UnknownData_1D[0x3]; // 0x1d(0x03)
};

// ScriptStruct ConcertSyncCore.ConcertClientPresenceDataUpdateEvent
// Size: 0x30 (Inherited: 0x04)
struct FConcertClientPresenceDataUpdateEvent : FConcertClientPresenceEventBase {
	struct FName WorldPath; // 0x04(0x08)
	struct FVector Position; // 0x0c(0x0c)
	char UnknownData_18[0x8]; // 0x18(0x08)
	struct FQuat Orientation; // 0x20(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertClientPresenceInVREvent
// Size: 0x08 (Inherited: 0x00)
struct FConcertClientPresenceInVREvent {
	struct FName VRDevice; // 0x00(0x08)
};

// ScriptStruct ConcertSyncCore.ConcertClientPresenceVisibilityUpdateEvent
// Size: 0x14 (Inherited: 0x00)
struct FConcertClientPresenceVisibilityUpdateEvent {
	struct FGuid ModifiedEndpointId; // 0x00(0x10)
	bool bVisibility; // 0x10(0x01)
	char UnknownData_11[0x3]; // 0x11(0x03)
};

// ScriptStruct ConcertSyncCore.ConcertSequencerStateSyncEvent
// Size: 0x10 (Inherited: 0x00)
struct FConcertSequencerStateSyncEvent {
	struct TArray<struct FConcertSequencerState> SequencerStates; // 0x00(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertSequencerState
// Size: 0x28 (Inherited: 0x00)
struct FConcertSequencerState {
	struct FString SequenceObjectPath; // 0x00(0x10)
	struct FQualifiedFrameTime Time; // 0x10(0x10)
	enum class EConcertMovieScenePlayerStatus PlayerStatus; // 0x20(0x01)
	char UnknownData_21[0x3]; // 0x21(0x03)
	float PlaybackSpeed; // 0x24(0x04)
};

// ScriptStruct ConcertSyncCore.ConcertSequencerStateEvent
// Size: 0x28 (Inherited: 0x00)
struct FConcertSequencerStateEvent {
	struct FConcertSequencerState State; // 0x00(0x28)
};

// ScriptStruct ConcertSyncCore.ConcertSequencerCloseEvent
// Size: 0x18 (Inherited: 0x00)
struct FConcertSequencerCloseEvent {
	struct FString SequenceObjectPath; // 0x00(0x10)
	bool bMasterClose; // 0x10(0x01)
	char UnknownData_11[0x7]; // 0x11(0x07)
};

// ScriptStruct ConcertSyncCore.ConcertSequencerOpenEvent
// Size: 0x10 (Inherited: 0x00)
struct FConcertSequencerOpenEvent {
	struct FString SequenceObjectPath; // 0x00(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertSyncActivitySummary
// Size: 0x08 (Inherited: 0x00)
struct FConcertSyncActivitySummary {
	char UnknownData_0[0x8]; // 0x00(0x08)
};

// ScriptStruct ConcertSyncCore.ConcertSyncPackageActivitySummary
// Size: 0x20 (Inherited: 0x08)
struct FConcertSyncPackageActivitySummary : FConcertSyncActivitySummary {
	struct FName PackageName; // 0x08(0x08)
	struct FName NewPackageName; // 0x10(0x08)
	enum class EConcertPackageUpdateType PackageUpdateType; // 0x18(0x01)
	bool bAutoSave; // 0x19(0x01)
	bool bPreSave; // 0x1a(0x01)
	char UnknownData_1B[0x5]; // 0x1b(0x05)
};

// ScriptStruct ConcertSyncCore.ConcertSyncTransactionActivitySummary
// Size: 0x48 (Inherited: 0x08)
struct FConcertSyncTransactionActivitySummary : FConcertSyncActivitySummary {
	enum class EConcertSyncTransactionActivitySummaryType TransactionSummaryType; // 0x08(0x01)
	char UnknownData_9[0x7]; // 0x09(0x07)
	struct FText TransactionTitle; // 0x10(0x18)
	struct FName PrimaryObjectName; // 0x28(0x08)
	struct FName PrimaryPackageName; // 0x30(0x08)
	struct FName NewObjectName; // 0x38(0x08)
	int32_t NumActions; // 0x40(0x04)
	char UnknownData_44[0x4]; // 0x44(0x04)
};

// ScriptStruct ConcertSyncCore.ConcertSyncLockActivitySummary
// Size: 0x20 (Inherited: 0x08)
struct FConcertSyncLockActivitySummary : FConcertSyncActivitySummary {
	enum class EConcertSyncLockEventType LockEventType; // 0x08(0x01)
	char UnknownData_9[0x3]; // 0x09(0x03)
	struct FName PrimaryResourceName; // 0x0c(0x08)
	struct FName PrimaryPackageName; // 0x14(0x08)
	int32_t NumResources; // 0x1c(0x04)
};

// ScriptStruct ConcertSyncCore.ConcertSyncConnectionActivitySummary
// Size: 0x10 (Inherited: 0x08)
struct FConcertSyncConnectionActivitySummary : FConcertSyncActivitySummary {
	enum class EConcertSyncConnectionEventType ConnectionEventType; // 0x08(0x01)
	char UnknownData_9[0x7]; // 0x09(0x07)
};

// ScriptStruct ConcertSyncCore.ConcertSyncActivity
// Size: 0x58 (Inherited: 0x00)
struct FConcertSyncActivity {
	int64_t ActivityId; // 0x00(0x08)
	bool bIgnored; // 0x08(0x01)
	char UnknownData_9[0x3]; // 0x09(0x03)
	struct FGuid EndpointId; // 0x0c(0x10)
	char UnknownData_1C[0x4]; // 0x1c(0x04)
	struct FDateTime EventTime; // 0x20(0x08)
	enum class EConcertSyncActivityEventType EventType; // 0x28(0x01)
	char UnknownData_29[0x7]; // 0x29(0x07)
	int64_t EventId; // 0x30(0x08)
	struct FConcertSessionSerializedCborPayload EventSummary; // 0x38(0x20)
};

// ScriptStruct ConcertSyncCore.ConcertSyncPackageActivity
// Size: 0xc8 (Inherited: 0x58)
struct FConcertSyncPackageActivity : FConcertSyncActivity {
	struct FConcertSyncPackageEvent EventData; // 0x58(0x70)
};

// ScriptStruct ConcertSyncCore.ConcertSyncPackageEvent
// Size: 0x70 (Inherited: 0x00)
struct FConcertSyncPackageEvent {
	int64_t PackageRevision; // 0x00(0x08)
	struct FConcertPackage Package; // 0x08(0x68)
};

// ScriptStruct ConcertSyncCore.ConcertPackage
// Size: 0x68 (Inherited: 0x00)
struct FConcertPackage {
	struct FConcertPackageInfo Info; // 0x00(0x48)
	struct TArray<enum class None> PackageData; // 0x48(0x10)
	struct FString FileId; // 0x58(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertPackageInfo
// Size: 0x48 (Inherited: 0x00)
struct FConcertPackageInfo {
	struct FName PackageName; // 0x00(0x08)
	struct FName NewPackageName; // 0x08(0x08)
	struct FString AssetClass; // 0x10(0x10)
	struct FString PackageFileExtension; // 0x20(0x10)
	enum class EConcertPackageUpdateType PackageUpdateType; // 0x30(0x01)
	char UnknownData_31[0x7]; // 0x31(0x07)
	int64_t TransactionEventIdAtSave; // 0x38(0x08)
	bool bPreSave; // 0x40(0x01)
	bool bAutoSave; // 0x41(0x01)
	char UnknownData_42[0x6]; // 0x42(0x06)
};

// ScriptStruct ConcertSyncCore.ConcertSyncTransactionActivity
// Size: 0x108 (Inherited: 0x58)
struct FConcertSyncTransactionActivity : FConcertSyncActivity {
	struct FConcertSyncTransactionEvent EventData; // 0x58(0xb0)
};

// ScriptStruct ConcertSyncCore.ConcertSyncTransactionEvent
// Size: 0xb0 (Inherited: 0x00)
struct FConcertSyncTransactionEvent {
	struct FConcertTransactionFinalizedEvent Transaction; // 0x00(0xb0)
};

// ScriptStruct ConcertSyncCore.ConcertTransactionEventBase
// Size: 0x88 (Inherited: 0x00)
struct FConcertTransactionEventBase {
	struct FGuid TransactionId; // 0x00(0x10)
	struct FGuid OperationId; // 0x10(0x10)
	struct FGuid TransactionEndpointId; // 0x20(0x10)
	enum class None TransactionUpdateIndex; // 0x30(0x01)
	char UnknownData_31[0x3]; // 0x31(0x03)
	int32_t VersionIndex; // 0x34(0x04)
	struct TArray<struct FName> ModifiedPackages; // 0x38(0x10)
	struct FConcertObjectId PrimaryObjectId; // 0x48(0x2c)
	char UnknownData_74[0x4]; // 0x74(0x04)
	struct TArray<struct FConcertExportedObject> ExportedObjects; // 0x78(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertExportedObject
// Size: 0x88 (Inherited: 0x00)
struct FConcertExportedObject {
	struct FConcertObjectId ObjectId; // 0x00(0x2c)
	int32_t ObjectPathDepth; // 0x2c(0x04)
	struct FConcertSerializedObjectData ObjectData; // 0x30(0x38)
	struct TArray<struct FConcertSerializedPropertyData> PropertyDatas; // 0x68(0x10)
	struct TArray<enum class None> SerializedAnnotationData; // 0x78(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertSerializedPropertyData
// Size: 0x18 (Inherited: 0x00)
struct FConcertSerializedPropertyData {
	struct FName PropertyName; // 0x00(0x08)
	struct TArray<enum class None> SerializedData; // 0x08(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertSerializedObjectData
// Size: 0x38 (Inherited: 0x00)
struct FConcertSerializedObjectData {
	bool bAllowCreate; // 0x00(0x01)
	bool bIsPendingKill; // 0x01(0x01)
	char UnknownData_2[0x2]; // 0x02(0x02)
	struct FName NewPackageName; // 0x04(0x08)
	struct FName NewName; // 0x0c(0x08)
	struct FName NewOuterPathName; // 0x14(0x08)
	struct FName NewExternalPackageName; // 0x1c(0x08)
	char UnknownData_24[0x4]; // 0x24(0x04)
	struct TArray<enum class None> SerializedData; // 0x28(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertObjectId
// Size: 0x2c (Inherited: 0x00)
struct FConcertObjectId {
	struct FName ObjectClassPathName; // 0x00(0x08)
	struct FName ObjectPackageName; // 0x08(0x08)
	struct FName ObjectName; // 0x10(0x08)
	struct FName ObjectOuterPathName; // 0x18(0x08)
	struct FName ObjectExternalPackageName; // 0x20(0x08)
	uint32_t ObjectPersistentFlags; // 0x28(0x04)
};

// ScriptStruct ConcertSyncCore.ConcertTransactionFinalizedEvent
// Size: 0xb0 (Inherited: 0x88)
struct FConcertTransactionFinalizedEvent : FConcertTransactionEventBase {
	struct FConcertLocalIdentifierState LocalIdentifierState; // 0x88(0x10)
	struct FText Title; // 0x98(0x18)
};

// ScriptStruct ConcertSyncCore.ConcertSyncLockActivity
// Size: 0x70 (Inherited: 0x58)
struct FConcertSyncLockActivity : FConcertSyncActivity {
	struct FConcertSyncLockEvent EventData; // 0x58(0x18)
};

// ScriptStruct ConcertSyncCore.ConcertSyncLockEvent
// Size: 0x18 (Inherited: 0x00)
struct FConcertSyncLockEvent {
	enum class EConcertSyncLockEventType LockEventType; // 0x00(0x01)
	char UnknownData_1[0x7]; // 0x01(0x07)
	struct TArray<struct FName> ResourceNames; // 0x08(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertSyncConnectionActivity
// Size: 0x60 (Inherited: 0x58)
struct FConcertSyncConnectionActivity : FConcertSyncActivity {
	struct FConcertSyncConnectionEvent EventData; // 0x58(0x01)
	char UnknownData_59[0x7]; // 0x59(0x07)
};

// ScriptStruct ConcertSyncCore.ConcertSyncConnectionEvent
// Size: 0x01 (Inherited: 0x00)
struct FConcertSyncConnectionEvent {
	enum class EConcertSyncConnectionEventType ConnectionEventType; // 0x00(0x01)
};

// ScriptStruct ConcertSyncCore.ConcertSyncPackageEventMetaData
// Size: 0x50 (Inherited: 0x00)
struct FConcertSyncPackageEventMetaData {
	int64_t PackageRevision; // 0x00(0x08)
	struct FConcertPackageInfo PackageInfo; // 0x08(0x48)
};

// ScriptStruct ConcertSyncCore.ConcertSyncEndpointIdAndData
// Size: 0xc8 (Inherited: 0x00)
struct FConcertSyncEndpointIdAndData {
	struct FGuid EndpointId; // 0x00(0x10)
	struct FConcertSyncEndpointData EndpointData; // 0x10(0xb8)
};

// ScriptStruct ConcertSyncCore.ConcertSyncEndpointData
// Size: 0xb8 (Inherited: 0x00)
struct FConcertSyncEndpointData {
	struct FConcertClientInfo ClientInfo; // 0x00(0xb8)
};

// ScriptStruct ConcertSyncCore.PackageClassFilter
// Size: 0x28 (Inherited: 0x00)
struct FPackageClassFilter {
	struct FSoftClassPath AssetClass; // 0x00(0x18)
	struct TArray<struct FString> ContentPaths; // 0x18(0x10)
};

// ScriptStruct ConcertSyncCore.TransactionClassFilter
// Size: 0x28 (Inherited: 0x00)
struct FTransactionClassFilter {
	struct FSoftClassPath ObjectOuterClass; // 0x00(0x18)
	struct TArray<struct FSoftClassPath> ObjectClasses; // 0x18(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertTransactionRejectedEvent
// Size: 0x10 (Inherited: 0x00)
struct FConcertTransactionRejectedEvent {
	struct FGuid TransactionId; // 0x00(0x10)
};

// ScriptStruct ConcertSyncCore.ConcertTransactionSnapshotEvent
// Size: 0x88 (Inherited: 0x88)
struct FConcertTransactionSnapshotEvent : FConcertTransactionEventBase {
};

// ScriptStruct ConcertSyncCore.ConcertIgnoreActivityStateChangedEvent
// Size: 0x14 (Inherited: 0x00)
struct FConcertIgnoreActivityStateChangedEvent {
	struct FGuid EndpointId; // 0x00(0x10)
	bool bIgnore; // 0x10(0x01)
	char UnknownData_11[0x3]; // 0x11(0x03)
};

// ScriptStruct ConcertSyncCore.ConcertPlaySessionEvent
// Size: 0x20 (Inherited: 0x00)
struct FConcertPlaySessionEvent {
	enum class EConcertPlaySessionEventType EventType; // 0x00(0x01)
	char UnknownData_1[0x3]; // 0x01(0x03)
	struct FGuid PlayEndpointId; // 0x04(0x10)
	struct FName PlayPackageName; // 0x14(0x08)
	bool bIsSimulating; // 0x1c(0x01)
	char UnknownData_1D[0x3]; // 0x1d(0x03)
};

// ScriptStruct ConcertSyncCore.ConcertResourceLockResponse
// Size: 0x58 (Inherited: 0x00)
struct FConcertResourceLockResponse {
	struct TMap<struct FName, struct FGuid> FailedResources; // 0x00(0x50)
	enum class EConcertResourceLockType LockType; // 0x50(0x01)
	char UnknownData_51[0x7]; // 0x51(0x07)
};

// ScriptStruct ConcertSyncCore.ConcertResourceLockRequest
// Size: 0x28 (Inherited: 0x00)
struct FConcertResourceLockRequest {
	struct FGuid ClientId; // 0x00(0x10)
	struct TArray<struct FName> ResourceNames; // 0x10(0x10)
	enum class EConcertResourceLockType LockType; // 0x20(0x01)
	char UnknownData_21[0x7]; // 0x21(0x07)
};

// ScriptStruct ConcertSyncCore.ConcertResourceLockEvent
// Size: 0x28 (Inherited: 0x00)
struct FConcertResourceLockEvent {
	struct FGuid ClientId; // 0x00(0x10)
	struct TArray<struct FName> ResourceNames; // 0x10(0x10)
	enum class EConcertResourceLockType LockType; // 0x20(0x01)
	char UnknownData_21[0x7]; // 0x21(0x07)
};

// ScriptStruct ConcertSyncCore.ConcertPackageRejectedEvent
// Size: 0x08 (Inherited: 0x00)
struct FConcertPackageRejectedEvent {
	struct FName PackageName; // 0x00(0x08)
};

// ScriptStruct ConcertSyncCore.ConcertPackageUpdateEvent
// Size: 0x68 (Inherited: 0x00)
struct FConcertPackageUpdateEvent {
	struct FConcertPackage Package; // 0x00(0x68)
};

// ScriptStruct ConcertSyncCore.ConcertSyncEventResponse
// Size: 0x20 (Inherited: 0x00)
struct FConcertSyncEventResponse {
	struct FConcertSessionSerializedPayload Event; // 0x00(0x20)
};

// ScriptStruct ConcertSyncCore.ConcertSyncEventRequest
// Size: 0x10 (Inherited: 0x00)
struct FConcertSyncEventRequest {
	enum class EConcertSyncActivityEventType EventType; // 0x00(0x01)
	char UnknownData_1[0x7]; // 0x01(0x07)
	int64_t EventId; // 0x08(0x08)
};

// ScriptStruct ConcertSyncCore.ConcertWorkspaceSyncCompletedEvent
// Size: 0x01 (Inherited: 0x00)
struct FConcertWorkspaceSyncCompletedEvent {
	char UnknownData_0[0x1]; // 0x00(0x01)
};

// ScriptStruct ConcertSyncCore.ConcertWorkspaceSyncRequestedEvent
// Size: 0x18 (Inherited: 0x00)
struct FConcertWorkspaceSyncRequestedEvent {
	int64_t FirstActivityIdToSync; // 0x00(0x08)
	int64_t LastActivityIdToSync; // 0x08(0x08)
	bool bEnableLiveSync; // 0x10(0x01)
	char UnknownData_11[0x7]; // 0x11(0x07)
};

// ScriptStruct ConcertSyncCore.ConcertWorkspaceSyncEventBase
// Size: 0x04 (Inherited: 0x00)
struct FConcertWorkspaceSyncEventBase {
	int32_t NumRemainingSyncEvents; // 0x00(0x04)
};

// ScriptStruct ConcertSyncCore.ConcertWorkspaceSyncLockEvent
// Size: 0x58 (Inherited: 0x04)
struct FConcertWorkspaceSyncLockEvent : FConcertWorkspaceSyncEventBase {
	char UnknownData_4[0x4]; // 0x04(0x04)
	struct TMap<struct FName, struct FGuid> LockedResources; // 0x08(0x50)
};

// ScriptStruct ConcertSyncCore.ConcertWorkspaceSyncActivityEvent
// Size: 0x28 (Inherited: 0x04)
struct FConcertWorkspaceSyncActivityEvent : FConcertWorkspaceSyncEventBase {
	char UnknownData_4[0x4]; // 0x04(0x04)
	struct FConcertSessionSerializedPayload Activity; // 0x08(0x20)
};

// ScriptStruct ConcertSyncCore.ConcertWorkspaceSyncEndpointEvent
// Size: 0xd0 (Inherited: 0x04)
struct FConcertWorkspaceSyncEndpointEvent : FConcertWorkspaceSyncEventBase {
	char UnknownData_4[0x4]; // 0x04(0x04)
	struct FConcertSyncEndpointIdAndData Endpoint; // 0x08(0xc8)
};

