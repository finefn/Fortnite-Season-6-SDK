// BlueprintGeneratedClass B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C
// Size: 0x938 (Inherited: 0x8f0)
struct AB_Prj_Bow_Flame_Fireball_C : AB_Prj_Athena_Generic_CurieFireball_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8f0(0x08)
	struct UParticleSystemComponent* P_GL_Ribbon_SmokeTrail; // 0x8f8(0x08)
	struct UBP_SurfaceTypeSoundComponent_C* BP_SurfaceTypeSoundComponent; // 0x900(0x08)
	struct UAudioComponent* LoopingAudioTell; // 0x908(0x08)
	struct UParticleSystem* IntoWaterEffects; // 0x910(0x08)
	struct USoundBase* HitWater_NoFire_Sound; // 0x918(0x08)
	float BurnoutTime; // 0x920(0x04)
	struct FVector Impact Point; // 0x924(0x0c)
	struct USoundBase* Impact Sound; // 0x930(0x08)

	void UserConstructionScript(); // Function B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStop(struct FHitResult Hit); // Function B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Burnout(); // Function B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C.Burnout // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Play Impact Sound(); // Function B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C.Play Impact Sound // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Bow_Flame_Fireball(int32_t EntryPoint); // Function B_Prj_Bow_Flame_Fireball.B_Prj_Bow_Flame_Fireball_C.ExecuteUbergraph_B_Prj_Bow_Flame_Fireball // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

