// WidgetBlueprintGeneratedClass BattlePassRewardChallenges.BattlePassRewardChallenges_C
// Size: 0x379 (Inherited: 0x348)
struct UBattlePassRewardChallenges_C : UBattlePassRewardChallenges {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x348(0x08)
	struct UWidgetAnimation* Outro; // 0x350(0x08)
	struct UWidgetAnimation* Intro; // 0x358(0x08)
	struct UCommonWidgetSwitcher* ChallengesAvailableSwitcher; // 0x360(0x08)
	struct UHorizontalBox* ChallengesLocked; // 0x368(0x08)
	struct UImage* ImageLockIcon; // 0x370(0x08)
	bool bChallengesActive; // 0x378(0x01)

	void OnClearEntries(); // Function BattlePassRewardChallenges.BattlePassRewardChallenges_C.OnClearEntries // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnInitPrerequisites(); // Function BattlePassRewardChallenges.BattlePassRewardChallenges_C.OnInitPrerequisites // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnAllChalengesCompleted(); // Function BattlePassRewardChallenges.BattlePassRewardChallenges_C.OnAllChalengesCompleted // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnInitChallenges(struct FText ChallengesTitle); // Function BattlePassRewardChallenges.BattlePassRewardChallenges_C.OnInitChallenges // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnSetChallengesSwitcher(bool bShowChallenges); // Function BattlePassRewardChallenges.BattlePassRewardChallenges_C.OnSetChallengesSwitcher // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BattlePassRewardChallenges(int32_t EntryPoint); // Function BattlePassRewardChallenges.BattlePassRewardChallenges_C.ExecuteUbergraph_BattlePassRewardChallenges // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

