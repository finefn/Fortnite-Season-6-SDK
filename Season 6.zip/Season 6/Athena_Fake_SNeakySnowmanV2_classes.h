// BlueprintGeneratedClass Athena_Fake_SNeakySnowmanV2.Athena_Fake_SneakySnowmanV2_C
// Size: 0x7f9 (Inherited: 0x7d8)
struct AAthena_Fake_SneakySnowmanV2_C : ABuildingGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7d8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x7e0(0x08)
	struct USceneComponent* Pivot; // 0x7e8(0x08)
	struct AAthena_Player_SneakySnowmanV2_C* MyOwner; // 0x7f0(0x08)
	bool Clipping; // 0x7f8(0x01)

	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function Athena_Fake_SNeakySnowmanV2.Athena_Fake_SneakySnowmanV2_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function Athena_Fake_SNeakySnowmanV2.Athena_Fake_SneakySnowmanV2_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function Athena_Fake_SNeakySnowmanV2.Athena_Fake_SneakySnowmanV2_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function Athena_Fake_SNeakySnowmanV2.Athena_Fake_SneakySnowmanV2_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Fake_SneakySnowmanV2(int32_t EntryPoint); // Function Athena_Fake_SNeakySnowmanV2.Athena_Fake_SneakySnowmanV2_C.ExecuteUbergraph_Athena_Fake_SneakySnowmanV2 // (Final|UbergraphFunction) // @ game+0xbd830c
};

