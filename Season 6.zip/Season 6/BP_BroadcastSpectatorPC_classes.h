// BlueprintGeneratedClass BP_BroadcastSpectatorPC.BP_BroadcastSpectatorPC_C
// Size: 0x3210 (Inherited: 0x3210)
struct ABP_BroadcastSpectatorPC_C : AFortLiveBroadcastController {

	void UserConstructionScript(); // Function BP_BroadcastSpectatorPC.BP_BroadcastSpectatorPC_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

