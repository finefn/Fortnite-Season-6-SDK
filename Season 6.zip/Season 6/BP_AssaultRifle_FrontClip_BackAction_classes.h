// AnimBlueprintGeneratedClass BP_AssaultRifle_FrontClip_BackAction.BP_AssaultRifle_FrontClip_BackAction_C
// Size: 0x358 (Inherited: 0x2c0)
struct UBP_AssaultRifle_FrontClip_BackAction_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose; // 0x2f8(0x18)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x310(0x48)

	void AnimGraph(struct FPoseLink AnimGraph); // Function BP_AssaultRifle_FrontClip_BackAction.BP_AssaultRifle_FrontClip_BackAction_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_AssaultRifle_FrontClip_BackAction(int32_t EntryPoint); // Function BP_AssaultRifle_FrontClip_BackAction.BP_AssaultRifle_FrontClip_BackAction_C.ExecuteUbergraph_BP_AssaultRifle_FrontClip_BackAction // (Final|UbergraphFunction) // @ game+0xbd830c
};

