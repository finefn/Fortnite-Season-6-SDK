// BlueprintGeneratedClass Creative_Device_Effects_Interface.Creative_Device_Effects_Interface_C
// Size: 0x28 (Inherited: 0x28)
struct UCreative_Device_Effects_Interface_C : UInterface {

	void Get Creative Effect Data(struct FFCreativeEffectColorIndex Effect Color); // Function Creative_Device_Effects_Interface.Creative_Device_Effects_Interface_C.Get Creative Effect Data // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

