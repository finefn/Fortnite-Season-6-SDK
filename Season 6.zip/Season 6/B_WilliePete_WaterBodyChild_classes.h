// BlueprintGeneratedClass B_WilliePete_WaterBodyChild.B_WilliePete_WaterBodyChild_C
// Size: 0xf40 (Inherited: 0xf30)
struct AB_WilliePete_WaterBodyChild_C : AFortWaterBodyActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xf30(0x08)
	struct UArrowComponent* Debug; // 0xf38(0x08)

	void ReceiveBeginPlay(); // Function B_WilliePete_WaterBodyChild.B_WilliePete_WaterBodyChild_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_WilliePete_WaterBodyChild(int32_t EntryPoint); // Function B_WilliePete_WaterBodyChild.B_WilliePete_WaterBodyChild_C.ExecuteUbergraph_B_WilliePete_WaterBodyChild // (Final|UbergraphFunction) // @ game+0xbd830c
};

