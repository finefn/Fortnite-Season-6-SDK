// BlueprintGeneratedClass Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C
// Size: 0xb38 (Inherited: 0xa2d)
struct AAthena_Player_CoolCarpet_C : AAthena_Player_SneakySnowmanV2_C {
	char UnknownData_A2D[0x3]; // 0xa2d(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa30(0x08)
	struct UStaticMeshComponent* SM_ShadowInsert; // 0xa38(0x08)
	struct UStaticMeshComponent* SM_CoolCarpet_Flap1; // 0xa40(0x08)
	struct UStaticMeshComponent* SM_CoolCarpet_Flap2; // 0xa48(0x08)
	float ShrinkBox_Rotation_B702562648A4C4CB590675BD0D3E005C; // 0xa50(0x04)
	float ShrinkBox_Shrinkage_B702562648A4C4CB590675BD0D3E005C; // 0xa54(0x04)
	enum class ETimelineDirection ShrinkBox__Direction_B702562648A4C4CB590675BD0D3E005C; // 0xa58(0x01)
	char UnknownData_A59[0x7]; // 0xa59(0x07)
	struct UTimelineComponent* ShrinkBox; // 0xa60(0x08)
	float Grow_Box_Growth_53FD69EF4E6B5DECD0D74DBB0BDDAA26; // 0xa68(0x04)
	enum class ETimelineDirection Grow_Box__Direction_53FD69EF4E6B5DECD0D74DBB0BDDAA26; // 0xa6c(0x01)
	char UnknownData_A6D[0x3]; // 0xa6d(0x03)
	struct UTimelineComponent* Grow Box; // 0xa70(0x08)
	float Timeline_1_Rotation_A659A2B4463C7B7008A67988DEB011BE; // 0xa78(0x04)
	enum class ETimelineDirection Timeline_1__Direction_A659A2B4463C7B7008A67988DEB011BE; // 0xa7c(0x01)
	char UnknownData_A7D[0x3]; // 0xa7d(0x03)
	struct UTimelineComponent* Timeline_2; // 0xa80(0x08)
	bool AlreadyJumpedOut; // 0xa88(0x01)
	char UnknownData_A89[0x7]; // 0xa89(0x07)
	struct AAthena_Fake_CoolCarpet_C* CastedFakeActor; // 0xa90(0x08)
	bool MovementEventsBound; // 0xa98(0x01)
	char UnknownData_A99[0x7]; // 0xa99(0x07)
	struct USoundBase* OnFootstepSound; // 0xaa0(0x08)
	struct USoundBase* OnLandedSound; // 0xaa8(0x08)
	struct USoundBase* OnJumpedSound; // 0xab0(0x08)
	struct FName HolsterId; // 0xab8(0x08)
	int32_t MatInt; // 0xac0(0x04)
	char UnknownData_AC4[0x4]; // 0xac4(0x04)
	struct FScalableFloat PopOutOnWindUp; // 0xac8(0x28)
	struct FScalableFloat AllowPopOut; // 0xaf0(0x28)
	bool Swimming_1; // 0xb18(0x01)
	enum class PopOutStates PopState; // 0xb19(0x01)
	bool FlapsClosed; // 0xb1a(0x01)
	char UnknownData_B1B[0x5]; // 0xb1b(0x05)
	struct FTimerHandle WindUpEndTimer; // 0xb20(0x08)
	bool PoppedFromWindUp; // 0xb28(0x01)
	bool DidWindUp; // 0xb29(0x01)
	bool PoppedFromStand; // 0xb2a(0x01)
	bool Firing; // 0xb2b(0x01)
	bool FirePressed; // 0xb2c(0x01)
	char UnknownData_B2D[0x3]; // 0xb2d(0x03)
	struct FTimerHandle StopFiringTimer; // 0xb30(0x08)

	void OnRep_PopState(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnRep_PopState // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_MatInt(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnRep_MatInt // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetMaterialInt(int32_t MatInt); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.GetMaterialInt // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPlayerMovementModeChanged(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, enum class None PreviousCustomMode); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnPlayerMovementModeChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPlayerLanded(struct FHitResult Hit); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnPlayerLanded // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPlayerFootstep(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnPlayerFootstep // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStoppedUsingFake(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnStoppedUsingFake // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStartedUsingFake(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnStartedUsingFake // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Timeline_1__FinishedFunc(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Timeline_1__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_1__UpdateFunc(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Timeline_1__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void ShrinkBox__FinishedFunc(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.ShrinkBox__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void ShrinkBox__UpdateFunc(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.ShrinkBox__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void Grow Box__FinishedFunc(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Grow Box__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Grow Box__UpdateFunc(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Grow Box__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OpenFlaps(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OpenFlaps // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CloseFlaps(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.CloseFlaps // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ADS_Client(bool AimDownsights); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.ADS_Client // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CustomEvent(struct AFortWeapon* NewWeapon, struct AFortWeapon* PrevWeapon); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.CustomEvent // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void JumpedOut(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.JumpedOut // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Set Flaps Visible Multicast(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Set Flaps Visible Multicast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void JustAttached(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.JustAttached // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Wobble(float Strength, bool MoveUpAndDown); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Wobble // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Bind to Movement Events(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Bind to Movement Events // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Unbind from Movement Events(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Unbind from Movement Events // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SetMatInt(struct AActor* Prop); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.SetMatInt // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetPopState_Server(enum class PopOutStates PopState); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.SetPopState_Server // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPopStateChanged(enum class PopOutStates PopState); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnPopStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ChangePopState(enum class PopOutStates PopState); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.ChangePopState // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Server_BlockPopOut(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Server_BlockPopOut // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void WeaponChangeClient(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.WeaponChangeClient // (Net|NetClient|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponChange(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnWeaponChange // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void MovementUpdated(float DeltaSeconds, struct FVector OldLocation, struct FVector OldVelocity); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.MovementUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OwningClient_ADS(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OwningClient_ADS // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Cleanup(struct AActor* DestroyedActor); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.Cleanup // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetPopState_Multicast(enum class PopOutStates PopState); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.SetPopState_Multicast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OpenFlaps_Multicast(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OpenFlaps_Multicast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FirePressed_Client(struct AFortWeapon* Weapon); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.FirePressed_Client // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FireReleased_Client(struct AFortWeapon* Weapon); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.FireReleased_Client // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StopFiring(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.StopFiring // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnGaveSneakySnowman_2(); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.OnGaveSneakySnowman_2 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Player_CoolCarpet(int32_t EntryPoint); // Function Athena_Player_CoolCarpet.Athena_Player_CoolCarpet_C.ExecuteUbergraph_Athena_Player_CoolCarpet // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

