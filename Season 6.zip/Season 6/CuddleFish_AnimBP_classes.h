// AnimBlueprintGeneratedClass CuddleFish_AnimBP.CuddleFish_AnimBP_C
// Size: 0xbd4 (Inherited: 0x2c0)
struct UCuddleFish_AnimBP_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x2f8(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // 0x340(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // 0x368(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // 0x390(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // 0x3b8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x3e0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x408(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x430(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x458(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0x480(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x500(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0x530(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x5b0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x5e0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x660(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x690(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x730(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x7b0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x830(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x860(0xb0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x910(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x9b0(0x80)
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace; // 0xa30(0x190)
	bool Jumped; // 0xbc0(0x01)
	bool HasAttached; // 0xbc1(0x01)
	bool Is Falling; // 0xbc2(0x01)
	bool Has Landed; // 0xbc3(0x01)
	bool IsThrowing; // 0xbc4(0x01)
	char UnknownData_BC5[0x3]; // 0xbc5(0x03)
	struct AActor* CuddleFishBP; // 0xbc8(0x08)
	float ThrowPitch; // 0xbd0(0x04)

	void AnimGraph(struct FPoseLink AnimGraph); // Function CuddleFish_AnimBP.CuddleFish_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CuddleFish_AnimBP_AnimGraphNode_TransitionResult_5701F9C347DEBB0E8ECBB1B9FF53BC44(); // Function CuddleFish_AnimBP.CuddleFish_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_CuddleFish_AnimBP_AnimGraphNode_TransitionResult_5701F9C347DEBB0E8ECBB1B9FF53BC44 // (BlueprintEvent) // @ game+0xbd830c
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function CuddleFish_AnimBP.CuddleFish_AnimBP_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CuddleFish_AnimBP(int32_t EntryPoint); // Function CuddleFish_AnimBP.CuddleFish_AnimBP_C.ExecuteUbergraph_CuddleFish_AnimBP // (Final|UbergraphFunction) // @ game+0xbd830c
};

