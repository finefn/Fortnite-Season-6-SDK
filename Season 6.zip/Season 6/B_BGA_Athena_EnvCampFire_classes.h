// BlueprintGeneratedClass B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C
// Size: 0xab8 (Inherited: 0x7d8)
struct AB_BGA_Athena_EnvCampFire_C : ABuildingGameplayActorCampFire {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7d8(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0x7e0(0x08)
	struct USphereComponent* Sphere; // 0x7e8(0x08)
	struct UStaticMeshComponent* FirePitEmpty; // 0x7f0(0x08)
	struct UStaticMeshComponent* Cylinder; // 0x7f8(0x08)
	struct UArrowComponent* FireLoc; // 0x800(0x08)
	struct UStaticMeshComponent* Wood; // 0x808(0x08)
	struct UStaticMeshComponent* Root; // 0x810(0x08)
	struct UFortCurieComponent* FortCurie; // 0x818(0x08)
	struct AFortPawn* InteractingPawn; // 0x820(0x08)
	bool BeenUsed; // 0x828(0x01)
	char UnknownData_829[0x3]; // 0x829(0x03)
	float DousedSmokeLife; // 0x82c(0x04)
	struct FScalableFloat Row_DousedSmokeLife; // 0x830(0x28)
	bool HotfixedEnabled; // 0x858(0x01)
	bool DestroyIfDisabled; // 0x859(0x01)
	bool Destroyed; // 0x85a(0x01)
	char UnknownData_85B[0x5]; // 0x85b(0x05)
	struct FScalableFloat Row_HotfixEnabled; // 0x860(0x28)
	struct FVector TraceOffset; // 0x888(0x0c)
	bool Season7Campfire; // 0x894(0x01)
	char UnknownData_895[0x3]; // 0x895(0x03)
	struct FGameplayTagContainer CustomSpecialS7Tags; // 0x898(0x20)
	float SpecialS7FireTime; // 0x8b8(0x04)
	char UnknownData_8BC[0x4]; // 0x8bc(0x04)
	struct FTimerHandle DousedSmokeWispTimer; // 0x8c0(0x08)
	struct UParticleSystem* S7SuccessEmitter; // 0x8c8(0x08)
	struct USoundBase* S7SuccessSound; // 0x8d0(0x08)
	bool BlockInteraction; // 0x8d8(0x01)
	char UnknownData_8D9[0x3]; // 0x8d9(0x03)
	int32_t LitRepBool; // 0x8dc(0x04)
	struct FGameplayTag DousedCue; // 0x8e0(0x08)
	struct FGameplayTag DeathCue; // 0x8e8(0x08)
	struct FScalableFloat Row_Light_Cost; // 0x8f0(0x28)
	struct FText Text_Light; // 0x918(0x18)
	struct FText Text_LightCost; // 0x930(0x18)
	struct FText Text_LightCostNeedMore; // 0x948(0x18)
	struct UFortWorldItemDefinition* Item_Wood; // 0x960(0x08)
	bool Stoked; // 0x968(0x01)
	char UnknownData_969[0x3]; // 0x969(0x03)
	struct FGameplayTag StokedCue; // 0x96c(0x08)
	char UnknownData_974[0x4]; // 0x974(0x04)
	struct FScalableFloat Row_Stoke_Cost; // 0x978(0x28)
	struct FScalableFloat Row_HotfixStokeEnabled; // 0x9a0(0x28)
	struct FText Text_StokeCostNeedMore; // 0x9c8(0x18)
	bool HasBeenLit; // 0x9e0(0x01)
	char UnknownData_9E1[0x7]; // 0x9e1(0x07)
	struct FScalableFloat Row_ReplaceCampfire; // 0x9e8(0x28)
	struct ABuildingActor* ActorToReplaceWith; // 0xa10(0x08)
	bool CurieActivated; // 0xa18(0x01)
	char UnknownData_A19[0x7]; // 0xa19(0x07)
	struct FScalableFloat FloodLevel; // 0xa20(0x28)
	float FloodHeightPerLevel; // 0xa48(0x04)
	float OceanHeight; // 0xa4c(0x04)
	struct TMap<struct AActor*, struct FCurieInteractHandle> InteractHandleMap; // 0xa50(0x50)
	struct FGameplayTag FireCue; // 0xaa0(0x08)
	struct UMaterialInstanceDynamic* WoodBurningMatInstance; // 0xaa8(0x08)
	float FX_WoodBurnAmount; // 0xab0(0x04)
	float FX_WoodBurnEmissive; // 0xab4(0x04)

	void DisableIfBelowFlood(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.DisableIfBelowFlood // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShouldPlayNativeCurieFX(enum class EFortCurieNativeFXType FXType, struct FFortNativeCurieFXResponse OutResponse); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.ShouldPlayNativeCurieFX // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void HasInfiniteResources(struct APawn* Pawn, bool HasInfiniteResources); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.HasInfiniteResources // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void OnRep_Stoked(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.OnRep_Stoked // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetFailedInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.BlueprintGetFailedInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	int32_t GetCostReActivate(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.GetCostReActivate // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void OnRep_LitRepBool(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.OnRep_LitRepBool // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_Destroyed(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.OnRep_Destroyed // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckIfUserIsSpecialS7(struct AFortPawn* PawnWhoLitFire, bool UserIsSpecial); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.CheckIfUserIsSpecialS7 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool RowToBool(struct FScalableFloat Input); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.RowToBool // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void SetSheetValues(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.SetSheetValues // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void OnReady_9F4554BE40FCB41157835B9AD897EE69(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.OnReady_9F4554BE40FCB41157835B9AD897EE69 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnCurieActive_A24E3C804D14344FC0E5E0B5CDB4FF55(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.OnCurieActive_A24E3C804D14344FC0E5E0B5CDB4FF55 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void Light(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.Light // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GoOut(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.GoOut // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Start(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.Start // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleBoundDestroyed(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.HandleBoundDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckDestroyDisabled(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.CheckDestroyDisabled // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpecialS7LightsFireAfterOut(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.SpecialS7LightsFireAfterOut // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void KillDouseSmokeWisp(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.KillDouseSmokeWisp // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Server_QuestObjectiveUpdated(struct AFortPlayerController* Controller, struct UFortQuestItemDefinition* QuestDef, struct FName BackendName, int32_t CompletionCount, bool ObjectiveCompleted, bool QuestCompleted); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.Server_QuestObjectiveUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleCharacterVariantTransition(struct AFortPawn* TransitioningPawn); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.HandleCharacterVariantTransition // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PayLightCost(struct AFortPawn* InteractingPawn); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.PayLightCost // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PayStokeCost(struct AFortPawn* InteractingPawn); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.PayStokeCost // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckReplaceCampfire(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.CheckReplaceCampfire // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Sphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Sphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void EndFireInteract(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.EndFireInteract // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementAttached_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.OnCurieElementAttached_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementDetached_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.OnCurieElementDetached_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void CheckInitialOverlappingActors(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.CheckInitialOverlappingActors // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Begin_Wood_Burn_FX(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.Begin_Wood_Burn_FX // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_2_OnLinkedActorDestroyed__DelegateSignature(); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_2_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_BGA_Athena_EnvCampFire(int32_t EntryPoint); // Function B_BGA_Athena_EnvCampFire.B_BGA_Athena_EnvCampFire_C.ExecuteUbergraph_B_BGA_Athena_EnvCampFire // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

