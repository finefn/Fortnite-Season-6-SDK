// Enum Concert.EConcertLogMessageAction
enum class EConcertLogMessageAction : uint8 {
	None,
	Send,
	Publish,
	Receive,
	Queue,
	Discard,
	Duplicate,
	TimeOut,
	Process,
	EndpointDiscovery,
	EndpointTimeOut,
	EndpointClosure,
	EConcertLogMessageAction_MAX,
};

// Enum Concert.EConcertServerFlags
enum class EConcertServerFlags : uint8 {
	None,
	IgnoreSessionRequirement,
	EConcertServerFlags_MAX,
};

// Enum Concert.EConcertSessionRepositoryMountResponseCode
enum class EConcertSessionRepositoryMountResponseCode : uint8 {
	None,
	Mounted,
	AlreadyMounted,
	NotFound,
	EConcertSessionRepositoryMountResponseCode_MAX,
};

// Enum Concert.EConcertSessionResponseCode
enum class EConcertSessionResponseCode : uint8 {
	Success,
	Failed,
	InvalidRequest,
	EConcertSessionResponseCode_MAX,
};

// Enum Concert.EConcertClientStatus
enum class EConcertClientStatus : uint8 {
	Connected,
	Disconnected,
	Updated,
	EConcertClientStatus_MAX,
};

// Enum Concert.EConcertConnectionResult
enum class EConcertConnectionResult : uint8 {
	None,
	ConnectionAccepted,
	ConnectionRefused,
	AlreadyConnected,
	EConcertConnectionResult_MAX,
};

// Enum Concert.EConcertConnectionStatus
enum class EConcertConnectionStatus : uint8 {
	Connecting,
	Connected,
	Disconnecting,
	Disconnected,
	EConcertConnectionStatus_MAX,
};

// Enum Concert.EConcertSourceValidationMode
enum class EConcertSourceValidationMode : uint8 {
	Hard,
	Soft,
	SoftAutoProceed,
	EConcertSourceValidationMode_MAX,
};

// ScriptStruct Concert.ConcertLog
// Size: 0x90 (Inherited: 0x00)
struct FConcertLog {
	uint64_t Frame; // 0x00(0x08)
	struct FGuid MessageID; // 0x08(0x10)
	uint16_t MessageOrderIndex; // 0x18(0x02)
	uint16_t ChannelId; // 0x1a(0x02)
	char UnknownData_1C[0x4]; // 0x1c(0x04)
	struct FDateTime Timestamp; // 0x20(0x08)
	enum class EConcertLogMessageAction MessageAction; // 0x28(0x01)
	char UnknownData_29[0x3]; // 0x29(0x03)
	struct FName MessageTypeName; // 0x2c(0x08)
	struct FGuid OriginEndpointId; // 0x34(0x10)
	struct FGuid DestinationEndpointId; // 0x44(0x10)
	struct FName CustomPayloadTypename; // 0x54(0x08)
	int32_t CustomPayloadUncompressedByteSize; // 0x5c(0x04)
	struct FString StringPayload; // 0x60(0x10)
	struct FConcertSessionSerializedPayload SerializedPayload; // 0x70(0x20)
};

// ScriptStruct Concert.ConcertSessionSerializedPayload
// Size: 0x20 (Inherited: 0x00)
struct FConcertSessionSerializedPayload {
	struct FName PayloadTypeName; // 0x00(0x08)
	int32_t UncompressedPayloadSize; // 0x08(0x04)
	char UnknownData_C[0x4]; // 0x0c(0x04)
	struct TArray<enum class None> CompressedPayload; // 0x10(0x10)
};

// ScriptStruct Concert.ConcertSessionSerializedCborPayload
// Size: 0x20 (Inherited: 0x00)
struct FConcertSessionSerializedCborPayload {
	struct FName PayloadTypeName; // 0x00(0x08)
	int32_t UncompressedPayloadSize; // 0x08(0x04)
	char UnknownData_C[0x4]; // 0x0c(0x04)
	struct TArray<enum class None> CompressedPayload; // 0x10(0x10)
};

// ScriptStruct Concert.ConcertSessionFilter
// Size: 0x38 (Inherited: 0x00)
struct FConcertSessionFilter {
	int64_t ActivityIdLowerBound; // 0x00(0x08)
	int64_t ActivityIdUpperBound; // 0x08(0x08)
	struct TArray<int64_t> ActivityIdsToExclude; // 0x10(0x10)
	struct TArray<int64_t> ActivityIdsToInclude; // 0x20(0x10)
	bool bOnlyLiveData; // 0x30(0x01)
	bool bMetaDataOnly; // 0x31(0x01)
	bool bIncludeIgnoredActivities; // 0x32(0x01)
	char UnknownData_33[0x5]; // 0x33(0x05)
};

// ScriptStruct Concert.ConcertSessionInfo
// Size: 0xa8 (Inherited: 0x00)
struct FConcertSessionInfo {
	struct FGuid ServerInstanceId; // 0x00(0x10)
	struct FGuid ServerEndpointId; // 0x10(0x10)
	struct FGuid OwnerInstanceId; // 0x20(0x10)
	struct FGuid SessionId; // 0x30(0x10)
	struct FString SessionName; // 0x40(0x10)
	struct FString OwnerUserName; // 0x50(0x10)
	struct FString OwnerDeviceName; // 0x60(0x10)
	struct FConcertSessionSettings Settings; // 0x70(0x28)
	struct TArray<struct FConcertSessionVersionInfo> VersionInfos; // 0x98(0x10)
};

// ScriptStruct Concert.ConcertSessionVersionInfo
// Size: 0x28 (Inherited: 0x00)
struct FConcertSessionVersionInfo {
	struct FConcertFileVersionInfo FileVersion; // 0x00(0x08)
	struct FConcertEngineVersionInfo EngineVersion; // 0x08(0x0c)
	char UnknownData_14[0x4]; // 0x14(0x04)
	struct TArray<struct FConcertCustomVersionInfo> CustomVersions; // 0x18(0x10)
};

// ScriptStruct Concert.ConcertCustomVersionInfo
// Size: 0x1c (Inherited: 0x00)
struct FConcertCustomVersionInfo {
	struct FName FriendlyName; // 0x00(0x08)
	struct FGuid Key; // 0x08(0x10)
	int32_t Version; // 0x18(0x04)
};

// ScriptStruct Concert.ConcertEngineVersionInfo
// Size: 0x0c (Inherited: 0x00)
struct FConcertEngineVersionInfo {
	uint16_t Major; // 0x00(0x02)
	uint16_t Minor; // 0x02(0x02)
	uint16_t Patch; // 0x04(0x02)
	char UnknownData_6[0x2]; // 0x06(0x02)
	uint32_t Changelist; // 0x08(0x04)
};

// ScriptStruct Concert.ConcertFileVersionInfo
// Size: 0x08 (Inherited: 0x00)
struct FConcertFileVersionInfo {
	int32_t FileVersionUE4; // 0x00(0x04)
	int32_t FileVersionLicenseeUE4; // 0x04(0x04)
};

// ScriptStruct Concert.ConcertSessionSettings
// Size: 0x28 (Inherited: 0x00)
struct FConcertSessionSettings {
	struct FString ProjectName; // 0x00(0x10)
	uint32_t BaseRevision; // 0x10(0x04)
	char UnknownData_14[0x4]; // 0x14(0x04)
	struct FString ArchiveNameOverride; // 0x18(0x10)
};

// ScriptStruct Concert.ConcertSessionClientInfo
// Size: 0xc8 (Inherited: 0x00)
struct FConcertSessionClientInfo {
	struct FGuid ClientEndpointId; // 0x00(0x10)
	struct FConcertClientInfo ClientInfo; // 0x10(0xb8)
};

// ScriptStruct Concert.ConcertClientInfo
// Size: 0xb8 (Inherited: 0x00)
struct FConcertClientInfo {
	struct FConcertInstanceInfo InstanceInfo; // 0x00(0x30)
	struct FString DeviceName; // 0x30(0x10)
	struct FString PlatformName; // 0x40(0x10)
	struct FString UserName; // 0x50(0x10)
	struct FString DisplayName; // 0x60(0x10)
	struct FLinearColor AvatarColor; // 0x70(0x10)
	struct FString DesktopAvatarActorClass; // 0x80(0x10)
	struct FString VRAvatarActorClass; // 0x90(0x10)
	struct TArray<struct FName> Tags; // 0xa0(0x10)
	bool bHasEditorData; // 0xb0(0x01)
	bool bRequiresCookedData; // 0xb1(0x01)
	char UnknownData_B2[0x6]; // 0xb2(0x06)
};

// ScriptStruct Concert.ConcertInstanceInfo
// Size: 0x30 (Inherited: 0x00)
struct FConcertInstanceInfo {
	struct FGuid InstanceID; // 0x00(0x10)
	struct FString InstanceName; // 0x10(0x10)
	struct FString InstanceType; // 0x20(0x10)
};

// ScriptStruct Concert.ConcertServerInfo
// Size: 0x58 (Inherited: 0x00)
struct FConcertServerInfo {
	struct FGuid AdminEndpointId; // 0x00(0x10)
	struct FString ServerName; // 0x10(0x10)
	struct FConcertInstanceInfo InstanceInfo; // 0x20(0x30)
	enum class EConcertServerFlags ServerFlags; // 0x50(0x01)
	char UnknownData_51[0x7]; // 0x51(0x07)
};

// ScriptStruct Concert.ConcertSession_CustomResponse
// Size: 0x80 (Inherited: 0x60)
struct FConcertSession_CustomResponse : FConcertResponseData {
	struct FConcertSessionSerializedPayload SerializedPayload; // 0x60(0x20)
};

// ScriptStruct Concert.ConcertSession_CustomRequest
// Size: 0x70 (Inherited: 0x30)
struct FConcertSession_CustomRequest : FConcertRequestData {
	struct FGuid SourceEndpointId; // 0x30(0x10)
	struct FGuid DestinationEndpointId; // 0x40(0x10)
	struct FConcertSessionSerializedPayload SerializedPayload; // 0x50(0x20)
};

// ScriptStruct Concert.ConcertSession_CustomEvent
// Size: 0x70 (Inherited: 0x30)
struct FConcertSession_CustomEvent : FConcertEventData {
	struct FGuid SourceEndpointId; // 0x30(0x10)
	struct TArray<struct FGuid> DestinationEndpointIds; // 0x40(0x10)
	struct FConcertSessionSerializedPayload SerializedPayload; // 0x50(0x20)
};

// ScriptStruct Concert.ConcertSession_SessionRenamedEvent
// Size: 0x40 (Inherited: 0x30)
struct FConcertSession_SessionRenamedEvent : FConcertEventData {
	struct FString NewName; // 0x30(0x10)
};

// ScriptStruct Concert.ConcertSession_ClientListUpdatedEvent
// Size: 0x40 (Inherited: 0x30)
struct FConcertSession_ClientListUpdatedEvent : FConcertEventData {
	struct TArray<struct FConcertSessionClientInfo> SessionClients; // 0x30(0x10)
};

// ScriptStruct Concert.ConcertSession_UpdateClientInfoEvent
// Size: 0xf8 (Inherited: 0x30)
struct FConcertSession_UpdateClientInfoEvent : FConcertEventData {
	struct FConcertSessionClientInfo SessionClient; // 0x30(0xc8)
};

// ScriptStruct Concert.ConcertSession_LeaveSessionEvent
// Size: 0x40 (Inherited: 0x30)
struct FConcertSession_LeaveSessionEvent : FConcertEventData {
	struct FGuid SessionServerEndpointId; // 0x30(0x10)
};

// ScriptStruct Concert.ConcertSession_JoinSessionResultEvent
// Size: 0x58 (Inherited: 0x30)
struct FConcertSession_JoinSessionResultEvent : FConcertEndpointDiscoveryEvent {
	struct FGuid SessionServerEndpointId; // 0x30(0x10)
	enum class EConcertConnectionResult ConnectionResult; // 0x40(0x01)
	char UnknownData_41[0x7]; // 0x41(0x07)
	struct TArray<struct FConcertSessionClientInfo> SessionClients; // 0x48(0x10)
};

// ScriptStruct Concert.ConcertSession_DiscoverAndJoinSessionEvent
// Size: 0xf8 (Inherited: 0x30)
struct FConcertSession_DiscoverAndJoinSessionEvent : FConcertEndpointDiscoveryEvent {
	struct FGuid SessionServerEndpointId; // 0x30(0x10)
	struct FConcertClientInfo ClientInfo; // 0x40(0xb8)
};

// ScriptStruct Concert.ConcertAdmin_GetSessionActivitiesResponse
// Size: 0xc0 (Inherited: 0x60)
struct FConcertAdmin_GetSessionActivitiesResponse : FConcertResponseData {
	struct TArray<struct FConcertSessionSerializedPayload> Activities; // 0x60(0x10)
	struct TMap<struct FGuid, struct FConcertClientInfo> EndpointClientInfoMap; // 0x70(0x50)
};

// ScriptStruct Concert.ConcertAdmin_GetSessionActivitiesRequest
// Size: 0x58 (Inherited: 0x30)
struct FConcertAdmin_GetSessionActivitiesRequest : FConcertRequestData {
	struct FGuid SessionId; // 0x30(0x10)
	int64_t FromActivityId; // 0x40(0x08)
	int64_t ActivityCount; // 0x48(0x08)
	bool bIncludeDetails; // 0x50(0x01)
	char UnknownData_51[0x7]; // 0x51(0x07)
};

// ScriptStruct Concert.ConcertAdmin_GetSessionClientsResponse
// Size: 0x70 (Inherited: 0x60)
struct FConcertAdmin_GetSessionClientsResponse : FConcertResponseData {
	struct TArray<struct FConcertSessionClientInfo> SessionClients; // 0x60(0x10)
};

// ScriptStruct Concert.ConcertAdmin_GetSessionClientsRequest
// Size: 0x40 (Inherited: 0x30)
struct FConcertAdmin_GetSessionClientsRequest : FConcertRequestData {
	struct FGuid SessionId; // 0x30(0x10)
};

// ScriptStruct Concert.ConcertAdmin_DeleteSessionResponse
// Size: 0x80 (Inherited: 0x60)
struct FConcertAdmin_DeleteSessionResponse : FConcertResponseData {
	struct FGuid SessionId; // 0x60(0x10)
	struct FString SessionName; // 0x70(0x10)
};

// ScriptStruct Concert.ConcertAdmin_DeleteSessionRequest
// Size: 0x60 (Inherited: 0x30)
struct FConcertAdmin_DeleteSessionRequest : FConcertRequestData {
	struct FGuid SessionId; // 0x30(0x10)
	struct FString UserName; // 0x40(0x10)
	struct FString DeviceName; // 0x50(0x10)
};

// ScriptStruct Concert.ConcertAdmin_RenameSessionResponse
// Size: 0x80 (Inherited: 0x60)
struct FConcertAdmin_RenameSessionResponse : FConcertResponseData {
	struct FGuid SessionId; // 0x60(0x10)
	struct FString OldName; // 0x70(0x10)
};

// ScriptStruct Concert.ConcertAdmin_RenameSessionRequest
// Size: 0x70 (Inherited: 0x30)
struct FConcertAdmin_RenameSessionRequest : FConcertRequestData {
	struct FGuid SessionId; // 0x30(0x10)
	struct FString NewName; // 0x40(0x10)
	struct FString UserName; // 0x50(0x10)
	struct FString DeviceName; // 0x60(0x10)
};

// ScriptStruct Concert.ConcertAdmin_ArchiveSessionResponse
// Size: 0xa0 (Inherited: 0x60)
struct FConcertAdmin_ArchiveSessionResponse : FConcertResponseData {
	struct FGuid SessionId; // 0x60(0x10)
	struct FString SessionName; // 0x70(0x10)
	struct FGuid ArchiveId; // 0x80(0x10)
	struct FString ArchiveName; // 0x90(0x10)
};

// ScriptStruct Concert.ConcertAdmin_ArchiveSessionRequest
// Size: 0xa8 (Inherited: 0x30)
struct FConcertAdmin_ArchiveSessionRequest : FConcertRequestData {
	struct FGuid SessionId; // 0x30(0x10)
	struct FString ArchiveNameOverride; // 0x40(0x10)
	struct FString UserName; // 0x50(0x10)
	struct FString DeviceName; // 0x60(0x10)
	struct FConcertSessionFilter SessionFilter; // 0x70(0x38)
};

// ScriptStruct Concert.ConcertAdmin_SessionInfoResponse
// Size: 0x108 (Inherited: 0x60)
struct FConcertAdmin_SessionInfoResponse : FConcertResponseData {
	struct FConcertSessionInfo SessionInfo; // 0x60(0xa8)
};

// ScriptStruct Concert.ConcertAdmin_CopySessionRequest
// Size: 0x198 (Inherited: 0x30)
struct FConcertAdmin_CopySessionRequest : FConcertRequestData {
	struct FGuid SessionId; // 0x30(0x10)
	struct FString SessionName; // 0x40(0x10)
	struct FConcertClientInfo OwnerClientInfo; // 0x50(0xb8)
	struct FConcertSessionSettings SessionSettings; // 0x108(0x28)
	struct FConcertSessionVersionInfo VersionInfo; // 0x130(0x28)
	struct FConcertSessionFilter SessionFilter; // 0x158(0x38)
	char UnknownData_190[0x8]; // 0x190(0x08)
};

// ScriptStruct Concert.ConcertAdmin_FindSessionRequest
// Size: 0x148 (Inherited: 0x30)
struct FConcertAdmin_FindSessionRequest : FConcertRequestData {
	struct FGuid SessionId; // 0x30(0x10)
	struct FConcertClientInfo OwnerClientInfo; // 0x40(0xb8)
	struct FConcertSessionSettings SessionSettings; // 0xf8(0x28)
	struct FConcertSessionVersionInfo VersionInfo; // 0x120(0x28)
};

// ScriptStruct Concert.ConcertAdmin_CreateSessionRequest
// Size: 0x148 (Inherited: 0x30)
struct FConcertAdmin_CreateSessionRequest : FConcertRequestData {
	struct FString SessionName; // 0x30(0x10)
	struct FConcertClientInfo OwnerClientInfo; // 0x40(0xb8)
	struct FConcertSessionSettings SessionSettings; // 0xf8(0x28)
	struct FConcertSessionVersionInfo VersionInfo; // 0x120(0x28)
};

// ScriptStruct Concert.ConcertAdmin_GetSessionsResponse
// Size: 0x70 (Inherited: 0x60)
struct FConcertAdmin_GetSessionsResponse : FConcertResponseData {
	struct TArray<struct FConcertSessionInfo> Sessions; // 0x60(0x10)
};

// ScriptStruct Concert.ConcertAdmin_GetArchivedSessionsRequest
// Size: 0x30 (Inherited: 0x30)
struct FConcertAdmin_GetArchivedSessionsRequest : FConcertRequestData {
};

// ScriptStruct Concert.ConcertAdmin_GetLiveSessionsRequest
// Size: 0x30 (Inherited: 0x30)
struct FConcertAdmin_GetLiveSessionsRequest : FConcertRequestData {
};

// ScriptStruct Concert.ConcertAdmin_GetAllSessionsResponse
// Size: 0x80 (Inherited: 0x60)
struct FConcertAdmin_GetAllSessionsResponse : FConcertResponseData {
	struct TArray<struct FConcertSessionInfo> LiveSessions; // 0x60(0x10)
	struct TArray<struct FConcertSessionInfo> ArchivedSessions; // 0x70(0x10)
};

// ScriptStruct Concert.ConcertAdmin_GetAllSessionsRequest
// Size: 0x30 (Inherited: 0x30)
struct FConcertAdmin_GetAllSessionsRequest : FConcertRequestData {
};

// ScriptStruct Concert.ConcertAdmin_DropSessionRepositoriesResponse
// Size: 0x70 (Inherited: 0x60)
struct FConcertAdmin_DropSessionRepositoriesResponse : FConcertResponseData {
	struct TArray<struct FGuid> DroppedRepositoryIds; // 0x60(0x10)
};

// ScriptStruct Concert.ConcertAdmin_DropSessionRepositoriesRequest
// Size: 0x40 (Inherited: 0x30)
struct FConcertAdmin_DropSessionRepositoriesRequest : FConcertRequestData {
	struct TArray<struct FGuid> RepositoryIds; // 0x30(0x10)
};

// ScriptStruct Concert.ConcertAdmin_GetSessionRepositoriesResponse
// Size: 0x70 (Inherited: 0x60)
struct FConcertAdmin_GetSessionRepositoriesResponse : FConcertResponseData {
	struct TArray<struct FConcertSessionRepositoryInfo> SessionRepositories; // 0x60(0x10)
};

// ScriptStruct Concert.ConcertSessionRepositoryInfo
// Size: 0x14 (Inherited: 0x00)
struct FConcertSessionRepositoryInfo {
	struct FGuid RepositoryId; // 0x00(0x10)
	bool bMounted; // 0x10(0x01)
	char UnknownData_11[0x3]; // 0x11(0x03)
};

// ScriptStruct Concert.ConcertAdmin_GetSessionRepositoriesRequest
// Size: 0x30 (Inherited: 0x30)
struct FConcertAdmin_GetSessionRepositoriesRequest : FConcertRequestData {
};

// ScriptStruct Concert.ConcertAdmin_MountSessionRepositoryResponse
// Size: 0x68 (Inherited: 0x60)
struct FConcertAdmin_MountSessionRepositoryResponse : FConcertResponseData {
	enum class EConcertSessionRepositoryMountResponseCode MountStatus; // 0x60(0x01)
	char UnknownData_61[0x7]; // 0x61(0x07)
};

// ScriptStruct Concert.ConcertAdmin_MountSessionRepositoryRequest
// Size: 0x58 (Inherited: 0x30)
struct FConcertAdmin_MountSessionRepositoryRequest : FConcertRequestData {
	struct FGuid RepositoryId; // 0x30(0x10)
	struct FString RepositoryRootDir; // 0x40(0x10)
	bool bAsServerDefault; // 0x50(0x01)
	bool bCreateIfNotExist; // 0x51(0x01)
	char UnknownData_52[0x6]; // 0x52(0x06)
};

// ScriptStruct Concert.ConcertAdmin_ServerDiscoveredEvent
// Size: 0x78 (Inherited: 0x30)
struct FConcertAdmin_ServerDiscoveredEvent : FConcertEndpointDiscoveryEvent {
	struct FString ServerName; // 0x30(0x10)
	struct FConcertInstanceInfo InstanceInfo; // 0x40(0x30)
	enum class EConcertServerFlags ServerFlags; // 0x70(0x01)
	char UnknownData_71[0x7]; // 0x71(0x07)
};

// ScriptStruct Concert.ConcertAdmin_DiscoverServersEvent
// Size: 0x60 (Inherited: 0x30)
struct FConcertAdmin_DiscoverServersEvent : FConcertEndpointDiscoveryEvent {
	struct FString RequiredRole; // 0x30(0x10)
	struct FString RequiredVersion; // 0x40(0x10)
	struct FString ClientAuthenticationKey; // 0x50(0x10)
};

// ScriptStruct Concert.ConcertServerSessionRepositoryDatabase
// Size: 0x10 (Inherited: 0x00)
struct FConcertServerSessionRepositoryDatabase {
	struct TArray<struct FConcertServerSessionRepository> Repositories; // 0x00(0x10)
};

// ScriptStruct Concert.ConcertServerSessionRepository
// Size: 0x48 (Inherited: 0x00)
struct FConcertServerSessionRepository {
	struct FGuid RepositoryId; // 0x00(0x10)
	struct FString RepositoryRootDir; // 0x10(0x10)
	struct FString WorkingDir; // 0x20(0x10)
	struct FString SavedDir; // 0x30(0x10)
	int32_t ProcessId; // 0x40(0x04)
	bool bMounted; // 0x44(0x01)
	char UnknownData_45[0x3]; // 0x45(0x03)
};

// ScriptStruct Concert.ConcertSourceControlSettings
// Size: 0x01 (Inherited: 0x00)
struct FConcertSourceControlSettings {
	enum class EConcertSourceValidationMode ValidationMode; // 0x00(0x01)
};

// ScriptStruct Concert.ConcertClientSettings
// Size: 0x80 (Inherited: 0x00)
struct FConcertClientSettings {
	struct FString DisplayName; // 0x00(0x10)
	struct FLinearColor AvatarColor; // 0x10(0x10)
	struct FSoftClassPath DesktopAvatarActorClass; // 0x20(0x18)
	struct FSoftClassPath VRAvatarActorClass; // 0x38(0x18)
	uint16_t ServerPort; // 0x50(0x02)
	char UnknownData_52[0x2]; // 0x52(0x02)
	int32_t DiscoveryTimeoutSeconds; // 0x54(0x04)
	int32_t SessionTickFrequencySeconds; // 0x58(0x04)
	float LatencyCompensationMs; // 0x5c(0x04)
	struct TArray<struct FName> Tags; // 0x60(0x10)
	struct FString ClientAuthenticationKey; // 0x70(0x10)
};

// ScriptStruct Concert.ConcertServerSettings
// Size: 0x08 (Inherited: 0x00)
struct FConcertServerSettings {
	bool bIgnoreSessionSettingsRestriction; // 0x00(0x01)
	char UnknownData_1[0x3]; // 0x01(0x03)
	int32_t SessionTickFrequencySeconds; // 0x04(0x04)
};

