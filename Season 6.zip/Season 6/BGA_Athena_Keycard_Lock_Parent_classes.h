// BlueprintGeneratedClass BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C
// Size: 0x999 (Inherited: 0x930)
struct ABGA_Athena_Keycard_Lock_Parent_C : ABGA_Athena_Lock_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x930(0x08)
	struct UChildActorComponent* ScannerScreenActor; // 0x938(0x08)
	struct FGameplayTag GC_Fail; // 0x940(0x08)
	struct FGameplayTag TagToCheck; // 0x948(0x08)
	struct FGameplayTag GC_Success; // 0x950(0x08)
	struct UFortWorldItemDefinition* KeyID; // 0x958(0x08)
	struct UMaterialInstanceDynamic* MIDI_ConsoleScreen; // 0x960(0x08)
	struct ABP_UI_ScannerScreen_C* ScannerScreen; // 0x968(0x08)
	struct FText PoINameText; // 0x970(0x18)
	struct FLinearColor OriginalEmissive; // 0x988(0x10)
	bool ScreenWidgetActive; // 0x998(0x01)

	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void LockCheck(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, bool CheckPassed); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.LockCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ApplyFailCheckEffect(); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.ApplyFailCheckEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CallOpenVault(); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.CallOpenVault // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ShowSuccessScreen(); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.ShowSuccessScreen // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShowFailScreen(); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.ShowFailScreen // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HideAndKill(); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.HideAndKill // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetLock(enum class Enum_Athena_Lock LockState); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.SetLock // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_Keycard_Lock_Parent(int32_t EntryPoint); // Function BGA_Athena_Keycard_Lock_Parent.BGA_Athena_Keycard_Lock_Parent_C.ExecuteUbergraph_BGA_Athena_Keycard_Lock_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

