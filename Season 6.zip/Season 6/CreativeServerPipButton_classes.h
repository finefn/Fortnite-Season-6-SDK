// WidgetBlueprintGeneratedClass CreativeServerPipButton.CreativeServerPipButton_C
// Size: 0xc28 (Inherited: 0xbf0)
struct UCreativeServerPipButton_C : UCommonButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbf0(0x08)
	struct UNamedSlot* ContentSlot; // 0xbf8(0x08)
	struct UCommonButtonStyle* ControllerInputStyle; // 0xc00(0x08)
	struct UCommonButtonStyle* MouseKeyboardStyle; // 0xc08(0x08)
	enum class EHorizontalAlignment InputActionHorizontalAlignment; // 0xc10(0x01)
	enum class EVerticalAlignment InputActionVerticalAlignment; // 0xc11(0x01)
	char UnknownData_C12[0x2]; // 0xc12(0x02)
	struct FVector2D InputActionRenderTranslation; // 0xc14(0x08)
	bool InputActionUseRimBrush; // 0xc1c(0x01)
	char UnknownData_C1D[0x3]; // 0xc1d(0x03)
	struct FVector2D InputActionRimBrushSize; // 0xc20(0x08)

	void UpdateInputActionLayout(); // Function CreativeServerPipButton.CreativeServerPipButton_C.UpdateInputActionLayout // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateStyle(bool bUsingGamepad); // Function CreativeServerPipButton.CreativeServerPipButton_C.UpdateStyle // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void InitializeButton(); // Function CreativeServerPipButton.CreativeServerPipButton_C.InitializeButton // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateTextAndStyle(); // Function CreativeServerPipButton.CreativeServerPipButton_C.UpdateTextAndStyle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function CreativeServerPipButton.CreativeServerPipButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CommonActionWidgetAction_K2Node_ComponentBoundEvent_0_OnInputMethodChanged__DelegateSignature(bool bUsingGamepad); // Function CreativeServerPipButton.CreativeServerPipButton_C.BndEvt__CommonActionWidgetAction_K2Node_ComponentBoundEvent_0_OnInputMethodChanged__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnTriggeredInputActionChanged(struct FDataTableRowHandle NewTriggeredAction); // Function CreativeServerPipButton.CreativeServerPipButton_C.OnTriggeredInputActionChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnActionProgress(float HeldPercent); // Function CreativeServerPipButton.CreativeServerPipButton_C.OnActionProgress // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnActionComplete(); // Function CreativeServerPipButton.CreativeServerPipButton_C.OnActionComplete // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function CreativeServerPipButton.CreativeServerPipButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function CreativeServerPipButton.CreativeServerPipButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function CreativeServerPipButton.CreativeServerPipButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CreativeServerPipButton(int32_t EntryPoint); // Function CreativeServerPipButton.CreativeServerPipButton_C.ExecuteUbergraph_CreativeServerPipButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

