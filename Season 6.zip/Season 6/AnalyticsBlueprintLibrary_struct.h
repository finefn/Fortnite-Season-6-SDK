// ScriptStruct AnalyticsBlueprintLibrary.AnalyticsEventAttr
// Size: 0x20 (Inherited: 0x00)
struct FAnalyticsEventAttr {
	struct FString Name; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

