// BlueprintGeneratedClass BP_Frontend_EventLevel_NavObject_VisibilityMannequin.BP_Frontend_EventLevel_NavObject_VisibilityMannequin_C
// Size: 0x4f0 (Inherited: 0x4d0)
struct ABP_Frontend_EventLevel_NavObject_VisibilityMannequin_C : ABP_Frontend_EventLevel_NavObject_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4d0(0x08)
	struct UFortNavigationVisibilityComponent* FortNavigationVisibility; // 0x4d8(0x08)
	struct UChildActorComponent* Mannequin; // 0x4e0(0x08)
	struct FTimerHandle VisTimerHandle; // 0x4e8(0x08)

	void ReceiveBeginPlay(); // Function BP_Frontend_EventLevel_NavObject_VisibilityMannequin.BP_Frontend_EventLevel_NavObject_VisibilityMannequin_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortNavigationVisibility_K2Node_ComponentBoundEvent_0_SimpleVisibilityResponseDelegate__DelegateSignature(); // Function BP_Frontend_EventLevel_NavObject_VisibilityMannequin.BP_Frontend_EventLevel_NavObject_VisibilityMannequin_C.BndEvt__FortNavigationVisibility_K2Node_ComponentBoundEvent_0_SimpleVisibilityResponseDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortNavigationVisibility_K2Node_ComponentBoundEvent_1_SimpleVisibilityResponseDelegate__DelegateSignature(); // Function BP_Frontend_EventLevel_NavObject_VisibilityMannequin.BP_Frontend_EventLevel_NavObject_VisibilityMannequin_C.BndEvt__FortNavigationVisibility_K2Node_ComponentBoundEvent_1_SimpleVisibilityResponseDelegate__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void HideMannequin(); // Function BP_Frontend_EventLevel_NavObject_VisibilityMannequin.BP_Frontend_EventLevel_NavObject_VisibilityMannequin_C.HideMannequin // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShowMannequin(); // Function BP_Frontend_EventLevel_NavObject_VisibilityMannequin.BP_Frontend_EventLevel_NavObject_VisibilityMannequin_C.ShowMannequin // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ClearVisTimer(); // Function BP_Frontend_EventLevel_NavObject_VisibilityMannequin.BP_Frontend_EventLevel_NavObject_VisibilityMannequin_C.ClearVisTimer // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_Frontend_EventLevel_NavObject_VisibilityMannequin(int32_t EntryPoint); // Function BP_Frontend_EventLevel_NavObject_VisibilityMannequin.BP_Frontend_EventLevel_NavObject_VisibilityMannequin_C.ExecuteUbergraph_BP_Frontend_EventLevel_NavObject_VisibilityMannequin // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

