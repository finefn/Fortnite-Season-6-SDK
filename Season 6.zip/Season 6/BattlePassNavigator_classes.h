// WidgetBlueprintGeneratedClass BattlePassNavigator.BattlePassNavigator_C
// Size: 0x350 (Inherited: 0x320)
struct UBattlePassNavigator_C : UBattlePassNavigator {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x320(0x08)
	struct UWidgetAnimation* TabBackward; // 0x328(0x08)
	struct UWidgetAnimation* TabForward; // 0x330(0x08)
	struct UCommonActionWidget* NextTabAction; // 0x338(0x08)
	struct UCommonActionWidget* PreviousTabAction; // 0x340(0x08)
	struct USafeZone* SZNavigator; // 0x348(0x08)

	void OnTabChanged(bool bIsForwardChange); // Function BattlePassNavigator.BattlePassNavigator_C.OnTabChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BattlePassNavigator(int32_t EntryPoint); // Function BattlePassNavigator.BattlePassNavigator_C.ExecuteUbergraph_BattlePassNavigator // (Final|UbergraphFunction) // @ game+0xbd830c
};

