// WidgetBlueprintGeneratedClass AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C
// Size: 0x591 (Inherited: 0x4b0)
struct UAthenaLobbyMatchmakingPlay_C : UFortAthenaMatchmakingWidgetLegacy {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b0(0x08)
	struct UWidgetAnimation* ShowMatchmakingDetails; // 0x4b8(0x08)
	struct UWidgetAnimation* NewModeViolation; // 0x4c0(0x08)
	struct UAthenaGenericLobbyViolator_C* AthenaGenericLobbyViolator; // 0x4c8(0x08)
	struct UCommonBorder* Border_BasePanel; // 0x4d0(0x08)
	struct UHorizontalBox* Box_LimitedMatchmaking; // 0x4d8(0x08)
	struct UIconTextButton_C* DebugCreativeServerSelect; // 0x4e0(0x08)
	struct UImage* MatchmakingSpinner; // 0x4e8(0x08)
	struct UCommonBorder* NewModeBorder; // 0x4f0(0x08)
	struct UShowdownLobbyViolator_C* ShowdownLobbyViolator; // 0x4f8(0x08)
	struct UCommonTextBlock* Text_FillStatus; // 0x500(0x08)
	struct UCommonTextBlock* Text_ModeTitle; // 0x508(0x08)
	struct UOverlay* ViolatorContent; // 0x510(0x08)
	struct UWidgetSwitcher* ViolatorSwitcher; // 0x518(0x08)
	struct FMulticastInlineDelegate PlaylistsUpdated; // 0x520(0x10)
	struct FTimerHandle ShowNewPlaylistTimer; // 0x530(0x08)
	struct FMulticastInlineDelegate OnPlaylistChanged; // 0x538(0x10)
	struct USoundBase* MatchmakingSucceededSound; // 0x548(0x08)
	SoftClassProperty CreativeOptionsSoftClass; // 0x550(0x28)
	struct UUserWidget* CreativeOptionsClass; // 0x578(0x08)
	bool SquadFill; // 0x580(0x01)
	char UnknownData_581[0x7]; // 0x581(0x07)
	struct UFortPlaylistAthena* PlaylistData; // 0x588(0x08)
	bool IsShowingMatchmakingDetails; // 0x590(0x01)

	void SetBasePanelColor(struct FLinearColor NewColor); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.SetBasePanelColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void RefreshFillText(); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.RefreshFillText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_7F9C59BE40E65C1C31B0EB98786CDA43(struct UObject* Loaded); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnLoaded_7F9C59BE40E65C1C31B0EB98786CDA43 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnAvailablePlaylistsUpdated(); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnAvailablePlaylistsUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnSetPlayButtonText(struct FText PlayButtonText); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnSetPlayButtonText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnSetCancelButtonText(struct FText CancelButtonText); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnSetCancelButtonText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void PlaylistChanged(struct FPlaylistFrontEndData NewPlaylist, struct FText PlaylistCMSOverrideName, enum class EFortLobbyType LobbyType); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.PlaylistChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void SetSquadFillText(bool InCurrentSquadFill); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.SetSquadFillText // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnNewModeViolatorUpdated(bool bShouldShow); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnNewModeViolatorUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void UpdateCustomViolatorText(struct FText ModeName, struct FText SubText); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.UpdateCustomViolatorText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Animate(); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.Animate // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnMatchmakingFinishedBlueprint(bool bSuccess, struct UFortPlaylistAthena* Playlist); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnMatchmakingFinishedBlueprint // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__PlayButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.BndEvt__PlayButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnInitialized(); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnCrossplayPreferencesChanged(bool IsCrossplayEnabled); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnCrossplayPreferencesChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShouldShowMatchmakingDetails(bool bShow); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.ShouldShowMatchmakingDetails // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaLobbyMatchmakingPlay(int32_t EntryPoint); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.ExecuteUbergraph_AthenaLobbyMatchmakingPlay // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void OnPlaylistChanged__DelegateSignature(struct FPlaylistFrontEndData Playlist Data, struct FText Playlist CMS Override, enum class EFortLobbyType Lobby Type); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.OnPlaylistChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlaylistsUpdated__DelegateSignature(); // Function AthenaLobbyMatchmakingPlay.AthenaLobbyMatchmakingPlay_C.PlaylistsUpdated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

