// BlueprintGeneratedClass BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C
// Size: 0xda8 (Inherited: 0xc58)
struct ABGA_Athena_FlopperSpawn_World_C : ABGA_Athena_FlopperSpawn_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc58(0x08)
	struct UAudioComponent* Audio_FlopperLoop; // 0xc60(0x08)
	struct UNiagaraComponent* NS_Flopper_Spot; // 0xc68(0x08)
	float Time_Interval; // 0xc70(0x04)
	float OffsetDistance; // 0xc74(0x04)
	float TimeIntervalOffset; // 0xc78(0x04)
	char UnknownData_C7C[0x4]; // 0xc7c(0x04)
	struct UNiagaraSystem* NS_FX_Jump; // 0xc80(0x08)
	struct UParticleSystem* FX_Jump; // 0xc88(0x08)
	struct FVector TraceOffsetAmount; // 0xc90(0x0c)
	char UnknownData_C9C[0x4]; // 0xc9c(0x04)
	struct AFortWaterBodyActor* FortWaterBody; // 0xca0(0x08)
	struct FVector WaterPlaneOffset; // 0xca8(0x0c)
	char UnknownData_CB4[0x4]; // 0xcb4(0x04)
	struct USoundBase* Sound_AmbientFishFlop; // 0xcb8(0x08)
	struct FVector ExplosionItemSpawnOffset; // 0xcc0(0x0c)
	char UnknownData_CCC[0x4]; // 0xccc(0x04)
	struct FGameplayTagContainer T_FlopperSpawn; // 0xcd0(0x20)
	float MinDistanceToExplosion; // 0xcf0(0x04)
	char UnknownData_CF4[0x4]; // 0xcf4(0x04)
	struct TMap<struct FGameplayTag, struct FName> MAP_TagToLootExplode; // 0xcf8(0x50)
	struct FName ExplodeItemsToDrop; // 0xd48(0x08)
	int32_t ExplodeRolls; // 0xd50(0x04)
	struct FVector WaterNormalHit; // 0xd54(0x0c)
	bool bHasWrittenAnalytic; // 0xd60(0x01)
	char UnknownData_D61[0x7]; // 0xd61(0x07)
	struct FGameplayTagContainer BattleLabProjectileTag; // 0xd68(0x20)
	struct FGameplayTagContainer ExplosionSpawnTag; // 0xd88(0x20)

	void GetLootTier(bool IsExplosion, bool IsProFishingRod, struct FName Output_Get); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.GetLootTier // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExplosionQuestProgress(struct AActor* Instigator, struct AActor* DamageCauser); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.ExplosionQuestProgress // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_FortWaterBody(); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.OnRep_FortWaterBody // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	float RandomTimeInterval(); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.RandomTimeInterval // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void SpawnJumpingFish(); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.SpawnJumpingFish // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void SpawnFromExplosion(struct AActor* Instigator, struct AActor* DamageCauser); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.SpawnFromExplosion // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_FlopperSpawn_World(int32_t EntryPoint); // Function BGA_Athena_FlopperSpawn_World.BGA_Athena_FlopperSpawn_World_C.ExecuteUbergraph_BGA_Athena_FlopperSpawn_World // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

