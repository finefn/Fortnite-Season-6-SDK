// BlueprintGeneratedClass B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C
// Size: 0xa88 (Inherited: 0x878)
struct AB_Prj_Athena_ShockGrenade_Parent_C : AFortProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x878(0x08)
	struct UAudioComponent* BeepTimer; // 0x880(0x08)
	struct UParticleSystemComponent* Fuse_Particle; // 0x888(0x08)
	struct USkeletalMeshComponent* ShockGrenadeMesh; // 0x890(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x898(0x08)
	struct UAudioComponent* GrenadeFuse_AudioComponent; // 0x8a0(0x08)
	struct UParticleSystemComponent* Effect_Distance; // 0x8a8(0x08)
	struct UParticleSystem* P_Explosion; // 0x8b0(0x08)
	struct USoundBase* Cue_DistantSound; // 0x8b8(0x08)
	struct USoundBase* Cue_CloseSound; // 0x8c0(0x08)
	struct USoundBase* Cue_GrenadeFuseSound; // 0x8c8(0x08)
	struct FVector HitLocation; // 0x8d0(0x0c)
	char UnknownData_8DC[0x4]; // 0x8dc(0x04)
	struct AFortPawn* Target; // 0x8e0(0x08)
	struct USoundBase* Cue_BeepSound; // 0x8e8(0x08)
	struct FVector HitNormal; // 0x8f0(0x0c)
	bool StuckVehicle; // 0x8fc(0x01)
	char UnknownData_8FD[0x3]; // 0x8fd(0x03)
	struct AEnemyPawn_Parent_Deimos_C* DeimosPawn; // 0x900(0x08)
	struct TArray<enum class EObjectTypeQuery> DestroyObjectTypes; // 0x908(0x10)
	struct FScalableFloat DestroyDistance; // 0x918(0x28)
	struct FScalableFloat ShouldDestroy; // 0x940(0x28)
	struct FScalableFloat LaunchVelocity; // 0x968(0x28)
	struct FScalableFloat ExplodeDelay; // 0x990(0x28)
	struct FScalableFloat EnemiesTakeFallDamage; // 0x9b8(0x28)
	struct FScalableFloat AllPlayersTakeFallDamage; // 0x9e0(0x28)
	struct USoundBase* Cue_StopSound; // 0xa08(0x08)
	struct FName ChestLootTableName; // 0xa10(0x08)
	struct FGameplayTag FeedbackCue; // 0xa18(0x08)
	bool HitWater; // 0xa20(0x01)
	char UnknownData_A21[0x7]; // 0xa21(0x07)
	struct USoundBase* Water Debris Explosion; // 0xa28(0x08)
	struct UParticleSystem* P_WaterExplosion; // 0xa30(0x08)
	struct AFortAthenaVehicle* TargetVehicle; // 0xa38(0x08)
	struct UGameplayEffect* GE_KnockbackStatus; // 0xa40(0x08)
	struct FGameplayTag Tag_BuildingPhysocs; // 0xa48(0x08)
	struct FScalableFloat Row_PhysicsObjectImpulseMult; // 0xa50(0x28)
	struct UNiagaraSystem* NS_Explosion; // 0xa78(0x08)
	struct UNiagaraSystem* NS_WaterExplosion; // 0xa80(0x08)

	void GetLaunchOriginPoint(struct FVector HitLocation); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.GetLaunchOriginPoint // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	struct FVector CalculateLaunchVel(struct AActor* Target); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.CalculateLaunchVel // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void Handle Pawn Detach RC(); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.Handle Pawn Detach RC // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnStop(struct FHitResult Hit); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Stop_Rotation(); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.Stop_Rotation // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void LaunchDeimos(); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.LaunchDeimos // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnTouched(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FHitResult HitResult, bool bIsOverlap); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.OnTouched // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ProjectileMovementComponent_K2Node_ComponentBoundEvent_1_OnProjectileBounceDelegate__DelegateSignature(struct FHitResult ImpactResult, struct FVector ImpactVelocity); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.BndEvt__ProjectileMovementComponent_K2Node_ComponentBoundEvent_1_OnProjectileBounceDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_2_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_2_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void LaunchPlayerVehicle(); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.LaunchPlayerVehicle // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void LaunchBuldingActors(struct AActor* Actor); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.LaunchBuldingActors // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void QuestSendShockwaveTag(); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.QuestSendShockwaveTag // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Athena_ShockGrenade_Parent(int32_t EntryPoint); // Function B_Prj_Athena_ShockGrenade_Parent.B_Prj_Athena_ShockGrenade_Parent_C.ExecuteUbergraph_B_Prj_Athena_ShockGrenade_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

