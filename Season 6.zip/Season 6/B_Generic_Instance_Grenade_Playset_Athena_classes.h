// BlueprintGeneratedClass B_Generic_Instance_Grenade_Playset_Athena.B_Generic_Instance_Grenade_Playset_Athena_C
// Size: 0xd68 (Inherited: 0xd60)
struct AB_Generic_Instance_Grenade_Playset_Athena_C : AB_Grenade_Playset_Athena_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd60(0x08)

	void ReceiveBeginPlay(); // Function B_Generic_Instance_Grenade_Playset_Athena.B_Generic_Instance_Grenade_Playset_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void K2_OnUnEquip(); // Function B_Generic_Instance_Grenade_Playset_Athena.B_Generic_Instance_Grenade_Playset_Athena_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_Generic_Instance_Grenade_Playset_Athena.B_Generic_Instance_Grenade_Playset_Athena_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Generic_Instance_Grenade_Playset_Athena(int32_t EntryPoint); // Function B_Generic_Instance_Grenade_Playset_Athena.B_Generic_Instance_Grenade_Playset_Athena_C.ExecuteUbergraph_B_Generic_Instance_Grenade_Playset_Athena // (Final|UbergraphFunction) // @ game+0xbd830c
};

