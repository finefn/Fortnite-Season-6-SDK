// BlueprintGeneratedClass BGA_IslandPortal.BGA_IslandPortal_C
// Size: 0xfda (Inherited: 0xb18)
struct ABGA_IslandPortal_C : AFortAthenaCreativePortal {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb18(0x08)
	struct USphereComponent* CodeScreenLookAtSphere; // 0xb20(0x08)
	struct USphereComponent* PortalLookAtSphere; // 0xb28(0x08)
	struct USphereComponent* HUD Visibility Volume; // 0xb30(0x08)
	struct UStaticMeshComponent* Code Entry Screen; // 0xb38(0x08)
	struct UStaticMeshComponent* Base Mesh; // 0xb40(0x08)
	struct USceneComponent* PortalHUDDetails_PointerOrigin; // 0xb48(0x08)
	struct UWidgetComponent* UI_PortalInfoPlate; // 0xb50(0x08)
	struct UStaticMeshComponent* ThumbnailPlane; // 0xb58(0x08)
	struct UParticleSystemComponent* P_Rift_Idle_Loop_Gold; // 0xb60(0x08)
	struct UPostProcessComponent* RiftPostProcess; // 0xb68(0x08)
	struct USphereComponent* PostProcessRadius; // 0xb70(0x08)
	struct UParticleSystemComponent* P_RiftClosingUp; // 0xb78(0x08)
	struct UParticleSystemComponent* P_Rift_Idle_Loop; // 0xb80(0x08)
	struct UCapsuleComponent* OverlapCapsule; // 0xb88(0x08)
	struct UCapsuleComponent* Capsule; // 0xb90(0x08)
	struct UStaticMeshComponent* SM_Rift; // 0xb98(0x08)
	struct UAudioComponent* Audio_Looping; // 0xba0(0x08)
	float Timeline_0_Open_D988993744202060C85FC18A08065960; // 0xba8(0x04)
	enum class ETimelineDirection Timeline_0__Direction_D988993744202060C85FC18A08065960; // 0xbac(0x01)
	char UnknownData_BAD[0x3]; // 0xbad(0x03)
	struct UTimelineComponent* Timeline_1; // 0xbb0(0x08)
	float VectorScale_Open_7AB95DD3448038155AB954ABBF1B806E; // 0xbb8(0x04)
	enum class ETimelineDirection VectorScale__Direction_7AB95DD3448038155AB954ABBF1B806E; // 0xbbc(0x01)
	char UnknownData_BBD[0x3]; // 0xbbd(0x03)
	struct UTimelineComponent* VectorScale; // 0xbc0(0x08)
	struct UParticleSystem* DeathEffects; // 0xbc8(0x08)
	struct USoundBase* EnteredRift; // 0xbd0(0x08)
	struct USoundBase* RiftDestroyed; // 0xbd8(0x08)
	struct AFortPlayerPawn* PlayerPawn; // 0xbe0(0x08)
	struct UParticleSystem* EnterRift; // 0xbe8(0x08)
	struct AActor* VehicleActor; // 0xbf0(0x08)
	struct UAnimMontage* FallingAnimation; // 0xbf8(0x08)
	struct FScalableFloat TeleportHeight; // 0xc00(0x28)
	struct FScalableFloat HangTime; // 0xc28(0x28)
	float TeleportDelay; // 0xc50(0x04)
	char UnknownData_C54[0x4]; // 0xc54(0x04)
	struct TArray<struct AFortPlayerPawn*> PassengerArray; // 0xc58(0x10)
	struct UParticleSystem* CrackExitRift; // 0xc68(0x08)
	struct USoundBase* PlayerExitSkyCrack; // 0xc70(0x08)
	struct FVector ActorOriginalLocation; // 0xc78(0x0c)
	int32_t MaxSpawnHeightMultiplier; // 0xc84(0x04)
	struct UFortQuestItemDefinition* QuestItem; // 0xc88(0x08)
	struct FName ObjectiveBackendName; // 0xc90(0x08)
	struct UFortQuestItemDefinition* RiftPortalLocationsQuest; // 0xc98(0x08)
	bool CreativeMode; // 0xca0(0x01)
	char UnknownData_CA1[0x7]; // 0xca1(0x07)
	struct AActor* OverlapActor; // 0xca8(0x08)
	int32_t RiftLocationNum; // 0xcb0(0x04)
	struct FRotator ActorRotation; // 0xcb4(0x0c)
	struct FScalableFloat ShouldSpawnRift?; // 0xcc0(0x28)
	struct FScalableFloat TeleportExitDistance_1; // 0xce8(0x28)
	int32_t PortalCount; // 0xd10(0x04)
	char UnknownData_D14[0x4]; // 0xd14(0x04)
	struct FScalableFloat XPortalSeparation; // 0xd18(0x28)
	struct FScalableFloat StarterIslandTeleportHeight; // 0xd40(0x28)
	bool bCanPlayerInteract; // 0xd68(0x01)
	char UnknownData_D69[0x7]; // 0xd69(0x07)
	struct FScalableFloat YPortalSeparation; // 0xd70(0x28)
	struct AFortPlayerControllerAthena* PendingTeleport; // 0xd98(0x08)
	bool IsMyPortal; // 0xda0(0x01)
	char UnknownData_DA1[0x7]; // 0xda1(0x07)
	struct UParticleSystem* Enter_Rift_Gold; // 0xda8(0x08)
	struct ABP_PortalLightPillar_C* Beacon; // 0xdb0(0x08)
	struct FTimerHandle UIDistanceCheckTimer; // 0xdb8(0x08)
	float UIShowDistance; // 0xdc0(0x04)
	char UnknownData_DC4[0x4]; // 0xdc4(0x04)
	SoftClassProperty UI_InteractionDisplayWidgetSoftClass; // 0xdc8(0x28)
	SoftClassProperty UI_PortalInfoPlateSoftClass; // 0xdf0(0x28)
	struct FMulticastInlineDelegate UpdatePlayerName; // 0xe18(0x10)
	struct FMulticastInlineDelegate UpdatePlayerPop; // 0xe28(0x10)
	struct FMulticastInlineDelegate UpdateIslandName; // 0xe38(0x10)
	struct FMulticastInlineDelegate UpdatePortalUIVis; // 0xe48(0x10)
	SoftClassProperty UI_IslandSelectSoftClass; // 0xe58(0x28)
	struct UUserWidget* UI_IslandSelectClass; // 0xe80(0x08)
	bool StartSkydiving; // 0xe88(0x01)
	char UnknownData_E89[0x7]; // 0xe89(0x07)
	struct FMulticastInlineDelegate UpdateIsCuratedPortal; // 0xe90(0x10)
	SoftClassProperty UI_IslandCodeEntrySoftClass; // 0xea0(0x28)
	struct UUserWidget* UI_IslandCodeEntryClass; // 0xec8(0x08)
	struct FMulticastInlineDelegate UpdateDescription; // 0xed0(0x10)
	struct FMulticastInlineDelegate UpdateLinkCode; // 0xee0(0x10)
	bool bIsBeingDisplayed; // 0xef0(0x01)
	char UnknownData_EF1[0x3]; // 0xef1(0x03)
	float ThumbnailWorldSizeScale; // 0xef4(0x04)
	struct FLinearColor OwnedThumbnailColor; // 0xef8(0x10)
	struct FLinearColor UnownedThumbnailColor; // 0xf08(0x10)
	struct FText OverrideName; // 0xf18(0x18)
	bool bAlwaysDisplay; // 0xf30(0x01)
	char UnknownData_F31[0x7]; // 0xf31(0x07)
	struct FMulticastInlineDelegate IsBeingInteractedWith; // 0xf38(0x10)
	struct UUserWidget* DisplayedWidget; // 0xf48(0x08)
	struct FMulticastInlineDelegate CloseShownUI; // 0xf50(0x10)
	struct TArray<struct APawn*> LocalPawnsInRange; // 0xf60(0x10)
	float LookAtUpdateTimeSecs; // 0xf70(0x04)
	char UnknownData_F74[0x4]; // 0xf74(0x04)
	struct FTimerHandle LookAtCodeScreenHandle; // 0xf78(0x08)
	struct FLinearColor ScreenColorNotHighlighted; // 0xf80(0x10)
	struct FLinearColor ScreenColorCanUpdate; // 0xf90(0x10)
	struct FLinearColor ScreenColorLocked; // 0xfa0(0x10)
	struct FLinearColor ScreenColorDisabled; // 0xfb0(0x10)
	bool bUseCodeEntryScreen; // 0xfc0(0x01)
	bool bPlayerMustInteractToUsePortal; // 0xfc1(0x01)
	bool bEnableBaseAndCodeEntryInteractions; // 0xfc2(0x01)
	char UnknownData_FC3[0x5]; // 0xfc3(0x05)
	struct FMulticastInlineDelegate UpdateLocalPlayerLookingAtScreen; // 0xfc8(0x10)
	bool bLocalPlayerLookingAtScreen; // 0xfd8(0x01)
	bool bLocalPlayerLookingAtPortal; // 0xfd9(0x01)

	void MobileInteractIsValid(bool bIsValid); // Function BGA_IslandPortal.BGA_IslandPortal_C.MobileInteractIsValid // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	bool BlueprintDisplayMobileInteractPrompt(); // Function BGA_IslandPortal.BGA_IslandPortal_C.BlueprintDisplayMobileInteractPrompt // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintUseMobileHighlight(); // Function BGA_IslandPortal.BGA_IslandPortal_C.BlueprintUseMobileHighlight // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool IconPlacementNeedsUpdate(); // Function BGA_IslandPortal.BGA_IslandPortal_C.IconPlacementNeedsUpdate // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void GetIconPlacement(struct AActor* SelfActor, struct AActor* ViewingActor, struct FVector OutLocation, struct FVector OutExtents); // Function BGA_IslandPortal.BGA_IslandPortal_C.GetIconPlacement // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void CanModifyPortal(bool bCanModify); // Function BGA_IslandPortal.BGA_IslandPortal_C.CanModifyPortal // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void IsLookingAtSphere(struct USphereComponent* LookAtSphere, struct FVector Eyes View Point Location, struct FRotator Eyes View Point Rotation, bool bIsLookingAtSphere); // Function BGA_IslandPortal.BGA_IslandPortal_C.IsLookingAtSphere // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void DetermineWherePlayerIsLooking(struct APawn* Pawn, bool bIsLookingAtScreen, bool bIsLookingAtPortal); // Function BGA_IslandPortal.BGA_IslandPortal_C.DetermineWherePlayerIsLooking // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StartTeleportByInteractionOnServer(struct AActor* OverlapActor); // Function BGA_IslandPortal.BGA_IslandPortal_C.StartTeleportByInteractionOnServer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateInfoPlatePointer(); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateInfoPlatePointer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PortalUsesCodeScreen(bool bUsesCodeScreen); // Function BGA_IslandPortal.BGA_IslandPortal_C.PortalUsesCodeScreen // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void PortalTeleportsByInteraction(bool bRequiresInteraction); // Function BGA_IslandPortal.BGA_IslandPortal_C.PortalTeleportsByInteraction // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void StartTeleport(struct AActor* OverlapActor); // Function BGA_IslandPortal.BGA_IslandPortal_C.StartTeleport // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void LocalPlayerRangeCheck(struct AActor* OverlappingActor, bool bEnteredRange); // Function BGA_IslandPortal.BGA_IslandPortal_C.LocalPlayerRangeCheck // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void LocalPlayerExitedRange(struct APawn* LocalPawn); // Function BGA_IslandPortal.BGA_IslandPortal_C.LocalPlayerExitedRange // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void LocalPlayerEnteredRange(struct APawn* LocalPawn); // Function BGA_IslandPortal.BGA_IslandPortal_C.LocalPlayerEnteredRange // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateBaseVisibility(); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateBaseVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateCodeEntryVisibility(); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateCodeEntryVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateCodeEntryScreen(bool bForceScreenUpdate); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateCodeEntryScreen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void QueryPlayerLookAt(); // Function BGA_IslandPortal.BGA_IslandPortal_C.QueryPlayerLookAt // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StartOrEndQuery(); // Function BGA_IslandPortal.BGA_IslandPortal_C.StartOrEndQuery // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_IslandPortal.BGA_IslandPortal_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void ClearDisplayedWidget(); // Function BGA_IslandPortal.BGA_IslandPortal_C.ClearDisplayedWidget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CloseAndClearDisplayedWidget(); // Function BGA_IslandPortal.BGA_IslandPortal_C.CloseAndClearDisplayedWidget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CanUseHUDInteract(bool CanInteract); // Function BGA_IslandPortal.BGA_IslandPortal_C.CanUseHUDInteract // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	struct FVector ScaleThumbnailPlaneByTextureSize(); // Function BGA_IslandPortal.BGA_IslandPortal_C.ScaleThumbnailPlaneByTextureSize // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_IslandPortal.BGA_IslandPortal_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void UpdateNameDisplay(); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateNameDisplay // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdatePopulationDisplay(); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdatePopulationDisplay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetPortalUIVisibility(bool Show, float Distance); // Function BGA_IslandPortal.BGA_IslandPortal_C.SetPortalUIVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TeleportToLobbyIsland(struct AFortPlayerController* RequestingController); // Function BGA_IslandPortal.BGA_IslandPortal_C.TeleportToLobbyIsland // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintOnLocalInteract(struct AFortPlayerPawn* InteractingPawn); // Function BGA_IslandPortal.BGA_IslandPortal_C.BlueprintOnLocalInteract // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_IslandPortal.BGA_IslandPortal_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void GetPortalPosition(struct FVector Location); // Function BGA_IslandPortal.BGA_IslandPortal_C.GetPortalPosition // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UseRiftQuestUpdate(struct AController* InController); // Function BGA_IslandPortal.BGA_IslandPortal_C.UseRiftQuestUpdate // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckForRiftLocUpdate(struct AController* InController); // Function BGA_IslandPortal.BGA_IslandPortal_C.CheckForRiftLocUpdate // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_PlayerPawn(); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnRep_PlayerPawn // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_Vehicle(); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnRep_Vehicle // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_TeleportLocation(); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnRep_TeleportLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayExpandOrCollapseAudio(bool Expand); // Function BGA_IslandPortal.BGA_IslandPortal_C.PlayExpandOrCollapseAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void VectorScale__FinishedFunc(); // Function BGA_IslandPortal.BGA_IslandPortal_C.VectorScale__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void VectorScale__UpdateFunc(); // Function BGA_IslandPortal.BGA_IslandPortal_C.VectorScale__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_0__FinishedFunc(); // Function BGA_IslandPortal.BGA_IslandPortal_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_0__UpdateFunc(); // Function BGA_IslandPortal.BGA_IslandPortal_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_25EC650C4A5067360B49BC87DAFA1B71(struct UObject* Loaded); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnLoaded_25EC650C4A5067360B49BC87DAFA1B71 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_A43955A14A20383F466DF18A87BBA501(struct UObject* Loaded); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnLoaded_A43955A14A20383F466DF18A87BBA501 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_F2A7F21346C6B461BE9A1182BB5B5DD5(struct UObject* Loaded); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnLoaded_F2A7F21346C6B461BE9A1182BB5B5DD5 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_E60F9B1D4E758E4EA443468A995679B2(struct UObject* Loaded); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnLoaded_E60F9B1D4E758E4EA443468A995679B2 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__OverlapCapsule_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_IslandPortal.BGA_IslandPortal_C.BndEvt__OverlapCapsule_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_IslandPortal.BGA_IslandPortal_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BGA_IslandPortal.BGA_IslandPortal_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_IslandPortal.BGA_IslandPortal_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void PlayTeleportFX(struct FVector PlayerLocation, struct FVector DestinationLocation); // Function BGA_IslandPortal.BGA_IslandPortal_C.PlayTeleportFX // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayCosmeticFX(struct FVector DestinationLocation); // Function BGA_IslandPortal.BGA_IslandPortal_C.PlayCosmeticFX // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OverlappingOnBeginPlay(struct AActor* Actor); // Function BGA_IslandPortal.BGA_IslandPortal_C.OverlappingOnBeginPlay // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void NotifyTeleportedVehicle(struct AActor* VehicleActor); // Function BGA_IslandPortal.BGA_IslandPortal_C.NotifyTeleportedVehicle // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void LoadIslandUI(struct AFortPlayerPawn* InteractingPawn); // Function BGA_IslandPortal.BGA_IslandPortal_C.LoadIslandUI // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void NotifyTeleportedPlayerPawn(struct AFortPlayerPawn* PlayerPawn, bool bTeleportedToIslandStart); // Function BGA_IslandPortal.BGA_IslandPortal_C.NotifyTeleportedPlayerPawn // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ClientTeleportToLobbyIsland(struct AFortPlayerController* RequestingController); // Function BGA_IslandPortal.BGA_IslandPortal_C.ClientTeleportToLobbyIsland // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void EvaluateOverlap(); // Function BGA_IslandPortal.BGA_IslandPortal_C.EvaluateOverlap // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckIsMyPortal(bool IsMyPortal); // Function BGA_IslandPortal.BGA_IslandPortal_C.CheckIsMyPortal // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OwningPlayerChanged(); // Function BGA_IslandPortal.BGA_IslandPortal_C.OwningPlayerChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void CheckShouldDisplayUI(); // Function BGA_IslandPortal.BGA_IslandPortal_C.CheckShouldDisplayUI // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PopulationChanged(); // Function BGA_IslandPortal.BGA_IslandPortal_C.PopulationChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void DisplayNameChanged(); // Function BGA_IslandPortal.BGA_IslandPortal_C.DisplayNameChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void TeleportToCreativeHub(); // Function BGA_IslandPortal.BGA_IslandPortal_C.TeleportToCreativeHub // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PortalOpenChanged(); // Function BGA_IslandPortal.BGA_IslandPortal_C.PortalOpenChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void UpdatePortal(); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdatePortal // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CuratedPortalChanged(); // Function BGA_IslandPortal.BGA_IslandPortal_C.CuratedPortalChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ClientSaveDisplayChanged(bool bSaving); // Function BGA_IslandPortal.BGA_IslandPortal_C.ClientSaveDisplayChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void Play Rift Exit Sound(struct FVector Location); // Function BGA_IslandPortal.BGA_IslandPortal_C.Play Rift Exit Sound // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnThumbnailTextureReady(); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnThumbnailTextureReady // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SetupPortalForThumbnailDisplay(); // Function BGA_IslandPortal.BGA_IslandPortal_C.SetupPortalForThumbnailDisplay // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Play Teleport Audio(); // Function BGA_IslandPortal.BGA_IslandPortal_C.Play Teleport Audio // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BroadcastIsBeingInteractedWith(bool IsInteracting); // Function BGA_IslandPortal.BGA_IslandPortal_C.BroadcastIsBeingInteractedWith // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnReceivedNewIslandInfo(); // Function BGA_IslandPortal.BGA_IslandPortal_C.OnReceivedNewIslandInfo // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__HUD Visibility Volume_K2Node_ComponentBoundEvent_5_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_IslandPortal.BGA_IslandPortal_C.BndEvt__HUD Visibility Volume_K2Node_ComponentBoundEvent_5_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__HUD Visibility Volume_K2Node_ComponentBoundEvent_6_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BGA_IslandPortal.BGA_IslandPortal_C.BndEvt__HUD Visibility Volume_K2Node_ComponentBoundEvent_6_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ServerOnInteractWithIslandPortal(struct AFortPlayerPawn* InteractingPawn); // Function BGA_IslandPortal.BGA_IslandPortal_C.ServerOnInteractWithIslandPortal // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ErrorStateChanged(); // Function BGA_IslandPortal.BGA_IslandPortal_C.ErrorStateChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_IslandPortal(int32_t EntryPoint); // Function BGA_IslandPortal.BGA_IslandPortal_C.ExecuteUbergraph_BGA_IslandPortal // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void UpdateLocalPlayerLookingAtScreen__DelegateSignature(bool bPlayerLookingAtScreen); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateLocalPlayerLookingAtScreen__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CloseShownUI__DelegateSignature(); // Function BGA_IslandPortal.BGA_IslandPortal_C.CloseShownUI__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void IsBeingInteractedWith__DelegateSignature(bool IsInteracting); // Function BGA_IslandPortal.BGA_IslandPortal_C.IsBeingInteractedWith__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateLinkCode__DelegateSignature(struct FString LinkCode); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateLinkCode__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateDescription__DelegateSignature(struct FText Description); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateDescription__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateIsCuratedPortal__DelegateSignature(bool bIsCurated, bool bIsLinkCode, bool bIsUserInitiatedLoad); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateIsCuratedPortal__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdatePortalUIVis__DelegateSignature(bool Show, bool WasHidden, float Distance); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdatePortalUIVis__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateIslandName__DelegateSignature(struct FText NewIslandName); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdateIslandName__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdatePlayerPop__DelegateSignature(int32_t NewPop); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdatePlayerPop__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdatePlayerName__DelegateSignature(struct FText NewPlayerName); // Function BGA_IslandPortal.BGA_IslandPortal_C.UpdatePlayerName__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

