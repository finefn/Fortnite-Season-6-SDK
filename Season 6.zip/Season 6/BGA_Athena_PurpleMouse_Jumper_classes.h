// BlueprintGeneratedClass BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C
// Size: 0xb50 (Inherited: 0x8fd)
struct ABGA_Athena_PurpleMouse_Jumper_C : ABGA_Athena_WithGravity_Parent_C {
	char UnknownData_8FD[0x3]; // 0x8fd(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x900(0x08)
	struct UAudioComponent* Proximity Spin Sound; // 0x908(0x08)
	struct UStaticMeshComponent* SM_Cylinder_Beam; // 0x910(0x08)
	struct UStaticMeshComponent* VisibleMesh; // 0x918(0x08)
	struct USceneComponent* MeshPivot; // 0x920(0x08)
	struct UAudioComponent* AmbientHumAudio; // 0x928(0x08)
	struct USphereComponent* BeepBlinkTrigger; // 0x930(0x08)
	struct USphereComponent* ExplosionTrigger; // 0x938(0x08)
	float JumpOut_Rotation_X_2F05E8C8489AA60C8C830FAFF1B78CA0; // 0x940(0x04)
	float JumpOut_Rotation_Z_2F05E8C8489AA60C8C830FAFF1B78CA0; // 0x944(0x04)
	float JumpOut_Lifetime_2F05E8C8489AA60C8C830FAFF1B78CA0; // 0x948(0x04)
	float JumpOut_SpawnRate_2F05E8C8489AA60C8C830FAFF1B78CA0; // 0x94c(0x04)
	enum class ETimelineDirection JumpOut__Direction_2F05E8C8489AA60C8C830FAFF1B78CA0; // 0x950(0x01)
	char UnknownData_951[0x7]; // 0x951(0x07)
	struct UTimelineComponent* JumpOut; // 0x958(0x08)
	struct FScalableFloat BeepTriggerRadius; // 0x960(0x28)
	struct FScalableFloat TriggerRadius; // 0x988(0x28)
	struct FScalableFloat DamageRadius; // 0x9b0(0x28)
	struct FScalableFloat MarkPlayers; // 0x9d8(0x28)
	struct FScalableFloat MarkDuration; // 0xa00(0x28)
	struct FScalableFloat TimeToArm; // 0xa28(0x28)
	struct FScalableFloat PlayBeepSoundOnArm; // 0xa50(0x28)
	struct FText InteractText; // 0xa78(0x18)
	bool IsExlode?; // 0xa90(0x01)
	char UnknownData_A91[0x3]; // 0xa91(0x03)
	struct FGameplayTag CameraShakeGC; // 0xa94(0x08)
	char UnknownData_A9C[0x4]; // 0xa9c(0x04)
	struct TArray<struct AActor*> ActorsInBeepRadius; // 0xaa0(0x10)
	bool IsInteract?; // 0xab0(0x01)
	char UnknownData_AB1[0x7]; // 0xab1(0x07)
	struct USoundBase* ExplodeSound; // 0xab8(0x08)
	struct UParticleSystemComponent* BeepParticles; // 0xac0(0x08)
	struct USoundBase* BeepSound; // 0xac8(0x08)
	struct UFortWorldItemDefinition* ItemToPickUpOnDisarm; // 0xad0(0x08)
	struct UGameplayEffect* ExplosionGE; // 0xad8(0x08)
	struct FLinearColor EnemyParticleColor; // 0xae0(0x10)
	struct FLinearColor FriendlyParticleColor; // 0xaf0(0x10)
	struct USoundBase* PickupSound; // 0xb00(0x08)
	struct FLinearColor EnemyEmissiveColor; // 0xb08(0x10)
	struct FLinearColor FriendlyEmissiveColor; // 0xb18(0x10)
	enum class None MyTeam; // 0xb28(0x01)
	bool Jumped; // 0xb29(0x01)
	bool TeamHasBeenSet; // 0xb2a(0x01)
	char UnknownData_B2B[0x5]; // 0xb2b(0x05)
	struct UFortAbilitySystemComponent* DamageDealingAbilitySystemComponent; // 0xb30(0x08)
	struct FGameplayEffectContextHandle ExplosionEffectContext; // 0xb38(0x18)

	struct FVector GetFocusedSocketLocation(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.GetFocusedSocketLocation // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	bool CanBeSavedToCreativeVolume(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.CanBeSavedToCreativeVolume // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void GetAllPawns(struct TArray<struct AActor*> _Array, struct TArray<struct AActor*> _Result); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.GetAllPawns // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool Is in Infiltration Mode(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.Is in Infiltration Mode // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void Init(struct FVector GravHitNormal); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FilterByLOS(struct TArray<struct AActor*> _Array, struct TArray<struct AActor*> _Result); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.FilterByLOS // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CheckLOSAgain(struct AActor* ActorToCheckLOSAgainst); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.CheckLOSAgain // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void Launch(struct FVector LaunchSource, float Amount); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.Launch // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void JumpOut__FinishedFunc(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.JumpOut__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void JumpOut__UpdateFunc(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.JumpOut__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ExplosionTrigger_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BndEvt__ExplosionTrigger_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void JumpIntoExplosion(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.JumpIntoExplosion // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void SpawnFXSounds(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.SpawnFXSounds // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__ExplosionTrigger_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BndEvt__ExplosionTrigger_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void Beep(struct FName EventName, float EmitterTime, struct FVector Location, struct FVector Velocity); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.Beep // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TriggerBeep(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.TriggerBeep // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DetachAndLaunch(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.DetachAndLaunch // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Explode(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.Explode // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TriggerJumpTimeline(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.TriggerJumpTimeline // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Destroyed(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.Destroyed // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__BeepBlinkTrigger_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BndEvt__BeepBlinkTrigger_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__BeepBlinkTrigger_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BndEvt__BeepBlinkTrigger_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void StopBeep(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.StopBeep // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Damaged(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.Damaged // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ResetExplosionTimer(); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.ResetExplosionTimer // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_4_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_4_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void StopSim(struct FHitResult Hit); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.StopSim // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Pushback(struct FVector V); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.Pushback // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInstigatorDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.OnInstigatorDied // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetMyTeam(enum class None Team); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.SetMyTeam // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_PurpleMouse_Jumper(int32_t EntryPoint); // Function BGA_Athena_PurpleMouse_Jumper.BGA_Athena_PurpleMouse_Jumper_C.ExecuteUbergraph_BGA_Athena_PurpleMouse_Jumper // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

