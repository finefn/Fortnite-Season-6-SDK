// BlueprintGeneratedClass Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C
// Size: 0xca0 (Inherited: 0xbc0)
struct AAthena_Prop_ParentBuildingContainerBlueprint_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc0(0x08)
	bool DebugWind; // 0xbc8(0x01)
	char UnknownData_BC9[0x7]; // 0xbc9(0x07)
	struct TArray<struct UMaterialInterface*> IntenseWindMaterialsForPreview; // 0xbd0(0x10)
	struct UStaticMeshComponent* Wind Intensity Debug Mesh; // 0xbe0(0x08)
	struct TArray<struct UMaterialInterface*> OriginalMaterials; // 0xbe8(0x10)
	struct UMaterialInstanceDynamic* Debug_TempMaterial; // 0xbf8(0x08)
	float DebugWindYaw; // 0xc00(0x04)
	float Debug Wind Intensity; // 0xc04(0x04)
	bool Set Max Actor Scale; // 0xc08(0x01)
	char UnknownData_C09[0x3]; // 0xc09(0x03)
	float Max Scale; // 0xc0c(0x04)
	bool Disable TOD Lights and Material Emissive Values; // 0xc10(0x01)
	bool Disable Static Mesh Shadow Casting When Lights Are Active; // 0xc11(0x01)
	bool Use An Alternate Shadow Mesh When The Light is On ; // 0xc12(0x01)
	char UnknownData_C13[0x5]; // 0xc13(0x05)
	struct UStaticMesh* AlternateShadowStaticMesh; // 0xc18(0x08)
	bool Animate Emissive and Lights Over Time; // 0xc20(0x01)
	char UnknownData_C21[0x7]; // 0xc21(0x07)
	struct TArray<struct FLinearColor> CodeControlled_EmissiveColor; // 0xc28(0x10)
	struct TArray<float> CodeControlled_LightConeOpacity; // 0xc38(0x10)
	struct FDayPhaseFloats Light Intensity Over Time of Day ; // 0xc48(0x10)
	float Day Phase Transition Length; // 0xc58(0x04)
	struct FDayPhaseFloats Emissive Intensity Over Time of Day; // 0xc5c(0x10)
	float Volumetric Light Scattering Intensity; // 0xc6c(0x04)
	bool Cast Volumetric Shadows; // 0xc70(0x01)
	bool Animate Lights With A Curve - Disables time of day light controls; // 0xc71(0x01)
	bool Animate Mesh MID Emissive Value with a Curve - Disables time of day light controls; // 0xc72(0x01)
	char UnknownData_C73[0x5]; // 0xc73(0x05)
	struct UCurveFloat* LightAnimationCurve; // 0xc78(0x08)
	float CodeControlled_Animation Curve Animation Length; // 0xc80(0x04)
	int32_t CodeControlled_NumberOfMaterials; // 0xc84(0x04)
	struct TArray<float> NewVar_1; // 0xc88(0x10)
	float Random Time Scale Percent; // 0xc98(0x04)
	float CodeControlled_CurrentPlayLength; // 0xc9c(0x04)

	void GetTimeOfDayBlueprintDefaultVariables(struct FTimeOfDayBlueprintDefaultVariables OutVariables); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.GetTimeOfDayBlueprintDefaultVariables // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnDayPhaseChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void Loop Animation Curve(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.Loop Animation Curve // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnBounceAnimationUpdate(struct FFortBounceData Data); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnBounceAnimationUpdate // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnSetSearched(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnSetSearched // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint(int32_t EntryPoint); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

