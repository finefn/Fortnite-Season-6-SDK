// BlueprintGeneratedClass BP_Frontend_EventLevel_NavObject_BattlePassScreen.BP_Frontend_EventLevel_NavObject_BattlePassScreen_C
// Size: 0x4f0 (Inherited: 0x4d0)
struct ABP_Frontend_EventLevel_NavObject_BattlePassScreen_C : AFortEventLevelNavigationActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4d0(0x08)
	struct UBoxComponent* Box; // 0x4d8(0x08)
	struct UStaticMeshComponent* Plane; // 0x4e0(0x08)
	struct UMaterialInstanceDynamic* MID_BPScreen; // 0x4e8(0x08)

	void SetBattlePassVisualState(bool bIsPurchased); // Function BP_Frontend_EventLevel_NavObject_BattlePassScreen.BP_Frontend_EventLevel_NavObject_BattlePassScreen_C.SetBattlePassVisualState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BP_Frontend_EventLevel_NavObject_BattlePassScreen.BP_Frontend_EventLevel_NavObject_BattlePassScreen_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void UpdateVisuals(); // Function BP_Frontend_EventLevel_NavObject_BattlePassScreen.BP_Frontend_EventLevel_NavObject_BattlePassScreen_C.UpdateVisuals // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnInitializeForPlayer(); // Function BP_Frontend_EventLevel_NavObject_BattlePassScreen.BP_Frontend_EventLevel_NavObject_BattlePassScreen_C.OnInitializeForPlayer // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_Frontend_EventLevel_NavObject_BattlePassScreen(int32_t EntryPoint); // Function BP_Frontend_EventLevel_NavObject_BattlePassScreen.BP_Frontend_EventLevel_NavObject_BattlePassScreen_C.ExecuteUbergraph_BP_Frontend_EventLevel_NavObject_BattlePassScreen // (Final|UbergraphFunction) // @ game+0xbd830c
};

