// BlueprintGeneratedClass BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C
// Size: 0x9a0 (Inherited: 0x7e0)
struct ABLGA_BattleLab_Parent_C : ABattleLabDeviceGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7e0(0x08)
	struct UFortWaterInteractionComponent* FortWaterInteraction; // 0x7e8(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0x7f0(0x08)
	struct UFortHeldObjectComponent* FortHeldObject; // 0x7f8(0x08)
	struct UFortProjectileMovementComponent* FortProjectileMovement; // 0x800(0x08)
	struct UCapsuleComponent* Capsule; // 0x808(0x08)
	struct UFortCurieComponent* FortCurie; // 0x810(0x08)
	int32_t RepStartMoving; // 0x818(0x04)
	struct FGameplayTag GC_HitPlayer; // 0x81c(0x08)
	struct FGameplayTag GC_HitWorld; // 0x824(0x08)
	struct FGameplayTag GC_Throw; // 0x82c(0x08)
	struct FGameplayTag GC_EnterWater; // 0x834(0x08)
	struct FGameplayTag GC_Pickup; // 0x83c(0x08)
	struct FGameplayTag GC_Death; // 0x844(0x08)
	bool PlayDeathGC; // 0x84c(0x01)
	bool RepHideActor; // 0x84d(0x01)
	bool SetHideActorOnDeath; // 0x84e(0x01)
	bool IsDestructable; // 0x84f(0x01)
	struct FGameplayTag GC_GenericDeath; // 0x850(0x08)
	float WorldStopSlop; // 0x858(0x04)
	bool AttachToWallsAndCeilings; // 0x85c(0x01)
	char UnknownData_85D[0x3]; // 0x85d(0x03)
	struct TMap<enum class ELinkToDirection, struct FVector> Map_DirectionToRelativeVector; // 0x860(0x50)
	enum class ELinkToDirection DirectionToAttach; // 0x8b0(0x01)
	char UnknownData_8B1[0x7]; // 0x8b1(0x07)
	struct AActor* EmptyAttachLinkActor; // 0x8b8(0x08)
	struct FTransform AttachRelativeTrans; // 0x8c0(0x30)
	struct FTransform AttachTransform; // 0x8f0(0x30)
	struct FText FirstInteractString; // 0x920(0x18)
	struct FText SecondInteractString; // 0x938(0x18)
	float SecondInteractTime; // 0x950(0x04)
	float FirstInteractTime; // 0x954(0x04)
	bool EverBeenThrownPlaced; // 0x958(0x01)
	bool AutoEnableCurieInteractionsOnStop; // 0x959(0x01)
	bool AlreadySavedDefaultTransform; // 0x95a(0x01)
	enum class Enum_HeldObject_GenericWeights ObjectWeights; // 0x95b(0x01)
	char UnknownData_95C[0x4]; // 0x95c(0x04)
	struct FMulticastInlineDelegate OnStartedMoving; // 0x960(0x10)
	struct ABLGA_BattleLab_Parent_C* AttachBaseDevice; // 0x970(0x08)
	enum class BL_HeldState HeldState; // 0x978(0x01)
	char UnknownData_979[0x7]; // 0x979(0x07)
	struct FGameplayTagContainer TC_BlockPickup; // 0x980(0x20)

	void OnRep_HeldState(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnRep_HeldState // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetBeenThrownPlaced(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.SetBeenThrownPlaced // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetCanFirstInteract(struct AFortPawn* InteractingPawn, bool Return); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.GetCanFirstInteract // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void OnRep_AttachTransform(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnRep_AttachTransform // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetAttachDefaultTransform(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.SetAttachDefaultTransform // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void GetAttachComponent(struct USceneComponent* Component); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.GetAttachComponent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	void FindAttachAngle(struct FVector HitLoc); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.FindAttachAngle // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_RepHideActor(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnRep_RepHideActor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_RepStartMoving(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnRep_RepStartMoving // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_2_OnHeldObjectThrown__DelegateSignature(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_2_OnHeldObjectThrown__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_3_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_3_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void HideActor(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.HideActor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayGenericDeath(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.PlayGenericDeath // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_1_OnProjectileBounceDelegate__DelegateSignature(struct FHitResult ImpactResult, struct FVector ImpactVelocity); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_1_OnProjectileBounceDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_0_OnLinkedActorDestroyed__DelegateSignature(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_0_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_4_OnProjectileStopDelegate__DelegateSignature(struct FHitResult ImpactResult); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_4_OnProjectileStopDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void AttachSetup(struct FVector Location, struct FVector HitNormal, bool NewParam); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.AttachSetup // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_6_OnHeldObjectPickedUp__DelegateSignature(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_6_OnHeldObjectPickedUp__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ResetRelativeTransformOnAttach(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.ResetRelativeTransformOnAttach // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnFirstInteract(struct AFortPawn* Interacting Pawn); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnFirstInteract // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_5_OnHeldObjectPlaced__DelegateSignature(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_5_OnHeldObjectPlaced__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnSecondInteract(struct AFortPawn* InteractingPawn); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnSecondInteract // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_7_OnProjectileVelocityReplicated__DelegateSignature(struct FVector ReplicatedVelocity); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_7_OnProjectileVelocityReplicated__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnBaseDeviceStartedMoving(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnBaseDeviceStartedMoving // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_8_OnHeldObjectDropped__DelegateSignature(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_8_OnHeldObjectDropped__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnHeldObjectStateChangedClient(enum class BL_HeldState HeldState); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnHeldObjectStateChangedClient // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BLGA_BattleLab_Parent(int32_t EntryPoint); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.ExecuteUbergraph_BLGA_BattleLab_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void OnStartedMoving__DelegateSignature(); // Function BLGA_BattleLab_Parent.BLGA_BattleLab_Parent_C.OnStartedMoving__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

