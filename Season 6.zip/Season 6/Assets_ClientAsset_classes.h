// SolarisGeneratedClass Assets_ClientAsset.ClientAsset
// Size: 0x80 (Inherited: 0x80)
struct UClientAsset : UAsset {

	void $InitInstance(); // Function Assets_ClientAsset.ClientAsset.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Assets_ClientAsset.ClientAsset.$InitCDO // () // @ game+0xbd830c
};

