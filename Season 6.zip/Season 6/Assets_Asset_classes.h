// SolarisGeneratedClass Assets_Asset.Asset
// Size: 0x80 (Inherited: 0x68)
struct UAsset : UVerseAssetPtr {
	char UnknownData_68[0x18]; // 0x68(0x18)

	char Load(); // Function Assets_Asset.Asset.Load // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea0a70
	struct UStickyEvent* getAsyncLoadEvent(); // Function Assets_Asset.Asset.getAsyncLoadEvent // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea07e8
	struct UStickyEvent* asyncLoad(); // Function Assets_Asset.Asset.asyncLoad // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea0350
	struct UAsset* create_Internal(struct UObject* __verse_0x69F1185B_assetClass, struct FString __verse_0x5D4EDCE6_pathToAsset); // Function Assets_Asset.Asset.create_Internal // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea06e0
	void $InitInstance(); // Function Assets_Asset.Asset.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Assets_Asset.Asset.$InitCDO // () // @ game+0xbd830c
};

