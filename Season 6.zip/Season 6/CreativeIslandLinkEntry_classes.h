// WidgetBlueprintGeneratedClass CreativeIslandLinkEntry.CreativeIslandLinkEntry_C
// Size: 0xc50 (Inherited: 0xbf8)
struct UCreativeIslandLinkEntry_C : UFortCreativeIslandLinkEntry {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbf8(0x08)
	struct UBorder* Border_Text; // 0xc00(0x08)
	struct UImage* Image_1; // 0xc08(0x08)
	struct UImage* Image_SelectedBG; // 0xc10(0x08)
	struct USimplePipButton_C* SimplePipButton; // 0xc18(0x08)
	struct UCommonTextBlock* Text_CreatorName; // 0xc20(0x08)
	struct UCommonTextBlock* Text_IslandDescription; // 0xc28(0x08)
	struct UCommonTextBlock* Text_IslandName; // 0xc30(0x08)
	struct UTextBlock* Text_Version; // 0xc38(0x08)
	struct FString Mnemonic; // 0xc40(0x10)

	void BP_OnSelected(); // Function CreativeIslandLinkEntry.CreativeIslandLinkEntry_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnDeselected(); // Function CreativeIslandLinkEntry.CreativeIslandLinkEntry_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnListItemObjectSet(struct UObject* ListItemObject); // Function CreativeIslandLinkEntry.CreativeIslandLinkEntry_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__SimplePipButton_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function CreativeIslandLinkEntry.CreativeIslandLinkEntry_C.BndEvt__SimplePipButton_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CreativeIslandLinkEntry(int32_t EntryPoint); // Function CreativeIslandLinkEntry.CreativeIslandLinkEntry_C.ExecuteUbergraph_CreativeIslandLinkEntry // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

