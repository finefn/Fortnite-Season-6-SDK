// AnimBlueprintGeneratedClass Bone_Bow_AnimBlueprint.Bone_Bow_AnimBlueprint_C
// Size: 0xab0 (Inherited: 0x2c0)
struct UBone_Bow_AnimBlueprint_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose; // 0x2f8(0x118)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody; // 0x410(0x660)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0xa70(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0xa90(0x20)

	void AnimGraph(struct FPoseLink InPose, struct FPoseLink AnimGraph); // Function Bone_Bow_AnimBlueprint.Bone_Bow_AnimBlueprint_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Bone_Bow_AnimBlueprint(int32_t EntryPoint); // Function Bone_Bow_AnimBlueprint.Bone_Bow_AnimBlueprint_C.ExecuteUbergraph_Bone_Bow_AnimBlueprint // (Final|UbergraphFunction) // @ game+0xbd830c
};

