// Class EasyAntiCheatCommon.EasyAntiCheatNetComponent
// Size: 0xb8 (Inherited: 0xb0)
struct UEasyAntiCheatNetComponent : UActorComponent {
	char UnknownData_B0[0x8]; // 0xb0(0x08)

	void ServerMessage(struct TArray<enum class None> Message); // Function EasyAntiCheatCommon.EasyAntiCheatNetComponent.ServerMessage // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x60880cc
	void ClientMessage(struct TArray<enum class None> Message); // Function EasyAntiCheatCommon.EasyAntiCheatNetComponent.ClientMessage // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x6088020
};

