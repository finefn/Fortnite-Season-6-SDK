// Enum CommonInput.ECommonInputType
enum class ECommonInputType : uint8 {
	MouseAndKeyboard,
	Gamepad,
	Touch,
	Count,
	ECommonInputType_MAX,
};

// Enum CommonInput.ECommonGamepadType
enum class ECommonGamepadType : uint8 {
	XboxOneController,
	PS4Controller,
	SwitchController,
	GenericController,
	XboxSeriesXController,
	PS5Controller,
	Count,
	ECommonGamepadType_MAX,
};

// Enum CommonInput.ECommonPlatformType
enum class ECommonPlatformType : uint8 {
	PC,
	Mac,
	PS4,
	XBox,
	IOS,
	Android,
	Switch,
	XSX,
	PS5,
	Count,
	ECommonPlatformType_MAX,
};

// ScriptStruct CommonInput.CommonInputPlatformData
// Size: 0x28 (Inherited: 0x00)
struct FCommonInputPlatformData {
	bool bSupported; // 0x00(0x01)
	enum class ECommonInputType DefaultInputType; // 0x01(0x01)
	bool bSupportsMouseAndKeyboard; // 0x02(0x01)
	bool bSupportsGamepad; // 0x03(0x01)
	enum class ECommonGamepadType DefaultGamepadType; // 0x04(0x01)
	bool bCanChangeGamepadType; // 0x05(0x01)
	bool bSupportsTouch; // 0x06(0x01)
	char UnknownData_7[0x1]; // 0x07(0x01)
	struct TArray<SoftClassProperty> ControllerData; // 0x08(0x10)
	struct TArray<struct UCommonInputControllerData*> ControllerDataClasses; // 0x18(0x10)
};

// ScriptStruct CommonInput.CommonInputKeySetBrushConfiguration
// Size: 0x98 (Inherited: 0x00)
struct FCommonInputKeySetBrushConfiguration {
	struct TArray<struct FKey> Keys; // 0x00(0x10)
	struct FSlateBrush KeyBrush; // 0x10(0x88)
};

// ScriptStruct CommonInput.CommonInputKeyBrushConfiguration
// Size: 0xa0 (Inherited: 0x00)
struct FCommonInputKeyBrushConfiguration {
	struct FKey Key; // 0x00(0x18)
	struct FSlateBrush KeyBrush; // 0x18(0x88)
};

