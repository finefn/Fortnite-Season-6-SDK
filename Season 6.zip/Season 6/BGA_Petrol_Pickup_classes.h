// BlueprintGeneratedClass BGA_Petrol_Pickup.BGA_Petrol_Pickup_C
// Size: 0xd18 (Inherited: 0x9b0)
struct ABGA_Petrol_Pickup_C : ABGA_HeldObject_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9b0(0x08)
	struct UFortItemEntryComponent* FortItemEntry; // 0x9b8(0x08)
	struct UStaticMeshComponent* PetrolCan; // 0x9c0(0x08)
	struct USphereComponent* Sphere; // 0x9c8(0x08)
	struct AFortPlayerPawn* PlayerPawn; // 0x9d0(0x08)
	struct AFortPlayerControllerAthena* PlayerController; // 0x9d8(0x08)
	bool ShouldExplode; // 0x9e0(0x01)
	char UnknownData_9E1[0x7]; // 0x9e1(0x07)
	struct TArray<struct UGameplayEffect*> ExplodeDamageGE; // 0x9e8(0x10)
	struct AFortPawn* ExplodeInstigator; // 0x9f8(0x08)
	struct TArray<struct AActor*> TargetedActors; // 0xa00(0x10)
	struct UGameplayEffect* GE_Explode; // 0xa10(0x08)
	struct FGameplayTag GC_Explode; // 0xa18(0x08)
	struct TArray<enum class EObjectTypeQuery> ObjectArray; // 0xa20(0x10)
	struct FScalableFloat SpawnedProjectileMinSpeed; // 0xa30(0x28)
	struct FScalableFloat SpawnedProjectileMaxSpeed; // 0xa58(0x28)
	struct FScalableFloat ConeHalfAngleInDegrees; // 0xa80(0x28)
	struct ABuildingGameplayActor* CurieBGAtoSpawn; // 0xaa8(0x08)
	struct AFortProjectileBase* CurieFireballsToSpawn; // 0xab0(0x08)
	struct FScalableFloat FireBallsToSpawn; // 0xab8(0x28)
	struct UFortWorldItemDefinition* WeaponItemDefinition; // 0xae0(0x08)
	struct AFortPickup* WeaponPickupToGrant; // 0xae8(0x08)
	struct FHitResult LastHit; // 0xaf0(0x88)
	struct FTimerHandle FuseTimerHandle; // 0xb78(0x08)
	struct FScalableFloat FuseMinDuration; // 0xb80(0x28)
	struct FScalableFloat FuseMaxDuration; // 0xba8(0x28)
	struct FGuid HeldItemGUID; // 0xbd0(0x10)
	struct TScriptInterface<None> HeldItemInventoryInterface; // 0xbe0(0x10)
	bool IsAttachedToWeapon; // 0xbf0(0x01)
	bool Dropped; // 0xbf1(0x01)
	char UnknownData_BF2[0x2]; // 0xbf2(0x02)
	struct FGameplayTag GC_OnFire; // 0xbf4(0x08)
	char UnknownData_BFC[0x4]; // 0xbfc(0x04)
	struct FScalableFloat ExplosionRadius; // 0xc00(0x28)
	struct FScalableFloat VehicleDamage; // 0xc28(0x28)
	struct AFortWeapon* WeaponAttachedTo; // 0xc50(0x08)
	struct FGameplayTag GC_Refuel; // 0xc58(0x08)
	struct TArray<enum class EObjectTypeQuery> SpawnCollisionCheck_ObjectTypes; // 0xc60(0x10)
	float Max_Spawn_Z; // 0xc70(0x04)
	bool SpawnCollisionBlocked; // 0xc74(0x01)
	char UnknownData_C75[0x3]; // 0xc75(0x03)
	struct FVector VelocityAfterVehicleOverlap; // 0xc78(0x0c)
	char UnknownData_C84[0x4]; // 0xc84(0x04)
	struct FScalableFloat HotfixExplodeVehicleImpulse; // 0xc88(0x28)
	struct FScalableFloat HotfixExplodeSpinThrust; // 0xcb0(0x28)
	struct UGameplayEffect* GE_ExplodePlayerDamage; // 0xcd8(0x08)
	struct UGameplayEffect* GE_ExplodeVehicleDamage; // 0xce0(0x08)
	bool FuseLit; // 0xce8(0x01)
	char UnknownData_CE9[0x3]; // 0xce9(0x03)
	float MinSpeedOfNoStickBounce; // 0xcec(0x04)
	struct USoundBase* FailedInteractSound; // 0xcf0(0x08)
	struct FGameplayTagContainer Tag_FailedInteract_InventoryIsFull; // 0xcf8(0x20)

	bool BlueprintOnLocalInteract(struct AFortPlayerPawn* InteractingPawn); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintOnLocalInteract // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CalcVehicleImpulse(struct AActor* Vehicle, float Magnitude, struct FVector Vector); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.CalcVehicleImpulse // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_LastHit(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnRep_LastHit // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnRep_ShouldExplode(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnRep_ShouldExplode // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void SpawnCurieFireballs(struct AFortPawn* ExplodeInstigator); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.SpawnCurieFireballs // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void SetFuseAndDrop(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.SetFuseAndDrop // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnFireBallsExplodeAndDie(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.SpawnFireBallsExplodeAndDie // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExplodeAndDie(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ExplodeAndDie // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetHeldItemInfo(struct TScriptInterface<None> InventoryInterface, struct FGuid Guid, struct AFortWeapon* WeaponAttachedTo); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.SetHeldItemInfo // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DropHeldItem(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.DropHeldItem // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HideAndDestroy(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.HideAndDestroy // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void (ServerOnly)HideAndDestroy(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.(ServerOnly)HideAndDestroy // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Refuel(int32_t FuelToAdd); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.Refuel // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileBounceDelegate__DelegateSignature(struct FHitResult ImpactResult, struct FVector ImpactVelocity); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileBounceDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementInteract_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag, struct FCurieInteractParamsHandle InteractParamsHandle); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnCurieElementInteract_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnCurieElementInteractBegun_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag, struct FCurieInteractParamsHandle InteractParamsHandle); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnCurieElementInteractBegun_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Petrol_Pickup(int32_t EntryPoint); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ExecuteUbergraph_BGA_Petrol_Pickup // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

