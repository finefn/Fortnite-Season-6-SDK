// WidgetBlueprintGeneratedClass BattlePassPagedTrack.BattlePassPagedTrack_C
// Size: 0x360 (Inherited: 0x348)
struct UBattlePassPagedTrack_C : UBattlePassRewardPagedTrack {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x348(0x08)
	struct UWidgetAnimation* Backward; // 0x350(0x08)
	struct UWidgetAnimation* Forward; // 0x358(0x08)

	void CycleTrackBackward(); // Function BattlePassPagedTrack.BattlePassPagedTrack_C.CycleTrackBackward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void CycleTrackForward(); // Function BattlePassPagedTrack.BattlePassPagedTrack_C.CycleTrackForward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPageChanged(bool bIsForward); // Function BattlePassPagedTrack.BattlePassPagedTrack_C.OnPageChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BattlePassPagedTrack(int32_t EntryPoint); // Function BattlePassPagedTrack.BattlePassPagedTrack_C.ExecuteUbergraph_BattlePassPagedTrack // (Final|UbergraphFunction) // @ game+0xbd830c
};

