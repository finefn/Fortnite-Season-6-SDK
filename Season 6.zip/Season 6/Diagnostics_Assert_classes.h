// SolarisGeneratedClass Diagnostics_Assert.Assert
// Size: 0x28 (Inherited: 0x28)
struct UAssert : UObject {

	void cmpMsg(char __verse_0x123742AA_expression, struct FString __verse_0xD212B012_message); // Function Diagnostics_Assert.Assert.cmpMsg // (Native|Static|Public|BlueprintCallable) // @ game+0x3ed642c
	void cmp(char __verse_0x123742AA_expression); // Function Diagnostics_Assert.Assert.cmp // (Native|Static|Public|BlueprintCallable) // @ game+0x3ed6434
	void $InitInstance(); // Function Diagnostics_Assert.Assert.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Diagnostics_Assert.Assert.$InitCDO // () // @ game+0xbd830c
};

