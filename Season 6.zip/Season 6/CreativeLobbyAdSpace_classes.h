// WidgetBlueprintGeneratedClass CreativeLobbyAdSpace.CreativeLobbyAdSpace_C
// Size: 0x294 (Inherited: 0x270)
struct UCreativeLobbyAdSpace_C : UFortCreativeAdsView {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)
	struct UCreativeLobbyAd_C* Ad1; // 0x278(0x08)
	struct UCreativeLobbyAd_C* Ad2; // 0x280(0x08)
	struct USizeBox* CreativeAdContent; // 0x288(0x08)
	int32_t NumCreativeAds; // 0x290(0x04)

	void Construct(); // Function CreativeLobbyAdSpace.CreativeLobbyAdSpace_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_CreativeLobbyAdSpace(int32_t EntryPoint); // Function CreativeLobbyAdSpace.CreativeLobbyAdSpace_C.ExecuteUbergraph_CreativeLobbyAdSpace // (Final|UbergraphFunction) // @ game+0xbd830c
};

