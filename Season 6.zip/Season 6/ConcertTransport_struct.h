// Enum ConcertTransport.EConcertReliableHandshakeState
enum class EConcertReliableHandshakeState : uint8 {
	None,
	Negotiate,
	Success,
	EConcertReliableHandshakeState_MAX,
};

// Enum ConcertTransport.EConcertResponseCode
enum class EConcertResponseCode : uint8 {
	Pending,
	Success,
	Failed,
	InvalidRequest,
	UnknownRequest,
	TimedOut,
	EConcertResponseCode_MAX,
};

// Enum ConcertTransport.EConcertMessageFlags
enum class EConcertMessageFlags : uint8 {
	None,
	ReliableOrdered,
	UniqueId,
	EConcertMessageFlags_MAX,
};

// ScriptStruct ConcertTransport.ConcertLocalIdentifierState
// Size: 0x10 (Inherited: 0x00)
struct FConcertLocalIdentifierState {
	struct TArray<struct FString> MappedNames; // 0x00(0x10)
};

// ScriptStruct ConcertTransport.ConcertMessageData
// Size: 0x30 (Inherited: 0x00)
struct FConcertMessageData {
	char UnknownData_0[0x8]; // 0x00(0x08)
	struct FGuid ConcertEndpointId; // 0x08(0x10)
	struct FGuid MessageID; // 0x18(0x10)
	uint16_t MessageOrderIndex; // 0x28(0x02)
	uint16_t ChannelId; // 0x2a(0x02)
	char UnknownData_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct ConcertTransport.ConcertKeepAlive
// Size: 0x30 (Inherited: 0x30)
struct FConcertKeepAlive : FConcertMessageData {
};

// ScriptStruct ConcertTransport.ConcertAckData
// Size: 0x48 (Inherited: 0x30)
struct FConcertAckData : FConcertMessageData {
	int64_t AckSendTimeTicks; // 0x30(0x08)
	struct FGuid SourceMessageId; // 0x38(0x10)
};

// ScriptStruct ConcertTransport.ConcertEventData
// Size: 0x30 (Inherited: 0x30)
struct FConcertEventData : FConcertMessageData {
};

// ScriptStruct ConcertTransport.ConcertEndpointDiscoveryEvent
// Size: 0x30 (Inherited: 0x30)
struct FConcertEndpointDiscoveryEvent : FConcertEventData {
};

// ScriptStruct ConcertTransport.ConcertReliableHandshakeData
// Size: 0x40 (Inherited: 0x30)
struct FConcertReliableHandshakeData : FConcertEndpointDiscoveryEvent {
	enum class EConcertReliableHandshakeState HandshakeState; // 0x30(0x01)
	char UnknownData_31[0x1]; // 0x31(0x01)
	uint16_t ReliableChannelId; // 0x32(0x02)
	uint16_t NextMessageIndex; // 0x34(0x02)
	char UnknownData_36[0x2]; // 0x36(0x02)
	int64_t EndpointTimeoutTick; // 0x38(0x08)
};

// ScriptStruct ConcertTransport.ConcertEndpointClosedData
// Size: 0x30 (Inherited: 0x30)
struct FConcertEndpointClosedData : FConcertMessageData {
};

// ScriptStruct ConcertTransport.ConcertResponseData
// Size: 0x60 (Inherited: 0x30)
struct FConcertResponseData : FConcertMessageData {
	struct FGuid RequestMessageId; // 0x30(0x10)
	enum class EConcertResponseCode ResponseCode; // 0x40(0x01)
	char UnknownData_41[0x7]; // 0x41(0x07)
	struct FText Reason; // 0x48(0x18)
};

// ScriptStruct ConcertTransport.ConcertRequestData
// Size: 0x30 (Inherited: 0x30)
struct FConcertRequestData : FConcertMessageData {
};

// ScriptStruct ConcertTransport.ConcertEndpointSettings
// Size: 0x0c (Inherited: 0x00)
struct FConcertEndpointSettings {
	bool bEnableLogging; // 0x00(0x01)
	char UnknownData_1[0x3]; // 0x01(0x03)
	int32_t PurgeProcessedMessageDelaySeconds; // 0x04(0x04)
	int32_t RemoteEndpointTimeoutSeconds; // 0x08(0x04)
};

