// BlueprintGeneratedClass B_UtilityItem_Generic_Athena.B_UtilityItem_Generic_Athena_C
// Size: 0xd49 (Inherited: 0xd40)
struct AB_UtilityItem_Generic_Athena_C : AB_UtilityItem_Generic_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd40(0x08)
	bool UseThrowConsumableHudKeyActions; // 0xd48(0x01)

	void ReceiveBeginPlay(); // Function B_UtilityItem_Generic_Athena.B_UtilityItem_Generic_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ThrowConsumableHudActionKey_Targeting(bool Targeting); // Function B_UtilityItem_Generic_Athena.B_UtilityItem_Generic_Athena_C.ThrowConsumableHudActionKey_Targeting // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ThrowConsumableHudActionKey_Visible(bool Visible); // Function B_UtilityItem_Generic_Athena.B_UtilityItem_Generic_Athena_C.ThrowConsumableHudActionKey_Visible // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_UtilityItem_Generic_Athena(int32_t EntryPoint); // Function B_UtilityItem_Generic_Athena.B_UtilityItem_Generic_Athena_C.ExecuteUbergraph_B_UtilityItem_Generic_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

