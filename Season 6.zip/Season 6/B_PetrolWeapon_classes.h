// BlueprintGeneratedClass B_PetrolWeapon.B_PetrolWeapon_C
// Size: 0x12f9 (Inherited: 0x1231)
struct AB_PetrolWeapon_C : AB_Ranged_Generic_Athena_Deprecated_C {
	char UnknownData_1231[0x7]; // 0x1231(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1238(0x08)
	struct UFortSplatterSourceComponent* FortSplatterSource; // 0x1240(0x08)
	bool EnableAmmoMod; // 0x1248(0x01)
	char UnknownData_1249[0x7]; // 0x1249(0x07)
	struct ABGA_Petrol_Pickup_C* AttachedBGAActor; // 0x1250(0x08)
	struct FName AttachSocket; // 0x1258(0x08)
	struct FVector AttachedBGAScale; // 0x1260(0x0c)
	char UnknownData_126C[0x4]; // 0x126c(0x04)
	struct FTransform AttachedBGARelativeTransform; // 0x1270(0x30)
	struct TScriptInterface<None> InventoryInterface; // 0x12a0(0x10)
	struct FGuid InventoryGUID; // 0x12b0(0x10)
	struct UNiagaraComponent* NS_FuelLeaking; // 0x12c0(0x08)
	struct FScalableFloat IsShootableWhileHeld; // 0x12c8(0x28)
	struct AFortWeapon* WeaponReference; // 0x12f0(0x08)
	bool ShowHUDKeyActions; // 0x12f8(0x01)

	void OnRep_AttachedBGAActor(); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnRep_AttachedBGAActor // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnSpawnProjectile(struct AFortProjectileBase* SpawnProjectile); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnSpawnProjectile // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void UpdateAndAttachBGA(); // Function B_PetrolWeapon.B_PetrolWeapon_C.UpdateAndAttachBGA // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnEquip(Copy)(); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnEquip(Copy) // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnStopWeaponFireFX(); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnStopWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnUnEquip(Copy)(); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnUnEquip(Copy) // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void K2_OnUnEquip(); // Function B_PetrolWeapon.B_PetrolWeapon_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_PetrolWeapon.B_PetrolWeapon_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void HUDKeyAction_Targeting(bool IsTargeting); // Function B_PetrolWeapon.B_PetrolWeapon_C.HUDKeyAction_Targeting // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnHolstered(); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnHolstered // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnUnholstered(); // Function B_PetrolWeapon.B_PetrolWeapon_C.OnUnholstered // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BindHolsterEvents(); // Function B_PetrolWeapon.B_PetrolWeapon_C.BindHolsterEvents // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UnbindHolsterEvents(); // Function B_PetrolWeapon.B_PetrolWeapon_C.UnbindHolsterEvents // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BGADestroyedWhileHeld(); // Function B_PetrolWeapon.B_PetrolWeapon_C.BGADestroyedWhileHeld // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReplicateOnUnholstered(); // Function B_PetrolWeapon.B_PetrolWeapon_C.ReplicateOnUnholstered // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReplicateOnHolstered(); // Function B_PetrolWeapon.B_PetrolWeapon_C.ReplicateOnHolstered // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_PetrolWeapon(int32_t EntryPoint); // Function B_PetrolWeapon.B_PetrolWeapon_C.ExecuteUbergraph_B_PetrolWeapon // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

