// SolarisGeneratedClass Core_StickyEvent.Context_StickyEvent_wait
// Size: 0xa0 (Inherited: 0xa0)
struct UContext_StickyEvent_wait : UContext__wait {

	int32_t Update(); // Function Core_StickyEvent.Context_StickyEvent_wait.Update // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea02f0
};

// SolarisGeneratedClass Core_StickyEvent.StickyEvent
// Size: 0x58 (Inherited: 0x50)
struct UStickyEvent : UEvent {
	char UnknownData_50[0x8]; // 0x50(0x08)

	void signal(); // Function Core_StickyEvent.StickyEvent.signal // (Native|Public|BlueprintCallable) // @ game+0x3ea0e3c
	char isSignaled(); // Function Core_StickyEvent.StickyEvent.isSignaled // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea0a54
	void clearSignal(); // Function Core_StickyEvent.StickyEvent.clearSignal // (Native|Public|BlueprintCallable) // @ game+0x3ea0570
	struct UStickyEvent* Create(); // Function Core_StickyEvent.StickyEvent.Create // (Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea0724
	void $InitInstance(); // Function Core_StickyEvent.StickyEvent.$InitInstance // () // @ game+0xbd830c
	void $InitCDO(); // Function Core_StickyEvent.StickyEvent.$InitCDO // () // @ game+0xbd830c
};

