// BlueprintGeneratedClass B_Athena_Wumba.B_Athena_Wumba_C
// Size: 0xfdc (Inherited: 0xc00)
struct AB_Athena_Wumba_C : ABuildingItemWeaponUpgradeActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc00(0x08)
	struct UAudioComponent* Search_Sound_Loop; // 0xc08(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0xc10(0x08)
	struct UChildActorComponent* EditorOnly_MeshPreview; // 0xc18(0x08)
	struct UStaticMeshComponent* CylinderDistance; // 0xc20(0x08)
	struct USphereComponent* SphereDetail; // 0xc28(0x08)
	struct UWidgetComponent* UI_InteractionPoint_Sidegrade; // 0xc30(0x08)
	struct UWidgetComponent* UI_InteractionPoint_Upgrade; // 0xc38(0x08)
	struct UWumba_ItemCostComponent_Horizontal_C* Wumba_ItemCostComponent_Horizontal; // 0xc40(0x08)
	struct UBoxComponent* TableCollision; // 0xc48(0x08)
	struct UBoxComponent* PostCollision; // 0xc50(0x08)
	struct UBoxComponent* TopCollision; // 0xc58(0x08)
	struct UBoxComponent* BaseCollision; // 0xc60(0x08)
	struct UParticleSystemComponent* P_UpgradeFX; // 0xc68(0x08)
	struct UParticleSystemComponent* P_TableLightIdle; // 0xc70(0x08)
	struct UParticleSystemComponent* P_Destroyed; // 0xc78(0x08)
	struct UAudioComponent* Flashing_Light_Sound_Loop; // 0xc80(0x08)
	struct UStaticMeshComponent* S_LootTiered_Athena_FloorLoot_01; // 0xc88(0x08)
	struct USkeletalMeshComponent* SK_Wumba; // 0xc90(0x08)
	struct UWumba_ItemCostComponent_C* Wumba_ItemCostComponent; // 0xc98(0x08)
	struct UForceFeedbackComponent* ForceFeedbackFail; // 0xca0(0x08)
	struct UForceFeedbackComponent* ForceFeedbackSuccess; // 0xca8(0x08)
	struct UAudioComponent* VendingMachine_Ambient; // 0xcb0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0xcb8(0x08)
	float Timeline_1_Light_F9C064A347D6CF3499CF96B51F1F7AF8; // 0xcc0(0x04)
	enum class ETimelineDirection Timeline_1__Direction_F9C064A347D6CF3499CF96B51F1F7AF8; // 0xcc4(0x01)
	char UnknownData_CC5[0x3]; // 0xcc5(0x03)
	struct UTimelineComponent* Timeline_2; // 0xcc8(0x08)
	struct UMaterialInstanceDynamic* MonitorMat; // 0xcd0(0x08)
	struct UMaterialInstanceDynamic* MetalMat; // 0xcd8(0x08)
	int32_t CurrentCaptureCount; // 0xce0(0x04)
	char UnknownData_CE4[0x4]; // 0xce4(0x04)
	struct FText Vend String; // 0xce8(0x18)
	struct USoundBase* SearchSound; // 0xd00(0x08)
	struct USoundBase* VendFailedSound; // 0xd08(0x08)
	struct USoundBase* CycleSound; // 0xd10(0x08)
	int32_t CostAmount; // 0xd18(0x04)
	char UnknownData_D1C[0x4]; // 0xd1c(0x04)
	struct UTexture* MaterialType; // 0xd20(0x08)
	struct USoundBase* Vend Succeeded Sound; // 0xd28(0x08)
	bool VendSuccess; // 0xd30(0x01)
	bool WasHit; // 0xd31(0x01)
	char UnknownData_D32[0x2]; // 0xd32(0x02)
	float CycleSoundVolume; // 0xd34(0x04)
	struct FCurveTableRowHandle TossOnGroundSetting; // 0xd38(0x10)
	struct FText Wood String; // 0xd48(0x18)
	struct FText Stone String; // 0xd60(0x18)
	struct FText Metal String; // 0xd78(0x18)
	enum class EFortRarity OverrideVendingMachineRarity; // 0xd90(0x01)
	char UnknownData_D91[0x7]; // 0xd91(0x07)
	struct USoundBase* Activate_Rare_Sound; // 0xd98(0x08)
	struct FText Free String; // 0xda0(0x18)
	struct USoundBase* DestroyedSound; // 0xdb8(0x08)
	struct FScalableFloat MaxItemsToSpawn; // 0xdc0(0x28)
	struct FScalableFloat ItemsAreFree; // 0xde8(0x28)
	bool ItemsAreFreeCached; // 0xe10(0x01)
	char UnknownData_E11[0x3]; // 0xe11(0x03)
	int32_t SpawnedItemCount; // 0xe14(0x04)
	int32_t MaxItemsToSpawnCached; // 0xe18(0x04)
	char UnknownData_E1C[0x4]; // 0xe1c(0x04)
	struct USoundBase* Activate_Uncommon_Sound; // 0xe20(0x08)
	struct USoundBase* Activate_Epic_Sound; // 0xe28(0x08)
	struct USoundBase* Activate_Legendary_Sound; // 0xe30(0x08)
	struct USoundBase* Ambient_Sound; // 0xe38(0x08)
	struct FGameplayTagContainer FailedReason; // 0xe40(0x20)
	struct FGameplayTagContainer UpgradeQuestTag; // 0xe60(0x20)
	struct FLinearColor DefaultLightEmissiveColor; // 0xe80(0x10)
	bool UpgradeAnim; // 0xe90(0x01)
	char UnknownData_E91[0x7]; // 0xe91(0x07)
	struct USoundBase* Light_Flashing; // 0xe98(0x08)
	struct USoundBase* Impact_Wobble; // 0xea0(0x08)
	struct UAudioComponent* Search Audio Component; // 0xea8(0x08)
	struct FText SideGradeString; // 0xeb0(0x18)
	struct FScalableFloat HorizontalEnabled; // 0xec8(0x28)
	float UIShowDistance; // 0xef0(0x04)
	float UIDetailDistance; // 0xef4(0x04)
	struct FTimerHandle UICheckTimer; // 0xef8(0x08)
	struct FScalableFloat AllowDamage; // 0xf00(0x28)
	struct USoundBase* Activate_Sidegrade_Sound; // 0xf28(0x08)
	struct FGameplayTagContainer SidegradeQuestTag; // 0xf30(0x20)
	struct FScalableFloat InteractionTimeSide; // 0xf50(0x28)
	float LightSize; // 0xf78(0x04)
	char UnknownData_F7C[0x4]; // 0xf7c(0x04)
	struct FScalableFloat SpawnPickup; // 0xf80(0x28)
	bool DoOnce; // 0xfa8(0x01)
	char UnknownData_FA9[0x7]; // 0xfa9(0x07)
	struct AActor* LinkToActor; // 0xfb0(0x08)
	enum class TInteractionType NewVar_1; // 0xfb8(0x01)
	char UnknownData_FB9[0x7]; // 0xfb9(0x07)
	struct FText UpgradeBenchDisplayName; // 0xfc0(0x18)
	float Search Sound Fade out Duration; // 0xfd8(0x04)

	void UpdateAnimInstanceVisuals(); // Function B_Athena_Wumba.B_Athena_Wumba_C.UpdateAnimInstanceVisuals // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetUiVisibility(struct UWidgetComponent* UITarget, bool ShowDetail, bool ShowDistance); // Function B_Athena_Wumba.B_Athena_Wumba_C.SetUiVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void LocalOnFailedInteract(struct AFortPlayerPawn* InteractingPawn); // Function B_Athena_Wumba.B_Athena_Wumba_C.LocalOnFailedInteract // (Event|Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_Athena_Wumba.B_Athena_Wumba_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void SetLightColor(struct FLinearColor NewColor); // Function B_Athena_Wumba.B_Athena_Wumba_C.SetLightColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetFailedInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_Athena_Wumba.B_Athena_Wumba_C.BlueprintGetFailedInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool GetOverrideRarity(enum class EFortRarity Rarity); // Function B_Athena_Wumba.B_Athena_Wumba_C.GetOverrideRarity // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void SetRarityColors(struct FLinearColor Color); // Function B_Athena_Wumba.B_Athena_Wumba_C.SetRarityColors // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_Athena_Wumba.B_Athena_Wumba_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	void Timeline_1__FinishedFunc(); // Function B_Athena_Wumba.B_Athena_Wumba_C.Timeline_1__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_1__UpdateFunc(); // Function B_Athena_Wumba.B_Athena_Wumba_C.Timeline_1__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnReady_524B43EB45254EC3646C7D81A1AA3359(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function B_Athena_Wumba.B_Athena_Wumba_C.OnReady_524B43EB45254EC3646C7D81A1AA3359 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_Athena_Wumba.B_Athena_Wumba_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnBeginInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function B_Athena_Wumba.B_Athena_Wumba_C.BlueprintOnBeginInteract // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void PlayUpgradeSuccess(struct FVector Color, enum class None Index, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_Athena_Wumba.B_Athena_Wumba_C.PlayUpgradeSuccess // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Athena_Wumba.B_Athena_Wumba_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void PlayVendFailFX(); // Function B_Athena_Wumba.B_Athena_Wumba_C.PlayVendFailFX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function B_Athena_Wumba.B_Athena_Wumba_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnDamagePlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function B_Athena_Wumba.B_Athena_Wumba_C.OnDamagePlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void WobbleMachine(); // Function B_Athena_Wumba.B_Athena_Wumba_C.WobbleMachine // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteractInterrupted(); // Function B_Athena_Wumba.B_Athena_Wumba_C.BlueprintOnInteractInterrupted // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ReceiveDestroyed(); // Function B_Athena_Wumba.B_Athena_Wumba_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void CheckShouldDisplayUI(bool ShowDetail, bool ShowDistance); // Function B_Athena_Wumba.B_Athena_Wumba_C.CheckShouldDisplayUI // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void InitializeUI(); // Function B_Athena_Wumba.B_Athena_Wumba_C.InitializeUI // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__SphereDetail_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function B_Athena_Wumba.B_Athena_Wumba_C.BndEvt__SphereDetail_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__SphereDetail_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function B_Athena_Wumba.B_Athena_Wumba_C.BndEvt__SphereDetail_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CylinderDistance_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function B_Athena_Wumba.B_Athena_Wumba_C.BndEvt__CylinderDistance_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__CylinderDistance_K2Node_ComponentBoundEvent_5_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function B_Athena_Wumba.B_Athena_Wumba_C.BndEvt__CylinderDistance_K2Node_ComponentBoundEvent_5_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function B_Athena_Wumba.B_Athena_Wumba_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void PingMultiCast(); // Function B_Athena_Wumba.B_Athena_Wumba_C.PingMultiCast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_2_OnLinkedActorDestroyed__DelegateSignature(); // Function B_Athena_Wumba.B_Athena_Wumba_C.BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_2_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void StopSearchSoundLoop(); // Function B_Athena_Wumba.B_Athena_Wumba_C.StopSearchSoundLoop // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Athena_Wumba(int32_t EntryPoint); // Function B_Athena_Wumba.B_Athena_Wumba_C.ExecuteUbergraph_B_Athena_Wumba // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

