// BlueprintGeneratedClass B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C
// Size: 0x1231 (Inherited: 0x10c8)
struct AB_Ranged_Generic_Athena_Deprecated_C : AFortWeaponRanged {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x10c8(0x08)
	struct UParticleSystemComponent* Muzzle1P(Empty); // 0x10d0(0x08)
	struct UStaticMeshComponent* IronSightsMesh1P; // 0x10d8(0x08)
	struct UParticleSystemComponent* MuzzleWindParticle(Empty); // 0x10e0(0x08)
	struct UParticleSystemComponent* Reload(Empty); // 0x10e8(0x08)
	struct UParticleSystemComponent* Shells(empty); // 0x10f0(0x08)
	struct UStaticMeshComponent* ScopeMesh1P; // 0x10f8(0x08)
	struct UParticleSystemComponent* Muzzle(Empty); // 0x1100(0x08)
	float AnimateScopePostProcess_DownSightPostProcessAmount_8E980769412DEF67B9B63CAE644DA93B; // 0x1108(0x04)
	enum class ETimelineDirection AnimateScopePostProcess__Direction_8E980769412DEF67B9B63CAE644DA93B; // 0x110c(0x01)
	char UnknownData_110D[0x3]; // 0x110d(0x03)
	struct UTimelineComponent* AnimateScopePostProcess; // 0x1110(0x08)
	struct UParticleSystem* MuzzleParticleSystem; // 0x1118(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffect; // 0x1120(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffectIcon; // 0x1128(0x08)
	bool UseDestroyEffect; // 0x1130(0x01)
	bool RandomMuzzleFlashScaling; // 0x1131(0x01)
	bool Use Reload Particles; // 0x1132(0x01)
	char UnknownData_1133[0x5]; // 0x1133(0x05)
	struct UParticleSystem* Reload_ParticleSystem; // 0x1138(0x08)
	float LastPlayFXTime; // 0x1140(0x04)
	float MinPlayFXTime; // 0x1144(0x04)
	bool UseShellsOnFire?; // 0x1148(0x01)
	bool UseShellsOnReload?; // 0x1149(0x01)
	bool UseShellsOnPump?; // 0x114a(0x01)
	char UnknownData_114B[0x5]; // 0x114b(0x05)
	struct UParticleSystem* ShellsParticleSystemTemplate; // 0x1150(0x08)
	struct FName ReloadSocketName; // 0x1158(0x08)
	struct TArray<struct AFortAIPawn*> Array Of Active Enemy AI; // 0x1160(0x10)
	bool Scope - Render Enemies To Custom Depth Buffer; // 0x1170(0x01)
	char UnknownData_1171[0x3]; // 0x1171(0x03)
	struct FName Shells Socket Name; // 0x1174(0x08)
	enum class En_ShellTypes_01 ShellTypeSelect; // 0x117c(0x01)
	char UnknownData_117D[0x3]; // 0x117d(0x03)
	float Shells Spawn Rate Scale; // 0x1180(0x04)
	struct FVector ShellsRotationRate; // 0x1184(0x0c)
	struct FVector Shells Velocity; // 0x1190(0x0c)
	struct FVector Shells Gravity; // 0x119c(0x0c)
	float Shells Lifetime; // 0x11a8(0x04)
	struct FVector Shells Size; // 0x11ac(0x0c)
	float Shells Time Dilation; // 0x11b8(0x04)
	float Target Scope Vignette Blur Screen Percentage; // 0x11bc(0x04)
	float Scope Camera Offset Amount; // 0x11c0(0x04)
	bool SmallShells; // 0x11c4(0x01)
	bool MediumShells; // 0x11c5(0x01)
	bool LargeShells; // 0x11c6(0x01)
	bool ShotgunShells; // 0x11c7(0x01)
	bool EnergyShells; // 0x11c8(0x01)
	char UnknownData_11C9[0x3]; // 0x11c9(0x03)
	float Inherit Parent Velocity; // 0x11cc(0x04)
	float Cylindrical Radius; // 0x11d0(0x04)
	float Cylindrical Height; // 0x11d4(0x04)
	bool DebugShellsSocket?; // 0x11d8(0x01)
	char UnknownData_11D9[0x7]; // 0x11d9(0x07)
	struct USoundBase* Sound_ScopeZoomIn; // 0x11e0(0x08)
	struct USoundBase* Sound_ScopeZoomOut; // 0x11e8(0x08)
	struct UParticleSystemComponent* Alteration Ambient PS; // 0x11f0(0x08)
	struct FGameplayTagContainer ReticleHUDElementTags; // 0x11f8(0x20)
	bool Is Wind Enabled; // 0x1218(0x01)
	char UnknownData_1219[0x7]; // 0x1219(0x07)
	struct UParticleSystem* MuzzleWindParticleSystem; // 0x1220(0x08)
	struct UParticleSystem* MuzzleParticleSystem1P; // 0x1228(0x08)
	bool ShouldHideReticleAfterDelay; // 0x1230(0x01)

	void GetScopeParameters(struct UStaticMeshComponent* ScopeComponent, struct FVector2D DepthOfFieldVignetteRange, float WeaponSightsCameraOffset); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.GetScopeParameters // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandlePawnAndWeaponVisFor1PTargeting(bool IsTargeting); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.HandlePawnAndWeaponVisFor1PTargeting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShowReticle(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ShowReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HideReticle(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.HideReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HideIronSightsMesh(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.HideIronSightsMesh // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ActivateOrDeactivateWindParticle(bool bNewActive); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ActivateOrDeactivateWindParticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DeactivateMuzzleFX(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.DeactivateMuzzleFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DeactivateReloadSmokeFX(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.DeactivateReloadSmokeFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ActivateReloadSmokeFX(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ActivateReloadSmokeFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ActivateShellsFX(bool Bool); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ActivateShellsFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DeactivateShellsFX(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.DeactivateShellsFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetupShellFX(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.SetupShellFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UpdateShellEmittersFX(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.UpdateShellEmittersFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Muzzle Play Reload FX(enum class EFortReloadFXState Selection); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.Muzzle Play Reload FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Muzzle Flash FX(bool Persistent Fire); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.Muzzle Flash FX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetWpnRarity(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.SetWpnRarity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AddRandomScale(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.AddRandomScale // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void AnimateScopePostProcess__FinishedFunc(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.AnimateScopePostProcess__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void AnimateScopePostProcess__UpdateFunc(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.AnimateScopePostProcess__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_43F549264BB135D3D385D4BB5846412A(struct UObject* Loaded); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnLoaded_43F549264BB135D3D385D4BB5846412A // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_109F12F046377B483CA7FF92A795CBD2(struct UObject* Loaded); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnLoaded_109F12F046377B483CA7FF92A795CBD2 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_65280D504DA982E453E39BA22D9D1643(struct UObject* Loaded); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnLoaded_65280D504DA982E453E39BA22D9D1643 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnLoaded_351A9D71483BD9CF417705946595CB08(struct UObject* Loaded); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnLoaded_351A9D71483BD9CF417705946595CB08 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnStopWeaponFireFX(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnStopWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnPlayReloadFX(enum class EFortReloadFXState ReloadStage); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnPlayReloadFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnSetTargeting(bool bNewIsTargeting); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnSetTargeting // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void K2_OnUnEquip(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void InitializeScopeVariables(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.InitializeScopeVariables // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update Enemy Custom Depths(bool Enable Or Disable, int32_t StencilBufferValue); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.Update Enemy Custom Depths // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponAttached(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnInitAlteration(struct UFortAlterationItemDefinition* NewAlteration); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnInitAlteration // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnInitCosmeticAlterations(struct FFortCosmeticModification CosmeticMod); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnInitCosmeticAlterations // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ShellsON_(onPump)(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ShellsON_(onPump) // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnEquippedWeaponDestory(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnEquippedWeaponDestory // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SetWeaponPierceThrough(bool Enable, int32_t TargetLimit); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.SetWeaponPierceThrough // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SetWeaponPierceThrough_ClientRep(bool Enable, int32_t TargetLimit); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.SetWeaponPierceThrough_ClientRep // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnWeaponVisibilityChanged(bool bVisible, bool bSetForLocalControllerOnly); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.OnWeaponVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void HideWeaponMesh(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.HideWeaponMesh // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShowWeaponMesh(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ShowWeaponMesh // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HideGunMesh(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.HideGunMesh // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShowGunMesh(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ShowGunMesh // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HideWeapon(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.HideWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ShowWeapon(); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ShowWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Ranged_Generic_Athena_Deprecated(int32_t EntryPoint); // Function B_Ranged_Generic_Athena_Deprecated.B_Ranged_Generic_Athena_Deprecated_C.ExecuteUbergraph_B_Ranged_Generic_Athena_Deprecated // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

