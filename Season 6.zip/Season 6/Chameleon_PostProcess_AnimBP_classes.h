// AnimBlueprintGeneratedClass Chameleon_PostProcess_AnimBP.Chameleon_PostProcess_AnimBP_C
// Size: 0x2300 (Inherited: 0x490)
struct UChameleon_PostProcess_AnimBP_C : UFortPetAnimInstance_AnimDynamics {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x490(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x498(0x30)
	char UnknownData_4C8[0x8]; // 0x4c8(0x08)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4; // 0x4d0(0x440)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x910(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0xa68(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3; // 0xa90(0x20)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0xab0(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2; // 0xad8(0x20)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0xaf8(0xa0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0xb98(0xa0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3; // 0xc38(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2; // 0xc58(0x20)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0xc78(0x28)
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput; // 0xca0(0x118)
	char UnknownData_DB8[0x8]; // 0xdb8(0x08)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3; // 0xdc0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2; // 0x1200(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics; // 0x1640(0x440)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_8; // 0x1a80(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x1b88(0x20)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_7; // 0x1ba8(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_6; // 0x1cb0(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_5; // 0x1db8(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x1ec0(0x20)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_4; // 0x1ee0(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_3; // 0x1fe8(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_2; // 0x20f0(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint; // 0x21f8(0x108)

	void AnimGraph(struct FPoseLink InPose, struct FPoseLink AnimGraph); // Function Chameleon_PostProcess_AnimBP.Chameleon_PostProcess_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Chameleon_PostProcess_AnimBP(int32_t EntryPoint); // Function Chameleon_PostProcess_AnimBP.Chameleon_PostProcess_AnimBP_C.ExecuteUbergraph_Chameleon_PostProcess_AnimBP // (Final|UbergraphFunction) // @ game+0xbd830c
};

