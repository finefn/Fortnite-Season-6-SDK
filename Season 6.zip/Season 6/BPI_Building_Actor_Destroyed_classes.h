// BlueprintGeneratedClass BPI_Building_Actor_Destroyed.BPI_Building_Actor_Destroyed_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_Building_Actor_Destroyed_C : UInterface {

	void Event_Building_Actor_Destroyed(); // Function BPI_Building_Actor_Destroyed.BPI_Building_Actor_Destroyed_C.Event_Building_Actor_Destroyed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

