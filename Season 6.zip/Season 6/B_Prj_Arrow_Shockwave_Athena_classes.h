// BlueprintGeneratedClass B_Prj_Arrow_Shockwave_Athena.B_Prj_Arrow_Shockwave_Athena_C
// Size: 0xc58 (Inherited: 0xc38)
struct AB_Prj_Arrow_Shockwave_Athena_C : AB_Prj_Athena_Arrow_Generic_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc38(0x08)
	struct FRotator ZeroRotator; // 0xc40(0x0c)
	char UnknownData_C4C[0x4]; // 0xc4c(0x04)
	struct AFortProjectileBase* DummyGrenadeClass; // 0xc50(0x08)

	void HandleHitPawn(struct APlayerPawn_Athena_C* Pawn, struct AFortProjectileBase* Projectile); // Function B_Prj_Arrow_Shockwave_Athena.B_Prj_Arrow_Shockwave_Athena_C.HandleHitPawn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnFullyChargedImpact(struct FHitResult Hit Result); // Function B_Prj_Arrow_Shockwave_Athena.B_Prj_Arrow_Shockwave_Athena_C.OnFullyChargedImpact // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void SpawnShockwaveGrenade(struct FHitResult Hit); // Function B_Prj_Arrow_Shockwave_Athena.B_Prj_Arrow_Shockwave_Athena_C.SpawnShockwaveGrenade // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_B_Prj_Arrow_Shockwave_Athena(int32_t EntryPoint); // Function B_Prj_Arrow_Shockwave_Athena.B_Prj_Arrow_Shockwave_Athena_C.ExecuteUbergraph_B_Prj_Arrow_Shockwave_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

