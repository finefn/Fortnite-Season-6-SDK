// WidgetBlueprintGeneratedClass BattlePassScreenS16.BattlePassScreenS16_C
// Size: 0x984 (Inherited: 0x8c8)
struct UBattlePassScreenS16_C : UBattlePassScreenS16 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8c8(0x08)
	struct UWidgetAnimation* ShowPreviewAction; // 0x8d0(0x08)
	struct UWidgetAnimation* ShowVariantLabel; // 0x8d8(0x08)
	struct UWidgetAnimation* SeasonInformation; // 0x8e0(0x08)
	struct UWidgetAnimation* OnViewRewardAnimation; // 0x8e8(0x08)
	struct UHorizontalBox* EndingDateNOTUSED; // 0x8f0(0x08)
	struct UImage* FakeHackGradient; // 0x8f8(0x08)
	struct UOverlay* ForceBacchusMobileDownwards; // 0x900(0x08)
	struct UOverlay* ForceBacchusMobileUpwards; // 0x908(0x08)
	struct USizeBox* ItemDetailsContainer; // 0x910(0x08)
	struct UOverlay* OwnsBattlePassContainer; // 0x918(0x08)
	struct UHorizontalBox* PlatformSharedButtons; // 0x920(0x08)
	struct UVerticalBox* SeasonDetailsHB; // 0x928(0x08)
	struct USafeZone* SZButtonsAndLegal; // 0x930(0x08)
	struct USafeZone* SZSideContent; // 0x938(0x08)
	struct UCommonTextBlock* Text_ChapterNumber_2; // 0x940(0x08)
	struct UCommonTextBlock* Text_ChapterNumber_3; // 0x948(0x08)
	struct UCommonBorder* VariantLabel; // 0x950(0x08)
	struct UCommonTextBlock* VariantUnlockPreviewSet; // 0x958(0x08)
	bool AutoPlayVideo; // 0x960(0x01)
	bool ForceAutoPlayVideo; // 0x961(0x01)
	char UnknownData_962[0x2]; // 0x962(0x02)
	struct FLinearColor MPC-ManualSunlightVector; // 0x964(0x10)
	struct FLinearColor MPC-ManualSunlightColor; // 0x974(0x10)

	void HandleRewardTimelineAnimation(bool bAnimateRewardTimeline); // Function BattlePassScreenS16.BattlePassScreenS16_C.HandleRewardTimelineAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleWatchVideoRequest(bool PlayFromDisc); // Function BattlePassScreenS16.BattlePassScreenS16_C.HandleWatchVideoRequest // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void HandleViewReward(bool bInNoReward, int32_t InNumRewardsToPurchase); // Function BattlePassScreenS16.BattlePassScreenS16_C.HandleViewReward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BP_OnActivated(); // Function BattlePassScreenS16.BattlePassScreenS16_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnRequestViewReward(); // Function BattlePassScreenS16.BattlePassScreenS16_C.OnRequestViewReward // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnRequestViewRewardComplete(); // Function BattlePassScreenS16.BattlePassScreenS16_C.OnRequestViewRewardComplete // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnVariantUpdate(int32_t CurrentIndex, int32_t TotalNumVariants); // Function BattlePassScreenS16.BattlePassScreenS16_C.OnVariantUpdate // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnBattlePassViewChanged(enum class EBattlePassView NewView); // Function BattlePassScreenS16.BattlePassScreenS16_C.OnBattlePassViewChanged // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnAnimationFinished(struct UWidgetAnimation* Animation); // Function BattlePassScreenS16.BattlePassScreenS16_C.OnAnimationFinished // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnPreviewActionButtonUpdated(struct FText RowDisplayName); // Function BattlePassScreenS16.BattlePassScreenS16_C.OnPreviewActionButtonUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnViewReward(struct FFortRarityItemData Rarity, bool bNoReward, struct UFortItemDefinition* RewardItem); // Function BattlePassScreenS16.BattlePassScreenS16_C.OnViewReward // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnWatchVideo(); // Function BattlePassScreenS16.BattlePassScreenS16_C.OnWatchVideo // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function BattlePassScreenS16.BattlePassScreenS16_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BattlePassScreenS16(int32_t EntryPoint); // Function BattlePassScreenS16.BattlePassScreenS16_C.ExecuteUbergraph_BattlePassScreenS16 // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

