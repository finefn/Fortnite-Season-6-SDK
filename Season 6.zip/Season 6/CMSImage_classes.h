// WidgetBlueprintGeneratedClass CMSImage.CMSImage_C
// Size: 0x268 (Inherited: 0x260)
struct UCMSImage_C : UUserWidget {
	struct UEpicCMSImage* Image; // 0x260(0x08)

	void SetMediaURL(struct FString MediaUrl); // Function CMSImage.CMSImage_C.SetMediaURL // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

