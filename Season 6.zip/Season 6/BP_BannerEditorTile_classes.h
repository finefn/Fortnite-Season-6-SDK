// WidgetBlueprintGeneratedClass BP_BannerEditorTile.BP_BannerEditorTile_C
// Size: 0xc50 (Inherited: 0xc00)
struct UBP_BannerEditorTile_C : UFortPlayerProfileBannerEditorTile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc00(0x08)
	struct UImage* ColorImage; // 0xc08(0x08)
	struct UCommonWidgetSwitcher* CommonWidgetSwitcher_1; // 0xc10(0x08)
	struct UImage* IconImage; // 0xc18(0x08)
	struct UCommonLoadGuard* IconLoadGuard; // 0xc20(0x08)
	struct UImage* Image_BannerEditBorder; // 0xc28(0x08)
	struct UNormalBangWrapper_C* NormalBangWrapper; // 0xc30(0x08)
	struct UMaterialInstanceDynamic* ColorMID; // 0xc38(0x08)
	struct FMulticastInlineDelegate BannerTileBangUpdated; // 0xc40(0x10)

	void Mark Item As Seen(); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.Mark Item As Seen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Update Bang State(); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.Update Bang State // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnListItemObjectSet(struct UObject* ListItemObject); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void HandleBannerIconLoadGuardFinished(struct UObject* Object); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.HandleBannerIconLoadGuardFinished // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BP_OnSelected(); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_BannerEditorTile(int32_t EntryPoint); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.ExecuteUbergraph_BP_BannerEditorTile // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void BannerTileBangUpdated__DelegateSignature(); // Function BP_BannerEditorTile.BP_BannerEditorTile_C.BannerTileBangUpdated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

