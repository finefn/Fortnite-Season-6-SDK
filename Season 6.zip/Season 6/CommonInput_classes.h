// Class CommonInput.CommonInputSettings
// Size: 0x208 (Inherited: 0x28)
struct UCommonInputSettings : UObject {
	SoftClassProperty InputData; // 0x28(0x28)
	struct FCommonInputPlatformData CommonInputPlatformData[0x9]; // 0x50(0x168)
	bool bEnableInputMethodThrashingProtection; // 0x1b8(0x01)
	char UnknownData_1B9[0x3]; // 0x1b9(0x03)
	int32_t InputMethodThrashingLimit; // 0x1bc(0x04)
	double InputMethodThrashingWindowInSeconds; // 0x1c0(0x08)
	double InputMethodThrashingCooldownInSeconds; // 0x1c8(0x08)
	bool bAllowOutOfFocusDeviceInput; // 0x1d0(0x01)
	char UnknownData_1D1[0x7]; // 0x1d1(0x07)
	struct UCommonUIInputData* InputDataClass; // 0x1d8(0x08)
	struct FCommonInputPlatformData CurrentPlatform; // 0x1e0(0x28)
};

// Class CommonInput.CommonInputSubsystem
// Size: 0xf0 (Inherited: 0x30)
struct UCommonInputSubsystem : ULocalPlayerSubsystem {
	char UnknownData_30[0x20]; // 0x30(0x20)
	struct FMulticastInlineDelegate OnInputMethodChanged; // 0x50(0x10)
	int32_t NumberOfInputMethodChangesRecently; // 0x60(0x04)
	char UnknownData_64[0x4]; // 0x64(0x04)
	double LastInputMethodChangeTime; // 0x68(0x08)
	double LastTimeInputMethodThrashingBegan; // 0x70(0x08)
	enum class ECommonInputType LastInputType; // 0x78(0x01)
	enum class ECommonInputType CurrentInputType; // 0x79(0x01)
	enum class ECommonGamepadType GamepadInputType; // 0x7a(0x01)
	char UnknownData_7B[0x5]; // 0x7b(0x05)
	struct TMap<struct FName, enum class ECommonInputType> CurrentInputLocks; // 0x80(0x50)
	char UnknownData_D0[0x18]; // 0xd0(0x18)
	bool bIsGamepadSimulatedClick; // 0xe8(0x01)
	char UnknownData_E9[0x7]; // 0xe9(0x07)

	bool ShouldShowInputKeys(); // Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1b89aec
	void SetGamepadInputType(enum class ECommonGamepadType InGamepadInputType); // Function CommonInput.CommonInputSubsystem.SetGamepadInputType // (Final|Native|Public|BlueprintCallable) // @ game+0x3415818
	void SetCurrentInputType(enum class ECommonInputType NewInputType); // Function CommonInput.CommonInputSubsystem.SetCurrentInputType // (Final|Native|Public|BlueprintCallable) // @ game+0x3415780
	bool IsUsingPointerInput(); // Function CommonInput.CommonInputSubsystem.IsUsingPointerInput // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x341575c
	bool IsInputMethodActive(enum class ECommonInputType InputMethod); // Function CommonInput.CommonInputSubsystem.IsInputMethodActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x34156b8
	enum class ECommonInputType GetDefaultInputType(); // Function CommonInput.CommonInputSubsystem.GetDefaultInputType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3415694
	enum class ECommonInputType GetCurrentInputType(); // Function CommonInput.CommonInputSubsystem.GetCurrentInputType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1a21058
	enum class ECommonGamepadType GetCurrentGamepadType(); // Function CommonInput.CommonInputSubsystem.GetCurrentGamepadType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3415680
};

// Class CommonInput.CommonUIInputData
// Size: 0x48 (Inherited: 0x28)
struct UCommonUIInputData : UObject {
	struct FDataTableRowHandle DefaultClickAction; // 0x28(0x10)
	struct FDataTableRowHandle DefaultBackAction; // 0x38(0x10)
};

// Class CommonInput.CommonInputControllerData
// Size: 0xa0 (Inherited: 0x28)
struct UCommonInputControllerData : UObject {
	enum class ECommonInputType InputType; // 0x28(0x01)
	enum class ECommonGamepadType GamepadType; // 0x29(0x01)
	char UnknownData_2A[0x6]; // 0x2a(0x06)
	struct TSoftObjectPtr<struct UTexture2D> ControllerTexture; // 0x30(0x28)
	struct TSoftObjectPtr<struct UTexture2D> ControllerButtonMaskTexture; // 0x58(0x28)
	struct TArray<struct FCommonInputKeyBrushConfiguration> InputBrushDataMap; // 0x80(0x10)
	struct TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets; // 0x90(0x10)
};

