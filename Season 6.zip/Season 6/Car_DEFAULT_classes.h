// BlueprintGeneratedClass Car_DEFAULT.Car_DEFAULT_C
// Size: 0xdb4 (Inherited: 0xbc0)
struct ACar_DEFAULT_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc0(0x08)
	struct UBuildingActorLootDropOnDeathComponent_C* BuildingActorLootDropOnDeathComponent; // 0xbc8(0x08)
	float Timeline_2_SirenLightMultiplier_432AD11E41A8AFC288A559BCD8B4B9AF; // 0xbd0(0x04)
	enum class ETimelineDirection Timeline_2__Direction_432AD11E41A8AFC288A559BCD8B4B9AF; // 0xbd4(0x01)
	char UnknownData_BD5[0x3]; // 0xbd5(0x03)
	struct UTimelineComponent* Timeline_3; // 0xbd8(0x08)
	float BounceCar_Vertical_Bounce_Component_80AD679E42DD1FF308EBD994998BB983; // 0xbe0(0x04)
	enum class ETimelineDirection BounceCar__Direction_80AD679E42DD1FF308EBD994998BB983; // 0xbe4(0x01)
	char UnknownData_BE5[0x3]; // 0xbe5(0x03)
	struct UTimelineComponent* BounceCar; // 0xbe8(0x08)
	float Timeline_0_AlarmLightMultiplier_431FAFC04FFC4DEBB684B3B6AF7510E7; // 0xbf0(0x04)
	enum class ETimelineDirection Timeline_0__Direction_431FAFC04FFC4DEBB684B3B6AF7510E7; // 0xbf4(0x01)
	char UnknownData_BF5[0x3]; // 0xbf5(0x03)
	struct UTimelineComponent* Timeline_1; // 0xbf8(0x08)
	bool OverallAlarmCycleFinished; // 0xc00(0x01)
	char UnknownData_C01[0x3]; // 0xc01(0x03)
	struct FLinearColor InitialEmissiveMultiplier; // 0xc04(0x10)
	struct FLinearColor InitialEmissiveMultiplier2; // 0xc14(0x10)
	int32_t AlarmLightCounter; // 0xc24(0x04)
	bool SoundIsRetriggerable; // 0xc28(0x01)
	bool CurrentFlashAnimationCycleFinished; // 0xc29(0x01)
	char UnknownData_C2A[0x2]; // 0xc2a(0x02)
	int32_t NumberOfTimesTheLightsFlashWhenHit; // 0xc2c(0x04)
	float SirenLightEmissiveMultiplier; // 0xc30(0x04)
	bool SirenLightOn; // 0xc34(0x01)
	char UnknownData_C35[0x3]; // 0xc35(0x03)
	struct FName Emissive Multiplier 2; // 0xc38(0x08)
	struct FName Emissive Multiplier; // 0xc40(0x08)
	struct USoundBase* Sound - HitAlarm; // 0xc48(0x08)
	bool Use Emissive 2; // 0xc50(0x01)
	char UnknownData_C51[0x7]; // 0xc51(0x07)
	struct USoundBase* Sound - Jump on Car; // 0xc58(0x08)
	float SuspensionMovementAmount; // 0xc60(0x04)
	bool ParticleEffectHas_NOT_AlreadyBeenTriggered; // 0xc64(0x01)
	char UnknownData_C65[0x3]; // 0xc65(0x03)
	struct UParticleSystemComponent* EngineSteamParticleEffect; // 0xc68(0x08)
	struct USoundBase* Sound - Hit AutoBody; // 0xc70(0x08)
	bool canMakeJumpingNoiseAgain; // 0xc78(0x01)
	bool CarAlarmIsCurrentlyMakingNoise; // 0xc79(0x01)
	bool CarAlarmEnabled; // 0xc7a(0x01)
	bool RandomlyDisableSomeCarAlarms; // 0xc7b(0x01)
	float PercentageChanceOfCarAlarmsBeingDisabled; // 0xc7c(0x04)
	struct UPointLightComponent* HLight1; // 0xc80(0x08)
	struct FVector HLight1SocketLocation; // 0xc88(0x0c)
	struct FVector HLight2SocketLocation; // 0xc94(0x0c)
	struct TArray<struct UMaterialInstanceDynamic*> AnimatingMIDArray; // 0xca0(0x10)
	struct UAudioComponent* AudibleAlarmSound; // 0xcb0(0x08)
	bool UseCarBounce; // 0xcb8(0x01)
	bool UseCarAlarm; // 0xcb9(0x01)
	char UnknownData_CBA[0x2]; // 0xcba(0x02)
	float Headlight Emissive Brightness; // 0xcbc(0x04)
	bool IsCarAlarmEnabledInitialized; // 0xcc0(0x01)
	bool DebugWind; // 0xcc1(0x01)
	char UnknownData_CC2[0x6]; // 0xcc2(0x06)
	struct TArray<struct UMaterialInterface*> OriginalMaterials; // 0xcc8(0x10)
	struct TArray<struct UMaterialInterface*> IntenseWindMaterialsForPreview; // 0xcd8(0x10)
	struct UMaterialInstanceDynamic* Debug_TempMaterial; // 0xce8(0x08)
	float Debug Wind Intensity; // 0xcf0(0x04)
	char UnknownData_CF4[0x4]; // 0xcf4(0x04)
	struct UStaticMeshComponent* Wind Intensity Debug Mesh; // 0xcf8(0x08)
	bool CanDropOilDecal; // 0xd00(0x01)
	char UnknownData_D01[0x3]; // 0xd01(0x03)
	float Wind Yaw Rotation; // 0xd04(0x04)
	struct UPointLightComponent* Taillight1; // 0xd08(0x08)
	struct UPointLightComponent* Taillight2; // 0xd10(0x08)
	float TailLightBrightness; // 0xd18(0x04)
	bool TailLightsExist; // 0xd1c(0x01)
	bool HeadLightsExist; // 0xd1d(0x01)
	char UnknownData_D1E[0x2]; // 0xd1e(0x02)
	struct USpotLightComponent* HLight2; // 0xd20(0x08)
	float HeadLightLightBrightness; // 0xd28(0x04)
	struct FVector TLight1SocketLocation; // 0xd2c(0x0c)
	struct FVector TLight2SocketLocation; // 0xd38(0x0c)
	struct FVector Bounce Offset; // 0xd44(0x0c)
	struct FVector hlight2 - impact bounce light location; // 0xd50(0x0c)
	struct FVector tlight2 - impact bounce light location; // 0xd5c(0x0c)
	bool Car Currently Bouncing From Jump; // 0xd68(0x01)
	char UnknownData_D69[0x3]; // 0xd69(0x03)
	struct FVector hlight1 - impact bounce light location; // 0xd6c(0x0c)
	struct FVector tlight1 - impact bounce light location; // 0xd78(0x0c)
	bool Randomly start with some cars lights on; // 0xd84(0x01)
	char UnknownData_D85[0x3]; // 0xd85(0x03)
	float Percentage chance of lights being left off; // 0xd88(0x04)
	float Final Random Light Intensity Variance; // 0xd8c(0x04)
	bool This Car's Lights Have Been Enabled; // 0xd90(0x01)
	bool TurnHeadLightsOn; // 0xd91(0x01)
	char UnknownData_D92[0x2]; // 0xd92(0x02)
	float TimeSinceLastJumpSound; // 0xd94(0x04)
	float MinTimeBetweenJumpSound; // 0xd98(0x04)
	char UnknownData_D9C[0x4]; // 0xd9c(0x04)
	struct FMulticastInlineDelegate OnPlayDeathEffects; // 0xda0(0x10)
	float currentLightRuntimeIntensity; // 0xdb0(0x04)

	void Construct Clean Up Lights(); // Function Car_DEFAULT.Car_DEFAULT_C.Construct Clean Up Lights // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void construct_ValidateLightsOnVars(bool doesHaveLights); // Function Car_DEFAULT.Car_DEFAULT_C.construct_ValidateLightsOnVars // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void validateLightVisibility(); // Function Car_DEFAULT.Car_DEFAULT_C.validateLightVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void generateMeshMIDs(); // Function Car_DEFAULT.Car_DEFAULT_C.generateMeshMIDs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void getCarMatsForLights(struct TArray<struct UMaterialInstanceDynamic*> outMaterials); // Function Car_DEFAULT.Car_DEFAULT_C.getCarMatsForLights // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlayJumpOnCarSound(struct FVector Location); // Function Car_DEFAULT.Car_DEFAULT_C.PlayJumpOnCarSound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void toggle light visibility(bool bNewVisibility); // Function Car_DEFAULT.Car_DEFAULT_C.toggle light visibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Randomize the target brightness levels(); // Function Car_DEFAULT.Car_DEFAULT_C.Randomize the target brightness levels // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Set Light Brightness(float 0-1 Intensity, bool Include Second Emissive Channel, bool Force); // Function Car_DEFAULT.Car_DEFAULT_C.Set Light Brightness // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	float MaterialEditorSine(float Look up value, float Period); // Function Car_DEFAULT.Car_DEFAULT_C.MaterialEditorSine // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xbd830c
	float SetCarAlarmEnabledBasedOnLocation(struct FVector Location, bool NewParam); // Function Car_DEFAULT.Car_DEFAULT_C.SetCarAlarmEnabledBasedOnLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void setcanmakebouncingnoisetrue(); // Function Car_DEFAULT.Car_DEFAULT_C.setcanmakebouncingnoisetrue // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void StopCarAlarmFromPlaying(); // Function Car_DEFAULT.Car_DEFAULT_C.StopCarAlarmFromPlaying // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void UserConstructionScript(); // Function Car_DEFAULT.Car_DEFAULT_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Timeline_0__FinishedFunc(); // Function Car_DEFAULT.Car_DEFAULT_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_0__UpdateFunc(); // Function Car_DEFAULT.Car_DEFAULT_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void BounceCar__FinishedFunc(); // Function Car_DEFAULT.Car_DEFAULT_C.BounceCar__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void BounceCar__UpdateFunc(); // Function Car_DEFAULT.Car_DEFAULT_C.BounceCar__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_2__FinishedFunc(); // Function Car_DEFAULT.Car_DEFAULT_C.Timeline_2__FinishedFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_2__UpdateFunc(); // Function Car_DEFAULT.Car_DEFAULT_C.Timeline_2__UpdateFunc // (BlueprintEvent) // @ game+0xbd830c
	void Timeline_2__FireOffNoise__EventFunc(); // Function Car_DEFAULT.Car_DEFAULT_C.Timeline_2__FireOffNoise__EventFunc // (BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function Car_DEFAULT.Car_DEFAULT_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // Function Car_DEFAULT.Car_DEFAULT_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void StartSirenLight(); // Function Car_DEFAULT.Car_DEFAULT_C.StartSirenLight // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void FadeSirenLight(); // Function Car_DEFAULT.Car_DEFAULT_C.FadeSirenLight // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void TriggerLowHealthParticleEffect(); // Function Car_DEFAULT.Car_DEFAULT_C.TriggerLowHealthParticleEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Car_DEFAULT.Car_DEFAULT_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnDamagePlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Car_DEFAULT.Car_DEFAULT_C.OnDamagePlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function Car_DEFAULT.Car_DEFAULT_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function Car_DEFAULT.Car_DEFAULT_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void FireOffCarAlarm(); // Function Car_DEFAULT.Car_DEFAULT_C.FireOffCarAlarm // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnBounceAnimationUpdate(struct FFortBounceData Data); // Function Car_DEFAULT.Car_DEFAULT_C.OnBounceAnimationUpdate // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Hit Bounce Finished(); // Function Car_DEFAULT.Car_DEFAULT_C.Hit Bounce Finished // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Player jump based bounce (); // Function Car_DEFAULT.Car_DEFAULT_C.Player jump based bounce  // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function Car_DEFAULT.Car_DEFAULT_C.OnDayPhaseChanged // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_Car_DEFAULT(int32_t EntryPoint); // Function Car_DEFAULT.Car_DEFAULT_C.ExecuteUbergraph_Car_DEFAULT // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void OnPlayDeathEffects__DelegateSignature(); // Function Car_DEFAULT.Car_DEFAULT_C.OnPlayDeathEffects__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

