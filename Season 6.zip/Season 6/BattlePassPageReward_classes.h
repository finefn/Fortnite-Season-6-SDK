// WidgetBlueprintGeneratedClass BattlePassPageReward.BattlePassPageReward_C
// Size: 0xd48 (Inherited: 0xc60)
struct UBattlePassPageReward_C : UFortBattlePassReward {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc60(0x08)
	struct UWidgetAnimation* SpecialQuestPulse; // 0xc68(0x08)
	struct UWidgetAnimation* OnSelected; // 0xc70(0x08)
	struct UWidgetAnimation* NewTechPulse; // 0xc78(0x08)
	struct UWidgetAnimation* OnHover; // 0xc80(0x08)
	struct UVerticalBox* AlignmentVB; // 0xc88(0x08)
	struct UCommonTextBlock* BonusString; // 0xc90(0x08)
	struct UOverlay* Free; // 0xc98(0x08)
	struct UCommonTextBlock* FreeString; // 0xca0(0x08)
	struct UImage* FreeTrack; // 0xca8(0x08)
	struct UImage* Image_86; // 0xcb0(0x08)
	struct USizeBox* ItemSB; // 0xcb8(0x08)
	struct UImage* LinePulseBottom; // 0xcc0(0x08)
	struct UImage* LinePulseTop; // 0xcc8(0x08)
	struct UImage* NewTechBacking; // 0xcd0(0x08)
	struct UImage* NewTechIcon; // 0xcd8(0x08)
	struct UOverlay* Overlay_SpecialQuestInfo; // 0xce0(0x08)
	struct UImage* PaidTrack; // 0xce8(0x08)
	struct UImage* Pulse; // 0xcf0(0x08)
	struct UImage* PulseIcon; // 0xcf8(0x08)
	struct UImage* PulseLineBottom; // 0xd00(0x08)
	struct UImage* PulseLineTop; // 0xd08(0x08)
	struct UCommonTextBlock* QuestString; // 0xd10(0x08)
	struct UImage* SpecialQuestBacking; // 0xd18(0x08)
	struct UImage* SpecialQuestIcon; // 0xd20(0x08)
	float LargeHeight; // 0xd28(0x04)
	float LargeWidth; // 0xd2c(0x04)
	float SmallHeight; // 0xd30(0x04)
	float SmallWidth; // 0xd34(0x04)
	float LargeMobileHeight; // 0xd38(0x04)
	float LargeMobileWidth; // 0xd3c(0x04)
	float SmallMobileHeight; // 0xd40(0x04)
	float SmallMobileWidth; // 0xd44(0x04)

	void OnMouseLeave(struct FPointerEvent MouseEvent); // Function BattlePassPageReward.BattlePassPageReward_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void UpdateVisualsToCompletedState(); // Function BattlePassPageReward.BattlePassPageReward_C.UpdateVisualsToCompletedState // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void SetLargeRewardVisuals(); // Function BattlePassPageReward.BattlePassPageReward_C.SetLargeRewardVisuals // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void ResetToDefault(); // Function BattlePassPageReward.BattlePassPageReward_C.ResetToDefault // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void InitForReward(struct UFortItemDefinition* RewardItem); // Function BattlePassPageReward.BattlePassPageReward_C.InitForReward // (Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BP_OnHovered(); // Function BattlePassPageReward.BattlePassPageReward_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function BattlePassPageReward.BattlePassPageReward_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void PreConstruct(bool IsDesignTime); // Function BattlePassPageReward.BattlePassPageReward_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void BP_OnDeselected(); // Function BattlePassPageReward.BattlePassPageReward_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnSelected(); // Function BattlePassPageReward.BattlePassPageReward_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnOverrideIcon(struct TSoftObjectPtr<struct UTexture2D> IconOverride); // Function BattlePassPageReward.BattlePassPageReward_C.OnOverrideIcon // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function BattlePassPageReward.BattlePassPageReward_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BattlePassPageReward(int32_t EntryPoint); // Function BattlePassPageReward.BattlePassPageReward_C.ExecuteUbergraph_BattlePassPageReward // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

