// WidgetBlueprintGeneratedClass AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C
// Size: 0x558 (Inherited: 0x4b0)
struct UAthenaMatchmakingPlayLegacy_C : UFortAthenaMatchmakingWidgetLegacy {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b0(0x08)
	struct UWidgetAnimation* NewModeViolation; // 0x4b8(0x08)
	struct UAthenaGenericLobbyViolator_C* AthenaGenericLobbyViolator; // 0x4c0(0x08)
	struct UIconTextButton_C* DebugCreativeServerSelect; // 0x4c8(0x08)
	struct UImage* MatchmakingSpinner; // 0x4d0(0x08)
	struct UCommonBorder* NewModeBorder; // 0x4d8(0x08)
	struct UShowdownLobbyViolator_C* ShowdownLobbyViolator; // 0x4e0(0x08)
	struct UOverlay* ViolatorContent; // 0x4e8(0x08)
	struct UWidgetSwitcher* ViolatorSwitcher; // 0x4f0(0x08)
	struct FMulticastInlineDelegate PlaylistsUpdated; // 0x4f8(0x10)
	struct FTimerHandle ShowNewPlaylistTimer; // 0x508(0x08)
	struct FMulticastInlineDelegate OnPlaylistChanged; // 0x510(0x10)
	struct USoundBase* MatchmakingSucceededSound; // 0x520(0x08)
	SoftClassProperty CreativeOptionsSoftClass; // 0x528(0x28)
	struct UUserWidget* CreativeOptionsClass; // 0x550(0x08)

	void OnLoaded_624287AB42851447B4164286AAD2D464(struct UObject* Loaded); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.OnLoaded_624287AB42851447B4164286AAD2D464 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void Construct(); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void OnAvailablePlaylistsUpdated(); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.OnAvailablePlaylistsUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnSetPlayButtonText(struct FText PlayButtonText); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.OnSetPlayButtonText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void OnSetCancelButtonText(struct FText CancelButtonText); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.OnSetCancelButtonText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void PlaylistChanged(struct FPlaylistFrontEndData NewPlaylist, struct FText PlaylistCMSOverrideName, enum class EFortLobbyType LobbyType); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.PlaylistChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void SetSquadFillText(bool InCurrentSquadFill); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.SetSquadFillText // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnNewModeViolatorUpdated(bool bShouldShow); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.OnNewModeViolatorUpdated // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void UpdateCustomViolatorText(struct FText ModeName, struct FText SubText); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.UpdateCustomViolatorText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void Animate(); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.Animate // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnMatchmakingFinishedBlueprint(bool bSuccess, struct UFortPlaylistAthena* Playlist); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.OnMatchmakingFinishedBlueprint // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BndEvt__PlayButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(struct UCommonButton* Button); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.BndEvt__PlayButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_AthenaMatchmakingPlayLegacy(int32_t EntryPoint); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.ExecuteUbergraph_AthenaMatchmakingPlayLegacy // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
	void OnPlaylistChanged__DelegateSignature(struct FPlaylistFrontEndData Playlist Data, struct FText Playlist CMS Override, enum class EFortLobbyType Lobby Type); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.OnPlaylistChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void PlaylistsUpdated__DelegateSignature(); // Function AthenaMatchmakingPlayLegacy.AthenaMatchmakingPlayLegacy_C.PlaylistsUpdated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
};

