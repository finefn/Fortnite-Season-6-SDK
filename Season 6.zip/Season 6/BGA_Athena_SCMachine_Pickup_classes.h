// BlueprintGeneratedClass BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C
// Size: 0x9b9 (Inherited: 0x898)
struct ABGA_Athena_SCMachine_Pickup_C : ABuildingGameplayActorSpawnChip {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x898(0x08)
	struct UAudioComponent* SC_Machine_Memory_Card_Loop_Cue; // 0x8a0(0x08)
	struct UParticleSystemComponent* SpawnInEffect; // 0x8a8(0x08)
	struct UCapsuleComponent* Collision; // 0x8b0(0x08)
	struct UStaticMeshComponent* BackgroundGlow; // 0x8b8(0x08)
	struct UStaticMeshComponent* Card; // 0x8c0(0x08)
	int32_t UnHide; // 0x8c8(0x04)
	float DelayBeforeUnhide; // 0x8cc(0x04)
	enum class None OwnerTeam; // 0x8d0(0x01)
	char UnknownData_8D1[0x7]; // 0x8d1(0x07)
	struct TArray<struct AActor*> FoundBuildingOnDied; // 0x8d8(0x10)
	struct FVector Impact_Loc; // 0x8e8(0x0c)
	struct FVector HitNormal; // 0x8f4(0x0c)
	float MaxSlope; // 0x900(0x04)
	char UnknownData_904[0x4]; // 0x904(0x04)
	struct FTimerHandle Timer_DestroyPickup; // 0x908(0x08)
	struct FScalableFloat Row_PickupLife; // 0x910(0x28)
	struct FText InteractText; // 0x938(0x18)
	struct UParticleSystem* SpawnOutParticle; // 0x950(0x08)
	struct USoundBase* PickupSound; // 0x958(0x08)
	struct UParticleSystemComponent* SpawnFX; // 0x960(0x08)
	bool SpawnSoundPlayed; // 0x968(0x01)
	char UnknownData_969[0x7]; // 0x969(0x07)
	struct USoundBase* SpawnInSound; // 0x970(0x08)
	bool IsPendingKill; // 0x978(0x01)
	char UnknownData_979[0x3]; // 0x979(0x03)
	struct FVector StopLocation; // 0x97c(0x0c)
	bool HideAndKill; // 0x988(0x01)
	char UnknownData_989[0x7]; // 0x989(0x07)
	struct FScalableFloat Row_PickUpInteractTime; // 0x990(0x28)
	bool IsDelayingDeath; // 0x9b8(0x01)

	void OnRep_HideAndKill(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnRep_HideAndKill // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ConsiderPositionCorrection(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ConsiderPositionCorrection // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DetermineStopLocation(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.DetermineStopLocation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xbd830c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xbd830c
	void OnRep_UnHide(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnRep_UnHide // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ReceiveBeginPlay(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void DestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.DestroyPickup // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xbd830c
	void CollectPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.CollectPickup // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnDestroyPickup // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void SpawnSound(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.SpawnSound // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void HideAndKillPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.HideAndKillPickup // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void DelayDestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.DelayDestroyPickup // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BGA_Athena_SCMachine_Pickup(int32_t EntryPoint); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ExecuteUbergraph_BGA_Athena_SCMachine_Pickup // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

