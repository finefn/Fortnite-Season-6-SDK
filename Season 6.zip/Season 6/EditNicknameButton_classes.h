// WidgetBlueprintGeneratedClass EditNicknameButton.EditNicknameButton_C
// Size: 0xc40 (Inherited: 0xc28)
struct UEditNicknameButton_C : UFortEditNicknameButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc28(0x08)
	struct UWidgetAnimation* OnHovered; // 0xc30(0x08)
	struct UBorder* ClickCapture; // 0xc38(0x08)

	void BP_OnHovered(); // Function EditNicknameButton.EditNicknameButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void BP_OnUnhovered(); // Function EditNicknameButton.EditNicknameButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_EditNicknameButton(int32_t EntryPoint); // Function EditNicknameButton.EditNicknameButton_C.ExecuteUbergraph_EditNicknameButton // (Final|UbergraphFunction) // @ game+0xbd830c
};

