// BlueprintGeneratedClass BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C
// Size: 0x4418 (Inherited: 0x4408)
struct ABP_Pawn_DangerGrape_C : ABP_PlayerPawn_Athena_Phoebe_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4408(0x08)
	struct UParticleSystemComponent* Effect_Hologram; // 0x4410(0x08)

	void ReceiveBeginPlay(); // Function BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xbd830c
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xbd830c
	void PlayResOut_2(); // Function BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C.PlayResOut_2 // (BlueprintCallable|BlueprintEvent) // @ game+0xbd830c
	void ExecuteUbergraph_BP_Pawn_DangerGrape(int32_t EntryPoint); // Function BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C.ExecuteUbergraph_BP_Pawn_DangerGrape // (Final|UbergraphFunction|HasDefaults) // @ game+0xbd830c
};

